# Contractor Project Management — Phase 1

Internal tool for your team only. Phase 1 delivers two things: a jobs dashboard that organizes work by job, and a deep, opinionated estimating interface inside each job. Everything later (billing, schedule, client/designer portals) will read from the estimate, so we get its data model right now.

## Branding — Finer Builders

Restrained, minimal use of your logos in chocolate on a warm off-white interface:

- **Logo mark (solid circle)** — favicon and the small sidebar/top-bar mark. That's it for app chrome.
- **Horizontal stack** — sign-in screen, and the header of printed/PDF proposals and invoices.
- **Secondary / tertiary marks** — held in reserve for client-facing documents later; not used in the app UI.

No logo watermarks, no repeating marks on cards or empty states. Chocolate brown becomes the primary token with a warm neutral background and a quiet serif for headings to match the wordmark; the estimating grid stays neutral and data-dense so numbers, not branding, carry the screen.

## 1. Jobs dashboard

- Board + table toggle of all jobs, grouped by stage: Lead, Estimating, Proposal Sent, Contracted, Pre-Con, Production, Punch, Closeout.
- Job card shows: name, client, address, type (Remodel / Custom Home / Addition), stage, contract amount, estimated cost, current margin (with a warning color when below target), start/target dates.
- Filters by stage, job type, and lead/PM. Search by job or client name.
- "New Job" flow: name, client, address, job type, target margin, notes.
- Clicking a job opens the job workspace with tabs: Estimate (built now), Billing, Schedule, Files, Notes (placeholders in Phase 1).

## 2. Estimating interface (the deep part)

### Sequenced structure
Estimates are organized in **execution sequence**, not CSI numeric order — the order the job actually gets built. Phases use trade-style language similar to CSI (Sitework & Demo, Concrete & Foundations, Framing & Structure, Roofing & Envelope, Windows & Doors, Rough Mechanicals, Insulation & Drywall, Interior Finishes, Cabinetry & Tops, Flooring, Tile & Stone, Paint & Coatings, Specialties & Fixtures, Landscape & Exterior, General Conditions & Supervision) but not the exact CSI numbering.

### Prebuilt sequence templates
Dropdown at estimate creation loads a starter sequence of phases for the job type:
- Kitchen Remodel
- Bath Remodel
- Whole-House Remodel
- Addition
- Custom Home
- ADU / Garage Conversion
- Exterior / Envelope Only

Phases can be added, removed, renamed, and reordered by drag; the template is a starting point, never a cage.

### Line items — choose your method per line
Each line item picks its own estimating method, with sub-categories:
- **Square Foot** — area x $/SF (sub: floor area, wall area, roof area, counter area)
- **Unit Cost** — qty x unit price (sub: each, LF, SF, SY, CY, ton, sheet, gallon, day, hour)
- **Assembly** — a saved bundle that expands into its component costs (e.g. "Interior wall, 2x4 @16 in OC, drywall both sides"), editable after insert
- **Allowance** — dollar placeholder for undecided scope
- **Subcontract Bid** — lump sum from a sub, with vendor name and bid status
- **Labor** — crew hours x burdened rate

Every line carries: cost type (Labor / Material / Sub / Equipment / Other), cost, markup multiplier, sell price, and notes.

### Markup as a multiplier
Markup is entered as a **multiplier** (1.35, 1.5, 2.0), never a percent. Multipliers cascade with override at each level: company default -> phase default -> line item. Sell = cost x multiplier. Margin % is displayed as derived output only, so you can see what a multiplier actually earns.

### Live margin guardrails
Sticky summary bar always visible while editing:
- Total cost, total sell, gross profit, gross margin %
- Blended multiplier
- Target margin for the job, with live variance
- Warning state when margin drops below target, and a hard alert below a floor you set
- Per-phase margin strip so you can see which phase is eroding profit
- "Solve to target" action: back-solves the multiplier needed to hit your target margin, applied globally or to selected phases

### Assemblies & cost library
A reusable library of cost items and assemblies (unit costs, default multipliers, default cost type) so estimates get faster each job. Editable by your team; items can be pushed from an estimate line back into the library.

### Estimate output
Read-only proposal view grouped by phase, with a toggle for client-facing detail level (single total, phase totals, or full line detail). Cost and markup columns never appear in the client view.

## Technical notes

- Lovable Cloud for database, auth, and storage. Email/password sign-in restricted to your team; roles table (owner, pm, lead, admin) with owner-only visibility on cost and markup columns enforced in RLS.
- Schema: `jobs`, `estimates`, `estimate_phases`, `estimate_line_items`, `assemblies`, `assembly_components`, `cost_library_items`, `sequence_templates`, `template_phases`, `profiles`, `user_roles`.
- Money stored as integer cents; multipliers as numeric(6,4). All margin math computed from stored cost and multiplier, never from stored percentages.
- Estimating grid is a keyboard-first editable table (tab across fields, enter for new line, drag to reorder) — spreadsheet speed, not a form per line.
- Seeded on first migration: the phase library, the sequence templates above, and a starter set of assemblies and unit-cost items you can edit.

## Not in Phase 1

Billing/invoicing, change orders, scheduling, purchase orders, time tracking, client and designer portals. The estimate data model is built so these attach to it without rework.
