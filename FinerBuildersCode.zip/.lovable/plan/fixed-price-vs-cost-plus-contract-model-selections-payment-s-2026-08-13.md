# Fixed Price vs Cost Plus — contract model, selections, payment schedule

Your read is right: estimating is the same for both delivery types, and everything downstream of the estimate splits. This pass builds the split cleanly so billing and draw requests attach later without rework.

## 1. Contract type on the job

Every job is either **Fixed Price** or **Cost Plus**, chosen at creation and visible on the job card and job header. It drives the proposal, the payment schedule, and later the billing screen.

New job dialog gains:

- Contract type: Fixed Price / Cost Plus
- For Cost Plus: fee style — **Percent fee on cost** (one visible fee line, e.g. 20%) or **Per-line multipliers** (each line's markup rolled into one fee amount)
- Cost Plus also gets a **contingency %** field (reserved now, drawn against later)

Job type (kitchen, whole house, etc.) stays separate — that drives the phase template, not the money model.

## 2. Estimating stays as-is

Same grid, same phases, same multipliers, same margin guardrails. One label fix: the **Sell** column becomes **Price**.

## 3. Selections tracker

New tab on the job. A selection is a decision the client owes you:

- Item, room/location, allowance amount, linked estimate line (optional)
- Status: Pending / Decided / Ordered
- Due before phase (picked from the estimate's phases), with an overdue flag once that phase is the current one
- Actual chosen cost once decided, with variance vs the allowance shown

Allowance lines in the estimate can spawn a selection in one click, so the allowance and the pending decision stay tied together.

## 4. Proposal — two shapes

**Fixed Price proposal** (what exists today, refined): phase names, scope summary, one lump sum. No cost, no multiplier, ever. Allowances called out in their own block with amounts so the client knows what's still open.

**Cost Plus proposal** (new): transparent.

```text
Estimated cost of work, by phase        $ 412,500
Contingency (5%)                        $  20,625
Builder fee (20% of cost)               $  82,500
--------------------------------------------------
Estimated total                         $ 515,625
```

Phase-level estimated costs are visible, the fee is a single visible line derived from the job's fee style, and the language makes clear costs are estimates billed at actual. Detail level toggle (total only / phase totals / full line detail) applies to both shapes.

## 5. Payment schedule from the estimate

New tab, generated off the estimate, different by contract type.

**Fixed Price** — a milestone schedule:

- Auto-draft one milestone per phase, amount = that phase's price, plus a deposit line you set as a % or dollar amount
- Rows editable: name, amount, % of contract, trigger (on signing / phase start / phase complete / date)
- Live validation that the milestones sum exactly to the contract price, with the variance shown until it balances
- Each milestone remembers which phase and which estimate lines it covers — that's the hook receipts and sub invoices match to during construction
- add the option to combine phases for less payment lines. I want to be able to have it either as the estimate broke it super detaield or have the option to compile lots of lines and create bigger dollar amounts to request. I also want to have the option to create a pay scheduel based on % complete broken down into 4 25% payments or 5 20% payments. all of these shold be selectable when we are generating the pay scheduel based off the estimate. Theres a benefit for me to combine lots of work into one payment because it avoids the clinets doing math and contestings small charges 

**Cost Plus** — an AIA G702/G703-style schedule of values:

- One row per phase (expandable to line detail), with the estimated cost as the **target**
- Columns matching G703: scheduled value, work completed previous, this period, materials stored, total completed, % complete, balance to finish, retainage
- A visible **contingency** row you can draw against, showing amount used and remaining
- Fee row computed from the job's fee style so the total tracks with the cost lines
- Read-only totals now; entering actuals and generating draw requests is the next pass

Once a payment schedule is approved the target numberrs are locked in and the scheduel of values needs to become an interactive document where i can update and create draw requests based off progress being made. so it would show the document in its entirty with its latest updates and then there will be a button to create either a draw reqeust, change order, etc.. when a draw request is created the document will be updated just like a G702 would be and then invoices attached as backup to the amounts as well as pictures of on site material. just like the banks require when an official draw request is made from a financial institution. once that draw request is created and sent out the G702 document will now populate as the updated current version. I also need to be able to go back and see older draw requests with the g702 and back up saved as older renditions. dont just delete past versions. when a new request is made save the old reqeust with the old version of the document.

## 6. What comes after this pass

Construction budget entry (receipts and sub invoices matched to schedule lines for fixed price), progress payment entry against the G702 for cost plus, then the "Create draw request" button that snapshots the G702 and pulls QuickBooks backup. Cost entry is manual to start; the schema stores an external reference field on every cost row so a QuickBooks sync can fill it in later without a migration.

## Technical notes

- New enums: `contract_type` (fixed_price, cost_plus), `fee_style` (percent_of_cost, line_multipliers), `selection_status`, `payment_trigger`
- `jobs` gains `contract_type`, `fee_style`, `fee_percent`, `contingency_percent`
- New tables: `selections`, `payment_schedules`, `payment_schedule_items` (with `phase_id`, `scheduled_value_cents`, `retainage_percent`, `is_contingency`, `external_ref`), plus a link table for schedule item ↔ estimate lines
- Every new public table gets GRANTs, RLS enabled, and team-scoped policies matching the existing pattern; money stays integer cents, multipliers numeric(6,4)
- Cost-plus totals derive from stored cost + fee inputs; nothing stores a computed total