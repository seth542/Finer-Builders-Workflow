# Backend Code Review Package

## Goal
Compile the project's backend code into a single chat-pasteable review package so the user's coding buddy can evaluate it.

## What will be included
The package covers all server-side code and data layer:

1. **Supabase schema & migrations** — all `supabase/migrations/*.sql` files and `supabase/config.toml`.
2. **Supabase server clients & middleware** — `src/integrations/supabase/client.server.ts`, `auth-middleware.ts`, `auth-attacher.ts`, `types.ts`.
3. **Server functions** — `src/lib/integrations.functions.ts` (QuickBooks OAuth / disconnect).
4. **Server/API routes** — `src/routes/api/public/quickbooks/callback.ts`, `src/routes/mcp.ts`, `src/routes/[.mcp]/list-tools.ts`, `src/routes/[.mcp]/invoke-tool/$tool.ts`, `src/routes/[.well-known]/oauth-protected-resource.ts`.
5. **MCP server implementation** — `src/lib/mcp/index.ts`, `src/lib/mcp/supabase.ts`, `src/lib/mcp/tools/list-jobs.ts`, `src/lib/mcp/tools/get-job.ts`, `src/lib/mcp/tools/list-estimate-lines.ts`, `src/lib/mcp/tools/list-billing.ts`, `src/lib/mcp/tools/set-job-stage.ts`.
6. **Server infrastructure** — `src/start.ts`, `src/server.ts`, `src/lib/error-page.ts`, `src/lib/error-capture.ts`.

## What will be excluded
- Frontend components, routes, hooks, and client-side queries (`src/lib/queries.ts`, `src/routes/index.tsx`, etc.).
- Browser-only Supabase client (`src/integrations/supabase/client.ts`) unless needed for context.
- Assets, build config, and unrelated documentation.

## Delivery format
Paste the code into the chat in logical groups, grouped by the categories above. No secrets will be scrubbed per the user's preference.

## Steps
1. Read every file listed above.
2. Order the contents into a readable sequence: schema → clients/middleware → server functions → API routes → MCP tools → server infra.
3. Paste the grouped code into chat.

## Notes
- The code base is small enough that the full backend can be shared in one go.
- If any file is too long, I will summarize it and paste the rest in a follow-up message.
