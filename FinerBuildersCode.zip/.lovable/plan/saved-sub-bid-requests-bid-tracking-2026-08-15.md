# Saved sub bid requests + bid tracking

Right now the sub bid request is print-only: you build the document in the dialog and it disappears when you close it. This adds saving, a list at the bottom of Scope breakdown, and a place to log the bids that come back.

## What you'll get

**Saving the request**
- The Create sub bid request dialog gets a "Save request" action alongside Copy text and Print / save as PDF. Saving stores the trade, the selected scope items with their scope text, general requirements, exclusions, bids-due date, and contact.
- Saving also keeps the print/copy behavior, so nothing about the document changes.

**Bid requests list (bottom of Scope breakdown)**
Each saved request shows as a row/card with:
- Trade name, date created, bids due date, item count
- Buttons: Print / save as PDF (rebuilds the same document from the saved snapshot), Copy text, Delete
- A bids section inside the row

**Logging bids received**
Inside each request row, an inline table of bids:
- Sub name, amount, date received, optional notes, status (received / declined / no bid)
- "Add bid" adds a row; amounts entered as dollars, stored in cents
- Row footer shows low bid, high bid, and spread across the logged bids, plus a comparison against the estimated cost of the scope items in that request so you can see if bids are over or under budget
- Mark one bid as "Awarded" (a badge; no automatic writes to the estimate or job costs)

Available on both fixed price and cost plus jobs, since the tab is shared.

## Technical notes

New tables (with grants, RLS for authenticated team members, and updated_at triggers):
- `sub_bid_requests` — job_id, phase_id (trade), trade_name, notes, exclusions, due_date, contact, snapshot jsonb (the item list at time of saving), created_by, timestamps
- `sub_bid_responses` — request_id, sub_name, amount_cents, received_on, status, notes, awarded boolean, timestamps

Frontend:
- Query options `subBidRequestsQuery(jobId)` and `subBidResponsesQuery(jobId)` in `src/lib/queries.ts`
- `SubBidRequestDialog.tsx` gains a save mutation and takes `jobId`
- New `SubBidRequestList.tsx` rendered at the bottom of `ScopeBreakdownTab.tsx`, reusing `printBidRequest`/`bidRequestToText` from `src/lib/bid-request.ts` against the saved snapshot
- Estimated-cost comparison reuses `lineCostCents` over the estimate lines referenced in the snapshot
