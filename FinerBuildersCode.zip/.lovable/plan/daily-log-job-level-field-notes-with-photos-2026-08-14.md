# Daily Log — job-level field notes with photos

A new tab inside every job where the team can record what happened on site each day, with a chronological list of past entries and optional photo attachments.

## Scope

1. **Add to project backlog**
   - Update `.lovable/todo.md` to list: Daily Log tab (entry list, create entry, attach photos) for each job.

2. **Database (Lovable Cloud)**
   - New table `daily_logs` on `job_id`:
     - `log_date` (date, not null)
     - `notes` (text)
     - `weather` (text, optional)
     - `created_by` → `auth.users`
     - `created_at`, `updated_at`
   - New table `daily_log_photos` on `daily_logs`:
     - `file_path`, `file_name`, `mime_type`, `size_bytes`, `label` (optional)
   - New private Supabase Storage bucket `daily-log-photos`.
   - GRANTs + RLS enabled on both tables; authenticated team can manage logs and photos for any job (same pattern as `draw_attachments`).

3. **Storage behavior for photos**
   - Uploads go to a private bucket.
   - App fetches signed URLs (10–60 min) to display thumbnails / open originals.
   - No file size limit enforced in code initially; rely on browser compression + Supabase Storage limits.
   - This is safe for internal use: storage is the same Lovable Cloud backend that already hosts `draw-backup` attachments.

4. **UI — job workspace tab**
   - Add a **Daily Log** tab to the existing job tabs, after **Schedule**.
   - Empty state with a "New daily log" button.
   - Entry list: most recent first, showing date, author, notes, weather, and a photo count.
   - Entry form: date picker, notes, weather, multi-file photo upload.
   - Clicking a photo opens a lightbox/modal with the signed URL.

5. **Future hooks (not in this pass)**
   - Filter by date range.
   - Client-visible daily log in a portal.
   - Mobile camera capture polish.

## What we won't do

- No public access to photos (bucket stays private).
- No video or document attachments in this first version — only photos.
- No automatic weather lookup (manual entry only).

## Technical notes

- Reuse the same attachment pattern already working in `DrawAttachments.tsx`.
- Photos stored as references (file path + metadata) in `daily_log_photos`, not inline in `daily_logs`.
- Query key: `["daily-logs", jobId]` and `["daily-log-photos", jobId]`.
- Route: tab content inside `src/routes/jobs.$jobId.tsx`; new component `src/components/daily-log/DailyLogTab.tsx`.
