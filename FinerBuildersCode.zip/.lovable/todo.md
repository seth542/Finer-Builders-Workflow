# Finer Builders — running to-do list

Kept up to date as we work. Newest decisions win.

## In progress
- [ ] Home page (command center) — layout first, then wire buttons
  - [x] Move job board to `/jobs`, home page becomes launcher
  - [ ] Wire quick actions (change order, invoice, draw request, proposal, new job, schedule item)
  - [ ] Job picker step for document creation flows
- [x] Basic financial overview on home (sold YTD, pipeline, profit, billed, by quarter)

## Next up
- [ ] Two separate AI assistants (separate training/instructions, separate data access)
  - [ ] Finer Team assistant (internal only): full access — estimates, costs, margins,
        job budget, QuickBooks costs, selections, schedule, daily logs, bids, draws
  - [ ] Client assistant (client portal only): schedule, selections + allowances,
        approved change orders, invoices/amounts due, daily log photos, warranty/records
  - [ ] Hard rule: client assistant NEVER sees cost, margin, profit, markup/fee math,
        sub bid amounts, QuickBooks data, or internal notes — enforced server-side
        (per-job scoping + separate tool set), not just in the prompt
  - [ ] Separate instruction sets/tone per assistant, editable from Integrations page
- [ ] Change orders (fixed price + cost plus)
- [ ] Production tracking / actual costs tied to estimate lines
- [ ] QuickBooks connection (needs Intuit client ID + secret)

## Backlog
- [ ] Financial overview v2: bank balance via QuickBooks, AR aging, cash flow forecast, per-quarter profit
- [ ] Client portal
- [ ] Designer portal
- [ ] More MCP agent tools for Claude
- [ ] Mobile polish on job board and estimating grid
- [ ] Billing rollup across all jobs
- [ ] Cost library / assemblies management screen
- [ ] Purchase orders, time tracking
- [ ] Later: Capacitor wrapper for App Store

## Done
- [x] Branding (chocolate on warm off-white, minimal logo use)
- [x] Job board with margin health, board/table views
- [x] Estimating grid (keyboard-first, multipliers, solve to target)
- [x] Fixed price vs cost plus split across estimate, proposal, billing
- [x] Selections library + auto-generate from estimate
- [x] Payment schedules: fixed price invoices, cost plus schedule of values
- [x] Draw requests with G702 summary + continuation sheet + backup docs
- [x] Construction schedule tab (phase dates from estimate + payment schedule, client view, proposal dates)
- [x] Daily Log tab with entry history and photo attachments (per job)

- [x] Integrations page (Claude MCP connector, QuickBooks scaffold)
- [x] Published to URL
