ALTER TABLE public.estimate_phases ADD COLUMN IF NOT EXISTS duration_days integer;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS schedule_notes text;