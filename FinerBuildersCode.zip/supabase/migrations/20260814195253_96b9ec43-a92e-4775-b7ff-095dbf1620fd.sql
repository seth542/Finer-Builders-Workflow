CREATE TABLE public.daily_logs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  log_date date NOT NULL,
  notes text,
  weather text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_logs TO authenticated;
GRANT ALL ON public.daily_logs TO service_role;
ALTER TABLE public.daily_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Team manages daily logs" ON public.daily_logs FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.daily_log_photos (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  log_id uuid NOT NULL REFERENCES public.daily_logs(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  mime_type text,
  size_bytes bigint NOT NULL DEFAULT 0,
  label text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_log_photos TO authenticated;
GRANT ALL ON public.daily_log_photos TO service_role;
ALTER TABLE public.daily_log_photos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Team manages daily log photos" ON public.daily_log_photos FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER daily_logs_updated_at BEFORE UPDATE ON public.daily_logs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Team can read daily log photos" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'daily-log-photos');
CREATE POLICY "Team can upload daily log photos" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'daily-log-photos');
CREATE POLICY "Team can delete daily log photos" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'daily-log-photos');