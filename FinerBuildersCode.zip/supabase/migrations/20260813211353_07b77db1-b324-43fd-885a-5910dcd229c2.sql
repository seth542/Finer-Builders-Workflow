CREATE TABLE public.integration_secrets (
  provider text PRIMARY KEY,
  access_token text,
  refresh_token text,
  realm_id text,
  expires_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
REVOKE ALL ON public.integration_secrets FROM authenticated, anon;
GRANT ALL ON public.integration_secrets TO service_role;
ALTER TABLE public.integration_secrets ENABLE ROW LEVEL SECURITY;