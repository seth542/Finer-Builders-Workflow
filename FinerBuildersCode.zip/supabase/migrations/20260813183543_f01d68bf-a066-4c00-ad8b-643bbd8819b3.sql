-- Enums
CREATE TYPE public.app_role AS ENUM ('owner','pm','lead','admin');
CREATE TYPE public.job_type AS ENUM ('kitchen_remodel','bath_remodel','whole_house_remodel','addition','custom_home','adu_garage','exterior_only','other');
CREATE TYPE public.job_stage AS ENUM ('lead','estimating','proposal_sent','contracted','pre_con','production','punch','closeout');
CREATE TYPE public.estimate_method AS ENUM ('square_foot','unit_cost','assembly','allowance','sub_bid','labor');
CREATE TYPE public.cost_type AS ENUM ('labor','material','sub','equipment','other');

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$
LANGUAGE plpgsql SET search_path = public;

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  full_name TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team can read profiles" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "own profile upsert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());

-- Roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team can read roles" ON public.user_roles FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Jobs
CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  client_name TEXT,
  address TEXT,
  job_type public.job_type NOT NULL DEFAULT 'whole_house_remodel',
  stage public.job_stage NOT NULL DEFAULT 'lead',
  contract_amount_cents BIGINT NOT NULL DEFAULT 0,
  target_margin NUMERIC(5,4) NOT NULL DEFAULT 0.25,
  margin_floor NUMERIC(5,4) NOT NULL DEFAULT 0.18,
  start_date DATE,
  target_end_date DATE,
  notes TEXT,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.jobs TO authenticated;
GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages jobs" ON public.jobs FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Estimates
CREATE TABLE public.estimates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT 'Estimate',
  status TEXT NOT NULL DEFAULT 'draft',
  default_multiplier NUMERIC(6,4) NOT NULL DEFAULT 1.4000,
  target_margin NUMERIC(5,4) NOT NULL DEFAULT 0.25,
  margin_floor NUMERIC(5,4) NOT NULL DEFAULT 0.18,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.estimates TO authenticated;
GRANT ALL ON public.estimates TO service_role;
ALTER TABLE public.estimates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages estimates" ON public.estimates FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER estimates_updated_at BEFORE UPDATE ON public.estimates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Phases
CREATE TABLE public.estimate_phases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID NOT NULL REFERENCES public.estimates(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  default_multiplier NUMERIC(6,4),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.estimate_phases TO authenticated;
GRANT ALL ON public.estimate_phases TO service_role;
ALTER TABLE public.estimate_phases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages phases" ON public.estimate_phases FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Line items
CREATE TABLE public.estimate_line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phase_id UUID NOT NULL REFERENCES public.estimate_phases(id) ON DELETE CASCADE,
  description TEXT NOT NULL DEFAULT '',
  method public.estimate_method NOT NULL DEFAULT 'unit_cost',
  method_subtype TEXT NOT NULL DEFAULT 'each',
  cost_type public.cost_type NOT NULL DEFAULT 'material',
  quantity NUMERIC(14,4) NOT NULL DEFAULT 1,
  unit_cost_cents BIGINT NOT NULL DEFAULT 0,
  multiplier NUMERIC(6,4),
  vendor TEXT,
  notes TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.estimate_line_items TO authenticated;
GRANT ALL ON public.estimate_line_items TO service_role;
ALTER TABLE public.estimate_line_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages line items" ON public.estimate_line_items FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER line_items_updated_at BEFORE UPDATE ON public.estimate_line_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX line_items_phase_idx ON public.estimate_line_items(phase_id);

-- Cost library
CREATE TABLE public.cost_library_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phase_hint TEXT,
  method public.estimate_method NOT NULL DEFAULT 'unit_cost',
  method_subtype TEXT NOT NULL DEFAULT 'each',
  cost_type public.cost_type NOT NULL DEFAULT 'material',
  unit_cost_cents BIGINT NOT NULL DEFAULT 0,
  default_multiplier NUMERIC(6,4),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cost_library_items TO authenticated;
GRANT ALL ON public.cost_library_items TO service_role;
ALTER TABLE public.cost_library_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages library" ON public.cost_library_items FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Assemblies
CREATE TABLE public.assemblies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  phase_hint TEXT,
  unit TEXT NOT NULL DEFAULT 'each',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.assemblies TO authenticated;
GRANT ALL ON public.assemblies TO service_role;
ALTER TABLE public.assemblies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages assemblies" ON public.assemblies FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.assembly_components (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assembly_id UUID NOT NULL REFERENCES public.assemblies(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  cost_type public.cost_type NOT NULL DEFAULT 'material',
  quantity NUMERIC(14,4) NOT NULL DEFAULT 1,
  unit TEXT NOT NULL DEFAULT 'each',
  unit_cost_cents BIGINT NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.assembly_components TO authenticated;
GRANT ALL ON public.assembly_components TO service_role;
ALTER TABLE public.assembly_components ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages assembly components" ON public.assembly_components FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Sequence templates
CREATE TABLE public.sequence_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  job_type public.job_type NOT NULL DEFAULT 'other',
  sort_order INTEGER NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sequence_templates TO authenticated;
GRANT ALL ON public.sequence_templates TO service_role;
ALTER TABLE public.sequence_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages templates" ON public.sequence_templates FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.template_phases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES public.sequence_templates(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.template_phases TO authenticated;
GRANT ALL ON public.template_phases TO service_role;
ALTER TABLE public.template_phases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages template phases" ON public.template_phases FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Seed: templates
INSERT INTO public.sequence_templates (id, name, job_type, sort_order) VALUES
 ('11111111-1111-4111-8111-000000000001','Kitchen Remodel','kitchen_remodel',1),
 ('11111111-1111-4111-8111-000000000002','Bath Remodel','bath_remodel',2),
 ('11111111-1111-4111-8111-000000000003','Whole-House Remodel','whole_house_remodel',3),
 ('11111111-1111-4111-8111-000000000004','Addition','addition',4),
 ('11111111-1111-4111-8111-000000000005','Custom Home','custom_home',5),
 ('11111111-1111-4111-8111-000000000006','ADU / Garage Conversion','adu_garage',6),
 ('11111111-1111-4111-8111-000000000007','Exterior / Envelope Only','exterior_only',7);

INSERT INTO public.template_phases (template_id, name, sort_order) VALUES
 ('11111111-1111-4111-8111-000000000001','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000001','Demolition & Protection',2),
 ('11111111-1111-4111-8111-000000000001','Framing & Structure',3),
 ('11111111-1111-4111-8111-000000000001','Rough Mechanicals',4),
 ('11111111-1111-4111-8111-000000000001','Insulation & Drywall',5),
 ('11111111-1111-4111-8111-000000000001','Cabinetry & Tops',6),
 ('11111111-1111-4111-8111-000000000001','Tile & Stone',7),
 ('11111111-1111-4111-8111-000000000001','Flooring',8),
 ('11111111-1111-4111-8111-000000000001','Paint & Coatings',9),
 ('11111111-1111-4111-8111-000000000001','Specialties & Fixtures',10),
 ('11111111-1111-4111-8111-000000000001','Final Clean & Punch',11),

 ('11111111-1111-4111-8111-000000000002','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000002','Demolition & Protection',2),
 ('11111111-1111-4111-8111-000000000002','Framing & Blocking',3),
 ('11111111-1111-4111-8111-000000000002','Rough Mechanicals',4),
 ('11111111-1111-4111-8111-000000000002','Waterproofing & Substrate',5),
 ('11111111-1111-4111-8111-000000000002','Insulation & Drywall',6),
 ('11111111-1111-4111-8111-000000000002','Tile & Stone',7),
 ('11111111-1111-4111-8111-000000000002','Cabinetry & Tops',8),
 ('11111111-1111-4111-8111-000000000002','Paint & Coatings',9),
 ('11111111-1111-4111-8111-000000000002','Specialties & Fixtures',10),
 ('11111111-1111-4111-8111-000000000002','Final Clean & Punch',11),

 ('11111111-1111-4111-8111-000000000003','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000003','Sitework & Demo',2),
 ('11111111-1111-4111-8111-000000000003','Concrete & Foundations',3),
 ('11111111-1111-4111-8111-000000000003','Framing & Structure',4),
 ('11111111-1111-4111-8111-000000000003','Roofing & Envelope',5),
 ('11111111-1111-4111-8111-000000000003','Windows & Doors',6),
 ('11111111-1111-4111-8111-000000000003','Rough Mechanicals',7),
 ('11111111-1111-4111-8111-000000000003','Insulation & Drywall',8),
 ('11111111-1111-4111-8111-000000000003','Interior Finishes',9),
 ('11111111-1111-4111-8111-000000000003','Cabinetry & Tops',10),
 ('11111111-1111-4111-8111-000000000003','Flooring',11),
 ('11111111-1111-4111-8111-000000000003','Tile & Stone',12),
 ('11111111-1111-4111-8111-000000000003','Paint & Coatings',13),
 ('11111111-1111-4111-8111-000000000003','Specialties & Fixtures',14),
 ('11111111-1111-4111-8111-000000000003','Landscape & Exterior',15),
 ('11111111-1111-4111-8111-000000000003','Final Clean & Punch',16),

 ('11111111-1111-4111-8111-000000000004','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000004','Sitework & Demo',2),
 ('11111111-1111-4111-8111-000000000004','Concrete & Foundations',3),
 ('11111111-1111-4111-8111-000000000004','Framing & Structure',4),
 ('11111111-1111-4111-8111-000000000004','Roofing & Envelope',5),
 ('11111111-1111-4111-8111-000000000004','Windows & Doors',6),
 ('11111111-1111-4111-8111-000000000004','Rough Mechanicals',7),
 ('11111111-1111-4111-8111-000000000004','Insulation & Drywall',8),
 ('11111111-1111-4111-8111-000000000004','Interior Finishes',9),
 ('11111111-1111-4111-8111-000000000004','Flooring',10),
 ('11111111-1111-4111-8111-000000000004','Paint & Coatings',11),
 ('11111111-1111-4111-8111-000000000004','Final Clean & Punch',12),

 ('11111111-1111-4111-8111-000000000005','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000005','Sitework & Utilities',2),
 ('11111111-1111-4111-8111-000000000005','Concrete & Foundations',3),
 ('11111111-1111-4111-8111-000000000005','Framing & Structure',4),
 ('11111111-1111-4111-8111-000000000005','Roofing & Envelope',5),
 ('11111111-1111-4111-8111-000000000005','Windows & Doors',6),
 ('11111111-1111-4111-8111-000000000005','Rough Mechanicals',7),
 ('11111111-1111-4111-8111-000000000005','Insulation & Drywall',8),
 ('11111111-1111-4111-8111-000000000005','Interior Trim & Millwork',9),
 ('11111111-1111-4111-8111-000000000005','Cabinetry & Tops',10),
 ('11111111-1111-4111-8111-000000000005','Flooring',11),
 ('11111111-1111-4111-8111-000000000005','Tile & Stone',12),
 ('11111111-1111-4111-8111-000000000005','Paint & Coatings',13),
 ('11111111-1111-4111-8111-000000000005','Specialties & Fixtures',14),
 ('11111111-1111-4111-8111-000000000005','Landscape & Exterior',15),
 ('11111111-1111-4111-8111-000000000005','Final Clean & Punch',16),

 ('11111111-1111-4111-8111-000000000006','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000006','Sitework & Demo',2),
 ('11111111-1111-4111-8111-000000000006','Concrete & Foundations',3),
 ('11111111-1111-4111-8111-000000000006','Framing & Structure',4),
 ('11111111-1111-4111-8111-000000000006','Roofing & Envelope',5),
 ('11111111-1111-4111-8111-000000000006','Windows & Doors',6),
 ('11111111-1111-4111-8111-000000000006','Rough Mechanicals',7),
 ('11111111-1111-4111-8111-000000000006','Insulation & Drywall',8),
 ('11111111-1111-4111-8111-000000000006','Interior Finishes',9),
 ('11111111-1111-4111-8111-000000000006','Cabinetry & Tops',10),
 ('11111111-1111-4111-8111-000000000006','Paint & Coatings',11),
 ('11111111-1111-4111-8111-000000000006','Final Clean & Punch',12),

 ('11111111-1111-4111-8111-000000000007','General Conditions & Supervision',1),
 ('11111111-1111-4111-8111-000000000007','Sitework & Demo',2),
 ('11111111-1111-4111-8111-000000000007','Roofing & Envelope',3),
 ('11111111-1111-4111-8111-000000000007','Windows & Doors',4),
 ('11111111-1111-4111-8111-000000000007','Siding & Trim',5),
 ('11111111-1111-4111-8111-000000000007','Paint & Coatings',6),
 ('11111111-1111-4111-8111-000000000007','Landscape & Exterior',7),
 ('11111111-1111-4111-8111-000000000007','Final Clean & Punch',8);

-- Seed: cost library
INSERT INTO public.cost_library_items (name, phase_hint, method, method_subtype, cost_type, unit_cost_cents, default_multiplier) VALUES
 ('Project management / supervision','General Conditions & Supervision','labor','hour','labor',9500,1.35),
 ('Lead carpenter','Framing & Structure','labor','hour','labor',8500,1.40),
 ('Laborer','Sitework & Demo','labor','hour','labor',5500,1.45),
 ('Dumpster, 20 yd','Sitework & Demo','unit_cost','each','other',65000,1.20),
 ('Interior demo, gut to studs','Sitework & Demo','square_foot','floor area','labor',650,1.45),
 ('Concrete footing, formed & poured','Concrete & Foundations','unit_cost','CY','sub',48000,1.35),
 ('Framing lumber package','Framing & Structure','square_foot','floor area','material',1400,1.30),
 ('Roof, architectural shingle','Roofing & Envelope','square_foot','roof area','sub',750,1.35),
 ('Window, mid-grade vinyl, installed','Windows & Doors','unit_cost','each','sub',115000,1.35),
 ('Interior door, prehung + install','Windows & Doors','unit_cost','each','material',48000,1.40),
 ('Rough electrical','Rough Mechanicals','square_foot','floor area','sub',900,1.30),
 ('Rough plumbing','Rough Mechanicals','square_foot','floor area','sub',1100,1.30),
 ('HVAC system, ducted','Rough Mechanicals','unit_cost','each','sub',1450000,1.28),
 ('Batt insulation, walls','Insulation & Drywall','square_foot','wall area','sub',210,1.40),
 ('Drywall, hang / tape / finish','Insulation & Drywall','square_foot','wall area','sub',340,1.38),
 ('Interior paint, walls & ceilings','Paint & Coatings','square_foot','floor area','sub',480,1.40),
 ('Cabinetry, semi-custom','Cabinetry & Tops','unit_cost','LF','material',52000,1.35),
 ('Countertop, quartz, installed','Cabinetry & Tops','square_foot','counter area','sub',8500,1.35),
 ('Tile setting, floor','Tile & Stone','square_foot','floor area','sub',1450,1.40),
 ('Engineered wood flooring, installed','Flooring','square_foot','floor area','sub',1250,1.38),
 ('Plumbing fixture allowance','Specialties & Fixtures','allowance','lump sum','material',350000,1.25),
 ('Lighting allowance','Specialties & Fixtures','allowance','lump sum','material',250000,1.25),
 ('Final clean','Final Clean & Punch','unit_cost','each','sub',95000,1.30);

-- Seed: assemblies
INSERT INTO public.assemblies (id, name, description, phase_hint, unit) VALUES
 ('22222222-2222-4222-8222-000000000001','Interior wall — 2x4 @ 16" OC, drywall both sides','Framing, insulation and drywall for one square foot of interior wall','Framing & Structure','SF'),
 ('22222222-2222-4222-8222-000000000002','Bathroom wet wall — waterproofed tile substrate','Blocking, backer board and waterproofing per square foot','Waterproofing & Substrate','SF'),
 ('22222222-2222-4222-8222-000000000003','Kitchen cabinet run — installed','Semi-custom boxes, hardware and install labor per linear foot','Cabinetry & Tops','LF');

INSERT INTO public.assembly_components (assembly_id, description, cost_type, quantity, unit, unit_cost_cents, sort_order) VALUES
 ('22222222-2222-4222-8222-000000000001','2x4 studs, plates & blocking','material',1,'SF',320,1),
 ('22222222-2222-4222-8222-000000000001','Framing labor','labor',0.08,'hour',8500,2),
 ('22222222-2222-4222-8222-000000000001','Drywall both sides, finished','sub',2,'SF',340,3),
 ('22222222-2222-4222-8222-000000000002','Cement backer board','material',1,'SF',210,1),
 ('22222222-2222-4222-8222-000000000002','Liquid waterproofing membrane','material',1,'SF',185,2),
 ('22222222-2222-4222-8222-000000000002','Install labor','labor',0.06,'hour',8500,3),
 ('22222222-2222-4222-8222-000000000003','Cabinet boxes, semi-custom','material',1,'LF',52000,1),
 ('22222222-2222-4222-8222-000000000003','Hardware & pulls','material',2,'each',2200,2),
 ('22222222-2222-4222-8222-000000000003','Install labor','labor',1.2,'hour',8500,3);