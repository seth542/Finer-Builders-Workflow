CREATE TABLE public.selection_library_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  room text,
  category text,
  job_type job_type NOT NULL DEFAULT 'other',
  phase_hint text,
  default_allowance_cents bigint NOT NULL DEFAULT 0,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.selection_library_items TO authenticated;
GRANT ALL ON public.selection_library_items TO service_role;

ALTER TABLE public.selection_library_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "team manages selection library" ON public.selection_library_items
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER selection_library_updated_at BEFORE UPDATE ON public.selection_library_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.selection_library_items (name, room, category, job_type, phase_hint, default_allowance_cents, sort_order) VALUES
('Cabinets — door style & finish','Kitchen','Cabinetry','kitchen_remodel','Cabinetry & Tops',2500000,0),
('Countertops — material & edge','Kitchen','Tops','kitchen_remodel','Cabinetry & Tops',800000,1),
('Backsplash tile','Kitchen','Tile & Stone','kitchen_remodel','Tile & Stone',180000,2),
('Cabinet hardware','Kitchen','Hardware','kitchen_remodel','Cabinetry & Tops',90000,3),
('Sink & faucet','Kitchen','Plumbing fixtures','kitchen_remodel','Specialties & Fixtures',150000,4),
('Appliance package','Kitchen','Appliances','kitchen_remodel','Specialties & Fixtures',1200000,5),
('Flooring','Kitchen','Flooring','kitchen_remodel','Flooring',600000,6),
('Lighting — cans, pendants, undercabinet','Kitchen','Lighting','kitchen_remodel','Specialties & Fixtures',250000,7),
('Paint colors','Kitchen','Paint','kitchen_remodel','Paint & Coatings',0,8),

('Vanity cabinet & top','Bath','Cabinetry','bath_remodel','Cabinetry & Tops',450000,0),
('Vanity faucet & drain','Bath','Plumbing fixtures','bath_remodel','Specialties & Fixtures',60000,1),
('Toilet','Bath','Plumbing fixtures','bath_remodel','Specialties & Fixtures',70000,2),
('Tub and/or shower base','Bath','Plumbing fixtures','bath_remodel','Rough Mechanicals',120000,3),
('Shower valve & trim','Bath','Plumbing fixtures','bath_remodel','Rough Mechanicals',90000,4),
('Shower glass / enclosure','Bath','Specialties','bath_remodel','Specialties & Fixtures',200000,5),
('Floor tile','Bath','Tile & Stone','bath_remodel','Tile & Stone',150000,6),
('Wall / shower tile','Bath','Tile & Stone','bath_remodel','Tile & Stone',220000,7),
('Mirror, lights & accessories','Bath','Specialties','bath_remodel','Specialties & Fixtures',80000,8),
('Paint colors','Bath','Paint','bath_remodel','Paint & Coatings',0,9),

('Exterior siding & trim','Exterior','Envelope','whole_house_remodel','Roofing & Envelope',0,0),
('Roofing material & color','Exterior','Envelope','whole_house_remodel','Roofing & Envelope',0,1),
('Windows — brand, color, grids','Whole house','Windows & Doors',  'whole_house_remodel','Windows & Doors',1800000,2),
('Exterior doors','Whole house','Windows & Doors','whole_house_remodel','Windows & Doors',600000,3),
('Interior doors & hardware','Whole house','Windows & Doors','whole_house_remodel','Interior Finishes',450000,4),
('Trim & baseboard profile','Whole house','Interior Finishes','whole_house_remodel','Interior Finishes',0,5),
('Kitchen cabinets & tops','Kitchen','Cabinetry','whole_house_remodel','Cabinetry & Tops',3500000,6),
('Bath vanities & tops','Baths','Cabinetry','whole_house_remodel','Cabinetry & Tops',900000,7),
('Plumbing fixtures — all baths','Baths','Plumbing fixtures','whole_house_remodel','Specialties & Fixtures',600000,8),
('Tile — floors & showers','Whole house','Tile & Stone','whole_house_remodel','Tile & Stone',800000,9),
('Flooring — hardwood / LVP','Whole house','Flooring','whole_house_remodel','Flooring',1500000,10),
('Lighting package','Whole house','Lighting','whole_house_remodel','Specialties & Fixtures',700000,11),
('HVAC equipment & thermostats','Whole house','Mechanical','whole_house_remodel','Rough Mechanicals',0,12),
('Paint colors — interior & exterior','Whole house','Paint','whole_house_remodel','Paint & Coatings',0,13),
('Appliance package','Kitchen','Appliances','whole_house_remodel','Specialties & Fixtures',1500000,14),

('Roofing to match / new','Exterior','Envelope','addition','Roofing & Envelope',0,0),
('Siding & trim to match','Exterior','Envelope','addition','Roofing & Envelope',0,1),
('Windows & exterior doors','Addition','Windows & Doors','addition','Windows & Doors',900000,2),
('Interior doors & hardware','Addition','Windows & Doors','addition','Interior Finishes',250000,3),
('Flooring','Addition','Flooring','addition','Flooring',500000,4),
('Lighting & fans','Addition','Lighting','addition','Specialties & Fixtures',200000,5),
('HVAC approach & registers','Addition','Mechanical','addition','Rough Mechanicals',0,6),
('Paint colors','Addition','Paint','addition','Paint & Coatings',0,7),

('Roofing material & color','Exterior','Envelope','custom_home','Roofing & Envelope',0,0),
('Siding / stucco / masonry','Exterior','Envelope','custom_home','Roofing & Envelope',0,1),
('Windows — brand, color, grids','Whole house','Windows & Doors','custom_home','Windows & Doors',4500000,2),
('Front & exterior doors','Whole house','Windows & Doors','custom_home','Windows & Doors',1200000,3),
('Garage doors & openers','Exterior','Specialties','custom_home','Specialties & Fixtures',700000,4),
('Interior doors, trim & hardware','Whole house','Interior Finishes','custom_home','Interior Finishes',1500000,5),
('Stair parts & railing','Whole house','Interior Finishes','custom_home','Interior Finishes',900000,6),
('Kitchen cabinets & tops','Kitchen','Cabinetry','custom_home','Cabinetry & Tops',6500000,7),
('Bath & laundry cabinets','Baths','Cabinetry','custom_home','Cabinetry & Tops',2000000,8),
('Plumbing fixtures — all rooms','Whole house','Plumbing fixtures','custom_home','Specialties & Fixtures',1500000,9),
('Tile — floors, showers, accents','Whole house','Tile & Stone','custom_home','Tile & Stone',2200000,10),
('Flooring — hardwood / carpet','Whole house','Flooring','custom_home','Flooring',3000000,11),
('Lighting package','Whole house','Lighting','custom_home','Specialties & Fixtures',1800000,12),
('Appliance package','Kitchen','Appliances','custom_home','Specialties & Fixtures',2500000,13),
('HVAC equipment & controls','Whole house','Mechanical','custom_home','Rough Mechanicals',0,14),
('Paint colors — interior & exterior','Whole house','Paint','custom_home','Paint & Coatings',0,15),
('Landscape & hardscape scope','Exterior','Landscape','custom_home','Landscape & Exterior',2500000,16),

('Kitchenette cabinets & tops','ADU','Cabinetry','adu_garage','Cabinetry & Tops',1200000,0),
('Bath fixtures & vanity','ADU','Plumbing fixtures','adu_garage','Specialties & Fixtures',450000,1),
('Windows & entry door','ADU','Windows & Doors','adu_garage','Windows & Doors',600000,2),
('Flooring','ADU','Flooring','adu_garage','Flooring',400000,3),
('Lighting & fans','ADU','Lighting','adu_garage','Specialties & Fixtures',150000,4),
('Mini-split / HVAC equipment','ADU','Mechanical','adu_garage','Rough Mechanicals',0,5),
('Appliances','ADU','Appliances','adu_garage','Specialties & Fixtures',500000,6),
('Paint colors','ADU','Paint','adu_garage','Paint & Coatings',0,7),

('Roofing material & color','Exterior','Envelope','exterior_only','Roofing & Envelope',0,0),
('Siding profile & color','Exterior','Envelope','exterior_only','Roofing & Envelope',0,1),
('Trim & fascia detail','Exterior','Envelope','exterior_only','Roofing & Envelope',0,2),
('Windows — brand & color','Exterior','Windows & Doors','exterior_only','Windows & Doors',1500000,3),
('Exterior doors','Exterior','Windows & Doors','exterior_only','Windows & Doors',600000,4),
('Gutters & downspouts color','Exterior','Envelope','exterior_only','Roofing & Envelope',0,5),
('Exterior paint / stain colors','Exterior','Paint','exterior_only','Paint & Coatings',0,6),
('Deck / porch materials & railing','Exterior','Specialties','exterior_only','Landscape & Exterior',900000,7);