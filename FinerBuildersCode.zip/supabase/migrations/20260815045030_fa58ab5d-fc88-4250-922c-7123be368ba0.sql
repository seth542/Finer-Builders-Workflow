ALTER TABLE public.sub_bid_requests
  ADD COLUMN IF NOT EXISTS specs text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS materials text NOT NULL DEFAULT '';