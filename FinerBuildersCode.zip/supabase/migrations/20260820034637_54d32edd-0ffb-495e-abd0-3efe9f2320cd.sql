CREATE TABLE public.qb_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  qb_id text NOT NULL,
  qb_type text NOT NULL,
  doc_number text,
  vendor text,
  qb_customer text,
  memo text,
  txn_date date NOT NULL,
  amount_cents bigint NOT NULL,
  account_name text,
  job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  matched_cost_id uuid REFERENCES public.job_costs(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'unmatched',
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (qb_type, qb_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.qb_transactions TO authenticated;
GRANT ALL ON public.qb_transactions TO service_role;

ALTER TABLE public.qb_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team can manage quickbooks transactions"
ON public.qb_transactions FOR ALL TO authenticated
USING (true) WITH CHECK (true);

CREATE TRIGGER qb_transactions_updated_at BEFORE UPDATE ON public.qb_transactions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX qb_transactions_job_status_idx ON public.qb_transactions (job_id, status);