CREATE TABLE public.job_costs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  line_item_id uuid REFERENCES public.estimate_line_items(id) ON DELETE SET NULL,
  phase_id uuid REFERENCES public.estimate_phases(id) ON DELETE SET NULL,
  cost_type public.cost_type NOT NULL DEFAULT 'sub',
  vendor text,
  description text,
  amount_cents bigint NOT NULL DEFAULT 0,
  incurred_on date NOT NULL DEFAULT current_date,
  source text NOT NULL DEFAULT 'manual',
  external_ref text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_costs TO authenticated;
GRANT ALL ON public.job_costs TO service_role;

ALTER TABLE public.job_costs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team can manage job costs" ON public.job_costs
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX job_costs_job_id_idx ON public.job_costs(job_id);
CREATE INDEX job_costs_line_item_id_idx ON public.job_costs(line_item_id);

CREATE TRIGGER job_costs_updated_at BEFORE UPDATE ON public.job_costs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();