ALTER TABLE public.sub_bid_requests ADD COLUMN IF NOT EXISTS details text NOT NULL DEFAULT '';

CREATE TABLE public.sub_bid_attachments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  request_id uuid NOT NULL REFERENCES public.sub_bid_requests(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  mime_type text,
  size_bytes bigint NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.sub_bid_attachments TO authenticated;
GRANT ALL ON public.sub_bid_attachments TO service_role;

ALTER TABLE public.sub_bid_attachments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team manages sub bid attachments" ON public.sub_bid_attachments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "team reads sub bid files" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'sub-bid-files');
CREATE POLICY "team uploads sub bid files" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'sub-bid-files');
CREATE POLICY "team deletes sub bid files" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'sub-bid-files');