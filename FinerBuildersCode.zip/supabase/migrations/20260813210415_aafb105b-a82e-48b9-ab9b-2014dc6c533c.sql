UPDATE public.draw_requests
SET snapshot = (snapshot - 'required_backup') || jsonb_build_object(
  'lines',
  (
    SELECT coalesce(jsonb_agg(l - 'materials_stored_cents' ORDER BY ord), '[]'::jsonb)
    FROM jsonb_array_elements(snapshot->'lines') WITH ORDINALITY AS t(l, ord)
  )
)
WHERE job_id = '9129f709-ff6e-4afb-ab3f-177343c534b5'
  AND snapshot->>'kind' = 'invoice';