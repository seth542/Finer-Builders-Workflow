-- enums
CREATE TYPE public.contract_type AS ENUM ('fixed_price', 'cost_plus');
CREATE TYPE public.fee_style AS ENUM ('percent_of_cost', 'line_multipliers');
CREATE TYPE public.selection_status AS ENUM ('pending', 'decided', 'ordered');
CREATE TYPE public.payment_trigger AS ENUM ('on_signing', 'phase_start', 'phase_complete', 'date', 'progress');
CREATE TYPE public.schedule_basis AS ENUM ('per_phase', 'combined', 'equal_percent');
CREATE TYPE public.draw_status AS ENUM ('draft', 'sent', 'paid');

-- jobs
ALTER TABLE public.jobs
  ADD COLUMN contract_type public.contract_type NOT NULL DEFAULT 'fixed_price',
  ADD COLUMN fee_style public.fee_style NOT NULL DEFAULT 'percent_of_cost',
  ADD COLUMN fee_percent numeric(6,4) NOT NULL DEFAULT 0.2000,
  ADD COLUMN contingency_percent numeric(6,4) NOT NULL DEFAULT 0.0500;

-- selections
CREATE TABLE public.selections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  line_item_id uuid REFERENCES public.estimate_line_items(id) ON DELETE SET NULL,
  due_before_phase_id uuid REFERENCES public.estimate_phases(id) ON DELETE SET NULL,
  name text NOT NULL,
  room text,
  allowance_cents bigint NOT NULL DEFAULT 0,
  actual_cents bigint,
  status public.selection_status NOT NULL DEFAULT 'pending',
  vendor text,
  notes text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.selections TO authenticated;
GRANT ALL ON public.selections TO service_role;
ALTER TABLE public.selections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages selections" ON public.selections FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER selections_updated_at BEFORE UPDATE ON public.selections
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- payment schedules
CREATE TABLE public.payment_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  estimate_id uuid NOT NULL REFERENCES public.estimates(id) ON DELETE CASCADE,
  contract_type public.contract_type NOT NULL DEFAULT 'fixed_price',
  basis public.schedule_basis NOT NULL DEFAULT 'per_phase',
  deposit_cents bigint NOT NULL DEFAULT 0,
  retainage_percent numeric(6,4) NOT NULL DEFAULT 0,
  contract_total_cents bigint NOT NULL DEFAULT 0,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payment_schedules TO authenticated;
GRANT ALL ON public.payment_schedules TO service_role;
ALTER TABLE public.payment_schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages payment schedules" ON public.payment_schedules FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER payment_schedules_updated_at BEFORE UPDATE ON public.payment_schedules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- payment schedule items
CREATE TABLE public.payment_schedule_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id uuid NOT NULL REFERENCES public.payment_schedules(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  scheduled_value_cents bigint NOT NULL DEFAULT 0,
  percent_of_contract numeric(7,4),
  trigger public.payment_trigger NOT NULL DEFAULT 'phase_complete',
  due_date date,
  is_contingency boolean NOT NULL DEFAULT false,
  is_fee boolean NOT NULL DEFAULT false,
  completed_previous_cents bigint NOT NULL DEFAULT 0,
  completed_this_period_cents bigint NOT NULL DEFAULT 0,
  materials_stored_cents bigint NOT NULL DEFAULT 0,
  retainage_percent numeric(6,4),
  external_ref text,
  notes text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payment_schedule_items TO authenticated;
GRANT ALL ON public.payment_schedule_items TO service_role;
ALTER TABLE public.payment_schedule_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages payment schedule items" ON public.payment_schedule_items FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER payment_schedule_items_updated_at BEFORE UPDATE ON public.payment_schedule_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- which phases (and lines) a schedule item covers
CREATE TABLE public.payment_item_phases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid NOT NULL REFERENCES public.payment_schedule_items(id) ON DELETE CASCADE,
  phase_id uuid NOT NULL REFERENCES public.estimate_phases(id) ON DELETE CASCADE,
  UNIQUE (item_id, phase_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payment_item_phases TO authenticated;
GRANT ALL ON public.payment_item_phases TO service_role;
ALTER TABLE public.payment_item_phases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages payment item phases" ON public.payment_item_phases FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- draw requests with immutable snapshots
CREATE TABLE public.draw_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  schedule_id uuid NOT NULL REFERENCES public.payment_schedules(id) ON DELETE CASCADE,
  number integer NOT NULL DEFAULT 1,
  period_to date,
  status public.draw_status NOT NULL DEFAULT 'draft',
  amount_requested_cents bigint NOT NULL DEFAULT 0,
  retainage_cents bigint NOT NULL DEFAULT 0,
  snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (job_id, number)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.draw_requests TO authenticated;
GRANT ALL ON public.draw_requests TO service_role;
ALTER TABLE public.draw_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team manages draw requests" ON public.draw_requests FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER draw_requests_updated_at BEFORE UPDATE ON public.draw_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX selections_job_idx ON public.selections(job_id);
CREATE INDEX payment_schedules_job_idx ON public.payment_schedules(job_id);
CREATE INDEX payment_schedule_items_schedule_idx ON public.payment_schedule_items(schedule_id);
CREATE INDEX draw_requests_job_idx ON public.draw_requests(job_id);