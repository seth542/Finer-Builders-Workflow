delete from payment_schedule_items
where id = 'dddedd6d-4120-4516-9614-1f2212f846dd'
  and name = 'New line';