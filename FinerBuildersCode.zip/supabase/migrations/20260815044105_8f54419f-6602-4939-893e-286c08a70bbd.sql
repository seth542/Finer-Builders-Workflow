CREATE TABLE public.sub_bid_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  phase_id uuid REFERENCES public.estimate_phases(id) ON DELETE SET NULL,
  trade_name text NOT NULL,
  notes text NOT NULL DEFAULT '',
  exclusions text NOT NULL DEFAULT '',
  due_date date,
  contact text,
  snapshot jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.sub_bid_requests TO authenticated;
GRANT ALL ON public.sub_bid_requests TO service_role;
ALTER TABLE public.sub_bid_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Team can manage sub bid requests" ON public.sub_bid_requests FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER sub_bid_requests_updated_at BEFORE UPDATE ON public.sub_bid_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.sub_bid_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.sub_bid_requests(id) ON DELETE CASCADE,
  sub_name text NOT NULL DEFAULT '',
  amount_cents bigint NOT NULL DEFAULT 0,
  received_on date,
  status text NOT NULL DEFAULT 'received',
  notes text,
  awarded boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.sub_bid_responses TO authenticated;
GRANT ALL ON public.sub_bid_responses TO service_role;
ALTER TABLE public.sub_bid_responses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Team can manage sub bid responses" ON public.sub_bid_responses FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER sub_bid_responses_updated_at BEFORE UPDATE ON public.sub_bid_responses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX sub_bid_requests_job_idx ON public.sub_bid_requests(job_id);
CREATE INDEX sub_bid_responses_request_idx ON public.sub_bid_responses(request_id);