CREATE TABLE public.draw_attachments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  draw_id uuid NOT NULL REFERENCES public.draw_requests(id) ON DELETE CASCADE,
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  category text NOT NULL DEFAULT 'other',
  label text NOT NULL DEFAULT '',
  file_name text NOT NULL,
  file_path text NOT NULL,
  mime_type text,
  size_bytes bigint NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.draw_attachments TO authenticated;
GRANT ALL ON public.draw_attachments TO service_role;

ALTER TABLE public.draw_attachments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "team manages draw attachments" ON public.draw_attachments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX draw_attachments_draw_id_idx ON public.draw_attachments (draw_id);

CREATE POLICY "team reads draw backup" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'draw-backup');

CREATE POLICY "team uploads draw backup" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'draw-backup');

CREATE POLICY "team updates draw backup" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'draw-backup');

CREATE POLICY "team deletes draw backup" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'draw-backup');