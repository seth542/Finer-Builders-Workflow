export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      agent_tokens: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          label: string
          last_used_at: string | null
          prefix: string
          revoked_at: string | null
          token_hash: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          label: string
          last_used_at?: string | null
          prefix: string
          revoked_at?: string | null
          token_hash: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          label?: string
          last_used_at?: string | null
          prefix?: string
          revoked_at?: string | null
          token_hash?: string
        }
        Relationships: []
      }
      assemblies: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          phase_hint: string | null
          unit: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          phase_hint?: string | null
          unit?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          phase_hint?: string | null
          unit?: string
        }
        Relationships: []
      }
      assembly_components: {
        Row: {
          assembly_id: string
          cost_type: Database["public"]["Enums"]["cost_type"]
          description: string
          id: string
          quantity: number
          sort_order: number
          unit: string
          unit_cost_cents: number
        }
        Insert: {
          assembly_id: string
          cost_type?: Database["public"]["Enums"]["cost_type"]
          description: string
          id?: string
          quantity?: number
          sort_order?: number
          unit?: string
          unit_cost_cents?: number
        }
        Update: {
          assembly_id?: string
          cost_type?: Database["public"]["Enums"]["cost_type"]
          description?: string
          id?: string
          quantity?: number
          sort_order?: number
          unit?: string
          unit_cost_cents?: number
        }
        Relationships: [
          {
            foreignKeyName: "assembly_components_assembly_id_fkey"
            columns: ["assembly_id"]
            isOneToOne: false
            referencedRelation: "assemblies"
            referencedColumns: ["id"]
          },
        ]
      }
      cost_library_items: {
        Row: {
          cost_type: Database["public"]["Enums"]["cost_type"]
          created_at: string
          default_multiplier: number | null
          id: string
          method: Database["public"]["Enums"]["estimate_method"]
          method_subtype: string
          name: string
          phase_hint: string | null
          unit_cost_cents: number
        }
        Insert: {
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          default_multiplier?: number | null
          id?: string
          method?: Database["public"]["Enums"]["estimate_method"]
          method_subtype?: string
          name: string
          phase_hint?: string | null
          unit_cost_cents?: number
        }
        Update: {
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          default_multiplier?: number | null
          id?: string
          method?: Database["public"]["Enums"]["estimate_method"]
          method_subtype?: string
          name?: string
          phase_hint?: string | null
          unit_cost_cents?: number
        }
        Relationships: []
      }
      daily_log_photos: {
        Row: {
          created_at: string
          file_name: string
          file_path: string
          id: string
          label: string | null
          log_id: string
          mime_type: string | null
          size_bytes: number
        }
        Insert: {
          created_at?: string
          file_name: string
          file_path: string
          id?: string
          label?: string | null
          log_id: string
          mime_type?: string | null
          size_bytes?: number
        }
        Update: {
          created_at?: string
          file_name?: string
          file_path?: string
          id?: string
          label?: string | null
          log_id?: string
          mime_type?: string | null
          size_bytes?: number
        }
        Relationships: [
          {
            foreignKeyName: "daily_log_photos_log_id_fkey"
            columns: ["log_id"]
            isOneToOne: false
            referencedRelation: "daily_logs"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_logs: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          job_id: string
          log_date: string
          notes: string | null
          updated_at: string
          weather: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          job_id: string
          log_date: string
          notes?: string | null
          updated_at?: string
          weather?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          job_id?: string
          log_date?: string
          notes?: string | null
          updated_at?: string
          weather?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "daily_logs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      draw_attachments: {
        Row: {
          category: string
          created_at: string
          draw_id: string
          file_name: string
          file_path: string
          id: string
          job_id: string
          label: string
          mime_type: string | null
          size_bytes: number
        }
        Insert: {
          category?: string
          created_at?: string
          draw_id: string
          file_name: string
          file_path: string
          id?: string
          job_id: string
          label?: string
          mime_type?: string | null
          size_bytes?: number
        }
        Update: {
          category?: string
          created_at?: string
          draw_id?: string
          file_name?: string
          file_path?: string
          id?: string
          job_id?: string
          label?: string
          mime_type?: string | null
          size_bytes?: number
        }
        Relationships: [
          {
            foreignKeyName: "draw_attachments_draw_id_fkey"
            columns: ["draw_id"]
            isOneToOne: false
            referencedRelation: "draw_requests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "draw_attachments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      draw_requests: {
        Row: {
          amount_requested_cents: number
          created_at: string
          id: string
          job_id: string
          notes: string | null
          number: number
          period_to: string | null
          retainage_cents: number
          schedule_id: string
          snapshot: Json
          status: Database["public"]["Enums"]["draw_status"]
          updated_at: string
        }
        Insert: {
          amount_requested_cents?: number
          created_at?: string
          id?: string
          job_id: string
          notes?: string | null
          number?: number
          period_to?: string | null
          retainage_cents?: number
          schedule_id: string
          snapshot?: Json
          status?: Database["public"]["Enums"]["draw_status"]
          updated_at?: string
        }
        Update: {
          amount_requested_cents?: number
          created_at?: string
          id?: string
          job_id?: string
          notes?: string | null
          number?: number
          period_to?: string | null
          retainage_cents?: number
          schedule_id?: string
          snapshot?: Json
          status?: Database["public"]["Enums"]["draw_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "draw_requests_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "draw_requests_schedule_id_fkey"
            columns: ["schedule_id"]
            isOneToOne: false
            referencedRelation: "payment_schedules"
            referencedColumns: ["id"]
          },
        ]
      }
      estimate_line_items: {
        Row: {
          cost_type: Database["public"]["Enums"]["cost_type"]
          created_at: string
          description: string
          id: string
          method: Database["public"]["Enums"]["estimate_method"]
          method_subtype: string
          multiplier: number | null
          notes: string | null
          phase_id: string
          quantity: number
          sort_order: number
          unit_cost_cents: number
          updated_at: string
          vendor: string | null
        }
        Insert: {
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          description?: string
          id?: string
          method?: Database["public"]["Enums"]["estimate_method"]
          method_subtype?: string
          multiplier?: number | null
          notes?: string | null
          phase_id: string
          quantity?: number
          sort_order?: number
          unit_cost_cents?: number
          updated_at?: string
          vendor?: string | null
        }
        Update: {
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          description?: string
          id?: string
          method?: Database["public"]["Enums"]["estimate_method"]
          method_subtype?: string
          multiplier?: number | null
          notes?: string | null
          phase_id?: string
          quantity?: number
          sort_order?: number
          unit_cost_cents?: number
          updated_at?: string
          vendor?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "estimate_line_items_phase_id_fkey"
            columns: ["phase_id"]
            isOneToOne: false
            referencedRelation: "estimate_phases"
            referencedColumns: ["id"]
          },
        ]
      }
      estimate_phases: {
        Row: {
          created_at: string
          default_multiplier: number | null
          duration_days: number | null
          estimate_id: string
          id: string
          name: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          default_multiplier?: number | null
          duration_days?: number | null
          estimate_id: string
          id?: string
          name: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          default_multiplier?: number | null
          duration_days?: number | null
          estimate_id?: string
          id?: string
          name?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "estimate_phases_estimate_id_fkey"
            columns: ["estimate_id"]
            isOneToOne: false
            referencedRelation: "estimates"
            referencedColumns: ["id"]
          },
        ]
      }
      estimates: {
        Row: {
          created_at: string
          default_multiplier: number
          id: string
          job_id: string
          margin_floor: number
          name: string
          status: string
          target_margin: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          default_multiplier?: number
          id?: string
          job_id: string
          margin_floor?: number
          name?: string
          status?: string
          target_margin?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          default_multiplier?: number
          id?: string
          job_id?: string
          margin_floor?: number
          name?: string
          status?: string
          target_margin?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "estimates_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      integration_secrets: {
        Row: {
          access_token: string | null
          expires_at: string | null
          provider: string
          realm_id: string | null
          refresh_token: string | null
          updated_at: string
        }
        Insert: {
          access_token?: string | null
          expires_at?: string | null
          provider: string
          realm_id?: string | null
          refresh_token?: string | null
          updated_at?: string
        }
        Update: {
          access_token?: string | null
          expires_at?: string | null
          provider?: string
          realm_id?: string | null
          refresh_token?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      integrations: {
        Row: {
          config: Json
          connected_at: string | null
          created_at: string
          id: string
          provider: string
          status: string
          updated_at: string
        }
        Insert: {
          config?: Json
          connected_at?: string | null
          created_at?: string
          id?: string
          provider: string
          status?: string
          updated_at?: string
        }
        Update: {
          config?: Json
          connected_at?: string | null
          created_at?: string
          id?: string
          provider?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      job_costs: {
        Row: {
          amount_cents: number
          cost_type: Database["public"]["Enums"]["cost_type"]
          created_at: string
          created_by: string | null
          description: string | null
          external_ref: string | null
          id: string
          incurred_on: string
          job_id: string
          line_item_id: string | null
          phase_id: string | null
          source: string
          updated_at: string
          vendor: string | null
        }
        Insert: {
          amount_cents?: number
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          created_by?: string | null
          description?: string | null
          external_ref?: string | null
          id?: string
          incurred_on?: string
          job_id: string
          line_item_id?: string | null
          phase_id?: string | null
          source?: string
          updated_at?: string
          vendor?: string | null
        }
        Update: {
          amount_cents?: number
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          created_by?: string | null
          description?: string | null
          external_ref?: string | null
          id?: string
          incurred_on?: string
          job_id?: string
          line_item_id?: string | null
          phase_id?: string | null
          source?: string
          updated_at?: string
          vendor?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_costs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_costs_line_item_id_fkey"
            columns: ["line_item_id"]
            isOneToOne: false
            referencedRelation: "estimate_line_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_costs_phase_id_fkey"
            columns: ["phase_id"]
            isOneToOne: false
            referencedRelation: "estimate_phases"
            referencedColumns: ["id"]
          },
        ]
      }
      jobs: {
        Row: {
          address: string | null
          client_name: string | null
          contingency_percent: number
          contract_amount_cents: number
          contract_type: Database["public"]["Enums"]["contract_type"]
          created_at: string
          created_by: string | null
          fee_percent: number
          fee_style: Database["public"]["Enums"]["fee_style"]
          id: string
          job_type: Database["public"]["Enums"]["job_type"]
          margin_floor: number
          name: string
          notes: string | null
          schedule_notes: string | null
          stage: Database["public"]["Enums"]["job_stage"]
          start_date: string | null
          target_end_date: string | null
          target_margin: number
          updated_at: string
        }
        Insert: {
          address?: string | null
          client_name?: string | null
          contingency_percent?: number
          contract_amount_cents?: number
          contract_type?: Database["public"]["Enums"]["contract_type"]
          created_at?: string
          created_by?: string | null
          fee_percent?: number
          fee_style?: Database["public"]["Enums"]["fee_style"]
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          margin_floor?: number
          name: string
          notes?: string | null
          schedule_notes?: string | null
          stage?: Database["public"]["Enums"]["job_stage"]
          start_date?: string | null
          target_end_date?: string | null
          target_margin?: number
          updated_at?: string
        }
        Update: {
          address?: string | null
          client_name?: string | null
          contingency_percent?: number
          contract_amount_cents?: number
          contract_type?: Database["public"]["Enums"]["contract_type"]
          created_at?: string
          created_by?: string | null
          fee_percent?: number
          fee_style?: Database["public"]["Enums"]["fee_style"]
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          margin_floor?: number
          name?: string
          notes?: string | null
          schedule_notes?: string | null
          stage?: Database["public"]["Enums"]["job_stage"]
          start_date?: string | null
          target_end_date?: string | null
          target_margin?: number
          updated_at?: string
        }
        Relationships: []
      }
      payment_item_phases: {
        Row: {
          id: string
          item_id: string
          phase_id: string
        }
        Insert: {
          id?: string
          item_id: string
          phase_id: string
        }
        Update: {
          id?: string
          item_id?: string
          phase_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_item_phases_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "payment_schedule_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_item_phases_phase_id_fkey"
            columns: ["phase_id"]
            isOneToOne: false
            referencedRelation: "estimate_phases"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_schedule_items: {
        Row: {
          completed_previous_cents: number
          completed_this_period_cents: number
          created_at: string
          due_date: string | null
          external_ref: string | null
          id: string
          is_contingency: boolean
          is_fee: boolean
          materials_stored_cents: number
          name: string
          notes: string | null
          percent_of_contract: number | null
          retainage_percent: number | null
          schedule_id: string
          scheduled_value_cents: number
          sort_order: number
          trigger: Database["public"]["Enums"]["payment_trigger"]
          updated_at: string
        }
        Insert: {
          completed_previous_cents?: number
          completed_this_period_cents?: number
          created_at?: string
          due_date?: string | null
          external_ref?: string | null
          id?: string
          is_contingency?: boolean
          is_fee?: boolean
          materials_stored_cents?: number
          name?: string
          notes?: string | null
          percent_of_contract?: number | null
          retainage_percent?: number | null
          schedule_id: string
          scheduled_value_cents?: number
          sort_order?: number
          trigger?: Database["public"]["Enums"]["payment_trigger"]
          updated_at?: string
        }
        Update: {
          completed_previous_cents?: number
          completed_this_period_cents?: number
          created_at?: string
          due_date?: string | null
          external_ref?: string | null
          id?: string
          is_contingency?: boolean
          is_fee?: boolean
          materials_stored_cents?: number
          name?: string
          notes?: string | null
          percent_of_contract?: number | null
          retainage_percent?: number | null
          schedule_id?: string
          scheduled_value_cents?: number
          sort_order?: number
          trigger?: Database["public"]["Enums"]["payment_trigger"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_schedule_items_schedule_id_fkey"
            columns: ["schedule_id"]
            isOneToOne: false
            referencedRelation: "payment_schedules"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_schedules: {
        Row: {
          approved_at: string | null
          basis: Database["public"]["Enums"]["schedule_basis"]
          contract_total_cents: number
          contract_type: Database["public"]["Enums"]["contract_type"]
          created_at: string
          deposit_cents: number
          estimate_id: string
          id: string
          job_id: string
          retainage_percent: number
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          basis?: Database["public"]["Enums"]["schedule_basis"]
          contract_total_cents?: number
          contract_type?: Database["public"]["Enums"]["contract_type"]
          created_at?: string
          deposit_cents?: number
          estimate_id: string
          id?: string
          job_id: string
          retainage_percent?: number
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          basis?: Database["public"]["Enums"]["schedule_basis"]
          contract_total_cents?: number
          contract_type?: Database["public"]["Enums"]["contract_type"]
          created_at?: string
          deposit_cents?: number
          estimate_id?: string
          id?: string
          job_id?: string
          retainage_percent?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_schedules_estimate_id_fkey"
            columns: ["estimate_id"]
            isOneToOne: false
            referencedRelation: "estimates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_schedules_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      qb_transactions: {
        Row: {
          account_name: string | null
          amount_cents: number
          created_at: string
          doc_number: string | null
          id: string
          job_id: string | null
          matched_cost_id: string | null
          memo: string | null
          qb_customer: string | null
          qb_id: string
          qb_type: string
          raw: Json
          status: string
          txn_date: string
          updated_at: string
          vendor: string | null
        }
        Insert: {
          account_name?: string | null
          amount_cents: number
          created_at?: string
          doc_number?: string | null
          id?: string
          job_id?: string | null
          matched_cost_id?: string | null
          memo?: string | null
          qb_customer?: string | null
          qb_id: string
          qb_type: string
          raw?: Json
          status?: string
          txn_date: string
          updated_at?: string
          vendor?: string | null
        }
        Update: {
          account_name?: string | null
          amount_cents?: number
          created_at?: string
          doc_number?: string | null
          id?: string
          job_id?: string | null
          matched_cost_id?: string | null
          memo?: string | null
          qb_customer?: string | null
          qb_id?: string
          qb_type?: string
          raw?: Json
          status?: string
          txn_date?: string
          updated_at?: string
          vendor?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "qb_transactions_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "qb_transactions_matched_cost_id_fkey"
            columns: ["matched_cost_id"]
            isOneToOne: false
            referencedRelation: "job_costs"
            referencedColumns: ["id"]
          },
        ]
      }
      selection_library_items: {
        Row: {
          category: string | null
          created_at: string
          default_allowance_cents: number
          id: string
          job_type: Database["public"]["Enums"]["job_type"]
          name: string
          phase_hint: string | null
          room: string | null
          sort_order: number
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          default_allowance_cents?: number
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          name: string
          phase_hint?: string | null
          room?: string | null
          sort_order?: number
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          default_allowance_cents?: number
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          name?: string
          phase_hint?: string | null
          room?: string | null
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      selections: {
        Row: {
          actual_cents: number | null
          allowance_cents: number
          created_at: string
          due_before_phase_id: string | null
          id: string
          job_id: string
          line_item_id: string | null
          name: string
          notes: string | null
          room: string | null
          sort_order: number
          status: Database["public"]["Enums"]["selection_status"]
          updated_at: string
          vendor: string | null
        }
        Insert: {
          actual_cents?: number | null
          allowance_cents?: number
          created_at?: string
          due_before_phase_id?: string | null
          id?: string
          job_id: string
          line_item_id?: string | null
          name: string
          notes?: string | null
          room?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["selection_status"]
          updated_at?: string
          vendor?: string | null
        }
        Update: {
          actual_cents?: number | null
          allowance_cents?: number
          created_at?: string
          due_before_phase_id?: string | null
          id?: string
          job_id?: string
          line_item_id?: string | null
          name?: string
          notes?: string | null
          room?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["selection_status"]
          updated_at?: string
          vendor?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "selections_due_before_phase_id_fkey"
            columns: ["due_before_phase_id"]
            isOneToOne: false
            referencedRelation: "estimate_phases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "selections_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "selections_line_item_id_fkey"
            columns: ["line_item_id"]
            isOneToOne: false
            referencedRelation: "estimate_line_items"
            referencedColumns: ["id"]
          },
        ]
      }
      sequence_templates: {
        Row: {
          id: string
          job_type: Database["public"]["Enums"]["job_type"]
          name: string
          sort_order: number
        }
        Insert: {
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          name: string
          sort_order?: number
        }
        Update: {
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          name?: string
          sort_order?: number
        }
        Relationships: []
      }
      sub_bid_attachments: {
        Row: {
          created_at: string
          file_name: string
          file_path: string
          id: string
          mime_type: string | null
          request_id: string
          size_bytes: number
        }
        Insert: {
          created_at?: string
          file_name: string
          file_path: string
          id?: string
          mime_type?: string | null
          request_id: string
          size_bytes?: number
        }
        Update: {
          created_at?: string
          file_name?: string
          file_path?: string
          id?: string
          mime_type?: string | null
          request_id?: string
          size_bytes?: number
        }
        Relationships: [
          {
            foreignKeyName: "sub_bid_attachments_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "sub_bid_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      sub_bid_requests: {
        Row: {
          contact: string | null
          created_at: string
          created_by: string | null
          details: string
          due_date: string | null
          exclusions: string
          id: string
          job_id: string
          materials: string
          notes: string
          phase_id: string | null
          snapshot: Json
          specs: string
          trade_name: string
          updated_at: string
        }
        Insert: {
          contact?: string | null
          created_at?: string
          created_by?: string | null
          details?: string
          due_date?: string | null
          exclusions?: string
          id?: string
          job_id: string
          materials?: string
          notes?: string
          phase_id?: string | null
          snapshot?: Json
          specs?: string
          trade_name: string
          updated_at?: string
        }
        Update: {
          contact?: string | null
          created_at?: string
          created_by?: string | null
          details?: string
          due_date?: string | null
          exclusions?: string
          id?: string
          job_id?: string
          materials?: string
          notes?: string
          phase_id?: string | null
          snapshot?: Json
          specs?: string
          trade_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_bid_requests_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sub_bid_requests_phase_id_fkey"
            columns: ["phase_id"]
            isOneToOne: false
            referencedRelation: "estimate_phases"
            referencedColumns: ["id"]
          },
        ]
      }
      sub_bid_responses: {
        Row: {
          amount_cents: number
          awarded: boolean
          created_at: string
          id: string
          notes: string | null
          received_on: string | null
          request_id: string
          status: string
          sub_name: string
          updated_at: string
        }
        Insert: {
          amount_cents?: number
          awarded?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          received_on?: string | null
          request_id: string
          status?: string
          sub_name?: string
          updated_at?: string
        }
        Update: {
          amount_cents?: number
          awarded?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          received_on?: string | null
          request_id?: string
          status?: string
          sub_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_bid_responses_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "sub_bid_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      template_phases: {
        Row: {
          id: string
          name: string
          sort_order: number
          template_id: string
        }
        Insert: {
          id?: string
          name: string
          sort_order?: number
          template_id: string
        }
        Update: {
          id?: string
          name?: string
          sort_order?: number
          template_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "template_phases_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "sequence_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "owner" | "pm" | "lead" | "admin"
      contract_type: "fixed_price" | "cost_plus"
      cost_type: "labor" | "material" | "sub" | "equipment" | "other"
      draw_status: "draft" | "sent" | "paid"
      estimate_method:
        | "square_foot"
        | "unit_cost"
        | "assembly"
        | "allowance"
        | "sub_bid"
        | "labor"
      fee_style: "percent_of_cost" | "line_multipliers"
      job_stage:
        | "lead"
        | "estimating"
        | "proposal_sent"
        | "contracted"
        | "pre_con"
        | "production"
        | "punch"
        | "closeout"
      job_type:
        | "kitchen_remodel"
        | "bath_remodel"
        | "whole_house_remodel"
        | "addition"
        | "custom_home"
        | "adu_garage"
        | "exterior_only"
        | "other"
      payment_trigger:
        | "on_signing"
        | "phase_start"
        | "phase_complete"
        | "date"
        | "progress"
      schedule_basis: "per_phase" | "combined" | "equal_percent"
      selection_status: "pending" | "decided" | "ordered"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "pm", "lead", "admin"],
      contract_type: ["fixed_price", "cost_plus"],
      cost_type: ["labor", "material", "sub", "equipment", "other"],
      draw_status: ["draft", "sent", "paid"],
      estimate_method: [
        "square_foot",
        "unit_cost",
        "assembly",
        "allowance",
        "sub_bid",
        "labor",
      ],
      fee_style: ["percent_of_cost", "line_multipliers"],
      job_stage: [
        "lead",
        "estimating",
        "proposal_sent",
        "contracted",
        "pre_con",
        "production",
        "punch",
        "closeout",
      ],
      job_type: [
        "kitchen_remodel",
        "bath_remodel",
        "whole_house_remodel",
        "addition",
        "custom_home",
        "adu_garage",
        "exterior_only",
        "other",
      ],
      payment_trigger: [
        "on_signing",
        "phase_start",
        "phase_complete",
        "date",
        "progress",
      ],
      schedule_basis: ["per_phase", "combined", "equal_percent"],
      selection_status: ["pending", "decided", "ordered"],
    },
  },
} as const
