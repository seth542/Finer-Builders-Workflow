import mark from "@/assets/finer-mark.png.asset.json";
import horizontal from "@/assets/finer-horizontal.png.asset.json";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <img
      src={mark.url}
      alt="Finer Builders"
      className={cn("h-7 w-7 rounded-full object-contain", className)}
    />
  );
}

export function LogoHorizontal({ className }: { className?: string }) {
  return (
    <img
      src={horizontal.url}
      alt="Finer Builders"
      className={cn("h-12 w-auto object-contain", className)}
    />
  );
}
