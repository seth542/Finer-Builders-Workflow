import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { TablesUpdate } from "@/integrations/supabase/types";
import { linesQuery, subBidRequestsQuery, subBidResponsesQuery } from "@/lib/queries";
import { lineCostCents } from "@/lib/estimate-math";
import { formatDate, money, parseMoneyToCents } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Printer, Copy, Trash2, Award, Paperclip, Download } from "lucide-react";
import { toast } from "sonner";
import {
  bidRequestToText,
  printBidRequest,
  parseMaterials,
  type BidRequestDoc,
} from "@/lib/bid-request";

type SnapshotItem = { id?: string; description: string; scope: string };

const STATUSES = ["received", "declined", "no_bid"] as const;
const statusLabel = (s: string) =>
  s === "no_bid" ? "No bid" : s === "declined" ? "Declined" : "Received";

export function SubBidRequestList({
  jobId,
  estimateId,
  jobName,
  jobAddress,
  startDate,
}: {
  jobId: string;
  estimateId: string;
  jobName: string;
  jobAddress: string | null;
  startDate: string | null;
}) {
  const qc = useQueryClient();
  const requests = useQuery(subBidRequestsQuery(jobId));
  const responses = useQuery(subBidResponsesQuery(jobId));
  const lines = useQuery(linesQuery(estimateId));
  const [amountDraft, setAmountDraft] = useState<Record<string, string>>({});
  const attachments = useQuery({
    queryKey: ["sub-bid-attachments", jobId],
    queryFn: async () => {
      const { data: reqs, error: re } = await supabase
        .from("sub_bid_requests")
        .select("id")
        .eq("job_id", jobId);
      if (re) throw re;
      const ids = (reqs ?? []).map((r) => r.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from("sub_bid_attachments")
        .select("*")
        .in("request_id", ids)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

  const photoUrls = useQuery({
    queryKey: ["sub-bid-photo-urls", jobId, (attachments.data ?? []).length],
    queryFn: async () => {
      const paths = (attachments.data ?? [])
        .filter((a) => a.mime_type?.startsWith("image/"))
        .map((a) => a.file_path);
      if (paths.length === 0) return {} as Record<string, string>;
      const { data, error } = await supabase.storage
        .from("sub-bid-files")
        .createSignedUrls(paths, 60 * 60);
      if (error) throw error;
      const map: Record<string, string> = {};
      for (const row of data ?? []) if (row.path && row.signedUrl) map[row.path] = row.signedUrl;
      return map;
    },
    enabled: (attachments.data ?? []).length > 0,
  });

  const openFile = async (path: string) => {
    const { data, error } = await supabase.storage
      .from("sub-bid-files")
      .createSignedUrl(path, 60 * 10);
    if (error || !data) {
      toast.error("Could not open file");
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  const uploadFiles = useMutation({
    mutationFn: async ({ requestId, files }: { requestId: string; files: File[] }) => {
      for (const f of files) {
        const path = `${jobId}/${requestId}/${Date.now()}-${f.name}`;
        const { error: ue } = await supabase.storage.from("sub-bid-files").upload(path, f);
        if (ue) throw ue;
        const { error } = await supabase.from("sub_bid_attachments").insert({
          request_id: requestId,
          file_name: f.name,
          file_path: path,
          mime_type: f.type || null,
          size_bytes: f.size,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["sub-bid-attachments", jobId] });
      toast.success("Files attached");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not attach files"),
  });

  const removeFile = useMutation({
    mutationFn: async ({ id, path }: { id: string; path: string }) => {
      await supabase.storage.from("sub-bid-files").remove([path]);
      const { error } = await supabase.from("sub_bid_attachments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["sub-bid-attachments", jobId] }),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not remove file"),
  });

  const costById = useMemo(() => {
    const m: Record<string, number> = {};
    for (const l of lines.data ?? []) m[l.id] = lineCostCents(l);
    return m;
  }, [lines.data]);

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["sub-bid-requests", jobId] });
    void qc.invalidateQueries({ queryKey: ["sub-bid-responses", jobId] });
  };

  const removeRequest = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("sub_bid_requests").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Bid request deleted");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not delete"),
  });

  const addBid = useMutation({
    mutationFn: async (requestId: string) => {
      const { error } = await supabase
        .from("sub_bid_responses")
        .insert({ request_id: requestId, sub_name: "", amount_cents: 0 });
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add bid"),
  });

  const updateBid = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: TablesUpdate<"sub_bid_responses"> }) => {
      const { error } = await supabase.from("sub_bid_responses").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save bid"),
  });

  const removeBid = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("sub_bid_responses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not remove bid"),
  });

  const award = useMutation({
    mutationFn: async ({ requestId, id }: { requestId: string; id: string }) => {
      const { error: clear } = await supabase
        .from("sub_bid_responses")
        .update({ awarded: false })
        .eq("request_id", requestId);
      if (clear) throw clear;
      const { error } = await supabase
        .from("sub_bid_responses")
        .update({ awarded: true })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Bid awarded");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not award bid"),
  });

  const list = requests.data ?? [];
  if (list.length === 0) return null;

  return (
    <div className="space-y-3">
      <div>
        <h3 className="font-display text-lg">Sub bid requests</h3>
        <p className="text-sm text-muted-foreground">
          Every request you saved, with the bids that came back. Log each sub and amount to compare
          against the estimated cost of that scope.
        </p>
      </div>

      {list.map((r) => {
        const items = (Array.isArray(r.snapshot) ? r.snapshot : []) as SnapshotItem[];
        const doc: BidRequestDoc = {
          jobName,
          jobAddress: jobAddress ?? "",
          tradeName: r.trade_name,
          items: items.map((i) => ({ description: i.description, scope: i.scope ?? "" })),
          notes: r.notes ?? "",
          exclusions: r.exclusions ?? "",
          dueDate: r.due_date ?? "",
          contact: r.contact ?? "",
          startDate: startDate ?? "",
          specs: r.specs ?? "",
          materials: r.materials ?? "",
          details: r.details ?? "",
          attachments: (attachments.data ?? [])
            .filter((a) => a.request_id === r.id)
            .map((a) => a.file_name),
        };
        const allAttached = (attachments.data ?? []).filter((a) => a.request_id === r.id);
        const photos = allAttached.filter((a) => a.mime_type?.startsWith("image/"));
        const files = allAttached.filter((a) => !a.mime_type?.startsWith("image/"));
        const budget = items.reduce((s, i) => s + (i.id ? (costById[i.id] ?? 0) : 0), 0);
        const bids = (responses.data ?? []).filter((b) => b.request_id === r.id);
        const real = bids.filter((b) => b.status === "received" && b.amount_cents > 0);
        const amounts = real.map((b) => b.amount_cents);
        const low = amounts.length ? Math.min(...amounts) : 0;
        const high = amounts.length ? Math.max(...amounts) : 0;

        return (
          <div key={r.id} className="rounded-lg border">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b px-3 py-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{r.trade_name}</span>
                <span className="text-xs text-muted-foreground">
                  Saved {formatDate(r.created_at)} · {items.length} item
                  {items.length === 1 ? "" : "s"}
                  {r.due_date ? ` · due ${formatDate(r.due_date)}` : ""}
                </span>
                {r.specs?.trim() && <Badge variant="outline">Specs</Badge>}
                {r.materials?.trim() && <Badge variant="outline">Materials</Badge>}
                {r.details?.trim() && <Badge variant="outline">Details</Badge>}
                {photos.length > 0 && (
                  <Badge variant="outline">
                    {photos.length} photo{photos.length === 1 ? "" : "s"}
                  </Badge>
                )}
                <Badge variant="secondary" className="num">
                  {money(budget)} budget
                </Badge>
              </div>
              <div className="flex gap-1.5">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (!printBidRequest(doc)) toast.error("Allow pop-ups to print or save as PDF");
                  }}
                >
                  <Printer className="mr-1.5 h-3.5 w-3.5" /> Print
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    void navigator.clipboard
                      .writeText(bidRequestToText(doc))
                      .then(() => toast.success("Bid request copied"))
                      .catch(() => toast.error("Could not copy"));
                  }}
                >
                  <Copy className="mr-1.5 h-3.5 w-3.5" /> Copy
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeRequest.mutate(r.id)}
                  disabled={removeRequest.isPending}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            {r.materials?.trim() && (
              <div className="border-b px-3 py-2">
                <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                  Required materials
                </div>
                <ul className="mt-1 list-disc space-y-0.5 pl-4 text-sm">
                  {parseMaterials(r.materials).map((m, i) => (
                    <li key={i}>
                      {m.name}
                      {m.url && (
                        <>
                          {" — "}
                          <a
                            href={m.url}
                            target="_blank"
                            rel="noreferrer"
                            className="underline underline-offset-2"
                          >
                            link
                          </a>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
              {files.map((a) => (
                <span
                  key={a.id}
                  className="flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs"
                >
                  <Paperclip className="h-3 w-3 text-muted-foreground" />
                  <button
                    type="button"
                    className="underline-offset-2 hover:underline"
                    onClick={() => void openFile(a.file_path)}
                  >
                    {a.file_name}
                  </button>
                  <Download className="h-3 w-3 text-muted-foreground" />
                  <button
                    type="button"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => removeFile.mutate({ id: a.id, path: a.file_path })}
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </span>
              ))}
              <label className="cursor-pointer text-xs text-muted-foreground underline-offset-2 hover:underline">
                {files.length ? "Attach more" : "Attach site plan or details"}
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    const picked = Array.from(e.target.files ?? []);
                    if (picked.length) uploadFiles.mutate({ requestId: r.id, files: picked });
                    e.target.value = "";
                  }}
                />
              </label>
              {photos.length === 0 && (
                <label className="cursor-pointer text-xs text-muted-foreground underline-offset-2 hover:underline">
                  Add photos
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const picked = Array.from(e.target.files ?? []);
                      if (picked.length) uploadFiles.mutate({ requestId: r.id, files: picked });
                      e.target.value = "";
                    }}
                  />
                </label>
              )}
            </div>

            {photos.length > 0 && (
              <div className="flex flex-wrap gap-2 border-b px-3 py-2">
                {photos.map((a) => (
                  <div key={a.id} className="group relative">
                    <button
                      type="button"
                      onClick={() => void openFile(a.file_path)}
                      title={a.file_name}
                    >
                      <img
                        src={photoUrls.data?.[a.file_path] ?? ""}
                        alt={a.file_name}
                        loading="lazy"
                        className="h-16 w-16 rounded-md border object-cover"
                      />
                    </button>
                    <button
                      type="button"
                      className="absolute -right-1.5 -top-1.5 rounded-full border bg-background p-0.5 text-muted-foreground opacity-0 transition group-hover:opacity-100 hover:text-destructive"
                      onClick={() => removeFile.mutate({ id: a.id, path: a.file_path })}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                <label className="flex h-16 w-16 cursor-pointer items-center justify-center rounded-md border border-dashed text-muted-foreground hover:text-foreground">
                  <Plus className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const picked = Array.from(e.target.files ?? []);
                      if (picked.length) uploadFiles.mutate({ requestId: r.id, files: picked });
                      e.target.value = "";
                    }}
                  />
                </label>
              </div>
            )}

            <div className="space-y-2 px-3 py-2">
              <div className="grid gap-2 text-sm sm:grid-cols-[1.4fr_1fr_1fr_1fr_auto] sm:items-center">
                <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Sub</div>
                <div className="hidden text-xs uppercase tracking-[0.14em] text-muted-foreground sm:block">
                  Amount
                </div>
                <div className="hidden text-xs uppercase tracking-[0.14em] text-muted-foreground sm:block">
                  Received
                </div>
                <div className="hidden text-xs uppercase tracking-[0.14em] text-muted-foreground sm:block">
                  Status
                </div>
                <div />
              </div>

              {bids.map((b) => {
                const key = b.id;
                const amountValue =
                  amountDraft[key] ?? (b.amount_cents ? (b.amount_cents / 100).toFixed(2) : "");
                return (
                  <div
                    key={b.id}
                    className="grid gap-2 sm:grid-cols-[1.4fr_1fr_1fr_1fr_auto] sm:items-center"
                  >
                    <Input
                      defaultValue={b.sub_name}
                      placeholder="Sub name"
                      onBlur={(e) => {
                        if (e.target.value !== b.sub_name)
                          updateBid.mutate({ id: b.id, patch: { sub_name: e.target.value } });
                      }}
                    />
                    <Input
                      className="num"
                      value={amountValue}
                      placeholder="0.00"
                      onChange={(e) => setAmountDraft((p) => ({ ...p, [key]: e.target.value }))}
                      onBlur={(e) => {
                        const cents = parseMoneyToCents(e.target.value);
                        if (cents !== b.amount_cents)
                          updateBid.mutate({ id: b.id, patch: { amount_cents: cents } });
                      }}
                    />
                    <Input
                      type="date"
                      defaultValue={b.received_on ?? ""}
                      onChange={(e) =>
                        updateBid.mutate({
                          id: b.id,
                          patch: { received_on: e.target.value || null },
                        })
                      }
                    />
                    <Select
                      value={b.status}
                      onValueChange={(v) => updateBid.mutate({ id: b.id, patch: { status: v } })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUSES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {statusLabel(s)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex items-center gap-1">
                      {b.awarded ? (
                        <Badge className="whitespace-nowrap">Awarded</Badge>
                      ) : (
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Mark as awarded"
                          onClick={() => award.mutate({ requestId: r.id, id: b.id })}
                        >
                          <Award className="h-3.5 w-3.5" />
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" onClick={() => removeBid.mutate(b.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addBid.mutate(r.id)}
                  disabled={addBid.isPending}
                >
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add bid
                </Button>
                {real.length > 0 && (
                  <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span className="num">Low {money(low)}</span>
                    <span className="num">High {money(high)}</span>
                    <span className="num">Spread {money(high - low)}</span>
                    {budget > 0 && (
                      <span className={low > budget ? "num text-destructive" : "num"}>
                        {low > budget ? "Over" : "Under"} budget {money(Math.abs(low - budget))}
                      </span>
                    )}
                  </div>
                )}
                {real.length === 0 && (
                  <span className="text-xs text-muted-foreground">No bids logged yet.</span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
