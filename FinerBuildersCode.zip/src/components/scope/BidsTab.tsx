import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { linesQuery, phasesQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { FileText } from "lucide-react";
import { SubBidRequestDialog, type BidTrade } from "./SubBidRequestDialog";
import { SubBidRequestList } from "./SubBidRequestList";

export function BidsTab({
  jobId,
  estimateId,
  jobName,
  jobAddress,
  startDate,
}: {
  jobId: string;
  estimateId: string;
  jobName: string;
  jobAddress: string | null;
  startDate: string | null;
}) {
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const [bidOpen, setBidOpen] = useState(false);

  const trades: BidTrade[] = useMemo(
    () =>
      (phases.data ?? []).map((p) => ({
        id: p.id,
        name: p.name,
        items: (lines.data ?? [])
          .filter((l) => l.phase_id === p.id)
          .map((l) => ({ id: l.id, description: l.description, scope: l.notes })),
      })),
    [phases.data, lines.data],
  );

  if (!estimateId) {
    return (
      <div className="rounded-lg border border-dashed p-10 text-center text-sm text-muted-foreground">
        Create the estimate first — bid requests are built from the scope on its phases.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl">Bids</h2>
          <p className="text-sm text-muted-foreground">
            Send the same scope to every sub, then log the numbers as they come back.
          </p>
        </div>
        <Button size="sm" onClick={() => setBidOpen(true)} disabled={trades.length === 0}>
          <FileText className="mr-1.5 h-3.5 w-3.5" /> Create sub bid request
        </Button>
      </div>

      <SubBidRequestList
        jobId={jobId}
        estimateId={estimateId}
        jobName={jobName}
        jobAddress={jobAddress}
        startDate={startDate}
      />

      {bidOpen && (
        <SubBidRequestDialog
          open={bidOpen}
          onOpenChange={setBidOpen}
          jobId={jobId}
          jobName={jobName}
          jobAddress={jobAddress}
          trades={trades}
          startDate={startDate}
        />
      )}
    </div>
  );
}
