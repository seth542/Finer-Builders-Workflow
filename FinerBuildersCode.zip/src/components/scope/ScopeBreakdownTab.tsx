import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { linesQuery, phasesQuery } from "@/lib/queries";
import { lineCostCents } from "@/lib/estimate-math";
import { money } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText } from "lucide-react";
import { toast } from "sonner";
import { SubBidRequestDialog, type BidTrade } from "./SubBidRequestDialog";

export function ScopeBreakdownTab({
  jobId,
  estimateId,
  jobName,
  jobAddress,
  startDate,
}: {
  jobId: string;
  estimateId: string;
  jobName: string;
  jobAddress: string | null;
  startDate: string | null;
}) {
  const qc = useQueryClient();
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const [bidOpen, setBidOpen] = useState(false);
  const [bidTradeId, setBidTradeId] = useState<string | undefined>(undefined);
  const [draft, setDraft] = useState<Record<string, string>>({});

  const saveScope = useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes: string }) => {
      const { error } = await supabase
        .from("estimate_line_items")
        .update({ notes: notes || null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["lines", estimateId] });
      toast.success("Scope saved");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save scope"),
  });

  const trades: BidTrade[] = useMemo(
    () =>
      (phases.data ?? []).map((p) => ({
        id: p.id,
        name: p.name,
        items: (lines.data ?? [])
          .filter((l) => l.phase_id === p.id)
          .map((l) => ({ id: l.id, description: l.description, scope: l.notes })),
      })),
    [phases.data, lines.data],
  );

  const costByPhase = (phaseId: string) =>
    (lines.data ?? [])
      .filter((l) => l.phase_id === phaseId)
      .reduce((s, l) => s + lineCostCents(l), 0);

  if (!estimateId) {
    return (
      <div className="rounded-lg border border-dashed p-10 text-center text-sm text-muted-foreground">
        Create the estimate first — the scope breaks out by the phases on it.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end sm:justify-between">
        <div className="min-w-0">
          <h2 className="font-display text-xl">Scope</h2>
          <p className="text-sm text-muted-foreground">
            Spell out the work by trade. Anything you write here travels straight onto the sub bid
            request so every quote covers the same scope.
          </p>
        </div>
        <Button
          size="sm"
          className="w-full sm:w-auto"
          onClick={() => {
            setBidTradeId(undefined);
            setBidOpen(true);
          }}
          disabled={trades.length === 0}
        >
          <FileText className="mr-1.5 h-3.5 w-3.5" /> Create sub bid request
        </Button>
      </div>

      <div className="space-y-3">
        {trades.map((t) => (
          <div key={t.id} className="rounded-lg border">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b px-3 py-2 sm:flex sm:flex-wrap sm:justify-between">
              <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
                <span className="min-w-0 truncate font-medium">{t.name}</span>
                <Badge variant="secondary" className="num">
                  {money(costByPhase(t.id))} cost
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {t.items.length} item{t.items.length === 1 ? "" : "s"}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="shrink-0"
                onClick={() => {
                  setBidTradeId(t.id);
                  setBidOpen(true);
                }}
                disabled={t.items.length === 0}
              >
                Sub bid request
              </Button>
            </div>
            <ul className="divide-y">
              {t.items.map((i) => {
                const value = draft[i.id] ?? i.scope ?? "";
                const dirty = value !== (i.scope ?? "");
                return (
                  <li key={i.id} className="grid gap-2 px-3 py-2 sm:grid-cols-[1fr_2fr]">
                    <div className="text-sm">{i.description}</div>
                    <div className="space-y-1.5">
                      <Textarea
                        rows={2}
                        placeholder="Scope of work — materials, who supplies what, standards, exclusions…"
                        value={value}
                        onChange={(e) => setDraft((p) => ({ ...p, [i.id]: e.target.value }))}
                      />
                      {dirty && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => saveScope.mutate({ id: i.id, notes: value })}
                            disabled={saveScope.isPending}
                          >
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDraft((p) => ({ ...p, [i.id]: i.scope ?? "" }))}
                          >
                            Reset
                          </Button>
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
              {t.items.length === 0 && (
                <li className="px-3 py-3 text-sm text-muted-foreground">
                  No estimate lines in this phase yet.
                </li>
              )}
            </ul>
          </div>
        ))}
      </div>

      {bidOpen && (
        <SubBidRequestDialog
          open={bidOpen}
          onOpenChange={setBidOpen}
          jobId={jobId}
          jobName={jobName}
          jobAddress={jobAddress}
          trades={trades}
          initialTradeId={bidTradeId}
          startDate={startDate}
        />
      )}
    </div>
  );
}
