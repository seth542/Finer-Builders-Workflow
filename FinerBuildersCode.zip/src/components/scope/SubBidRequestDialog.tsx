import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  printBidRequest,
  bidRequestToText,
  serializeMaterials,
  type MaterialEntry,
} from "@/lib/bid-request";

export type BidTrade = {
  id: string;
  name: string;
  items: { id: string; description: string; scope: string | null }[];
};

export function SubBidRequestDialog({
  open,
  onOpenChange,
  jobId,
  jobName,
  jobAddress,
  trades,
  initialTradeId,
  startDate,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  jobId: string;
  jobName: string;
  jobAddress: string | null;
  trades: BidTrade[];
  initialTradeId?: string | undefined;
  startDate?: string | null;
}) {
  const [tradeId, setTradeId] = useState(initialTradeId ?? trades[0]?.id ?? "");
  const trade = trades.find((t) => t.id === tradeId) ?? trades[0];
  const [excluded, setExcluded] = useState<Record<string, boolean>>({});
  const [dueDate, setDueDate] = useState("");
  const [contact, setContact] = useState("");
  const [specs, setSpecs] = useState("");
  const [materialList, setMaterialList] = useState<MaterialEntry[]>([{ name: "", url: "" }]);
  const materials = serializeMaterials(materialList);
  const [details, setDetails] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [photos, setPhotos] = useState<File[]>([]);
  const [panel, setPanel] = useState<"specs" | "materials" | "details" | "photos" | null>(null);
  const [notes, setNotes] = useState(
    "Include all labor, material, equipment, and cleanup unless noted. Verify field conditions before bidding.",
  );
  const [exclusions, setExclusions] = useState(
    "Permits, dumpsters, and finish material allowances by owner unless noted.",
  );

  const qc = useQueryClient();
  const items = (trade?.items ?? []).filter((i) => !excluded[i.id]);

  const saveRequest = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("sub_bid_requests")
        .insert({
          job_id: jobId,
          phase_id: trade?.id ?? null,
          trade_name: trade?.name ?? "",
          notes,
          exclusions,
          due_date: dueDate || null,
          specs,
          materials,
          details,
          contact: contact || null,
          snapshot: items.map((i) => ({
            id: i.id,
            description: i.description,
            scope: i.scope ?? "",
          })),
        })
        .select("id")
        .single();
      if (error) throw error;
      for (const f of [...files, ...photos]) {
        const path = `${jobId}/${data.id}/${Date.now()}-${f.name}`;
        const { error: ue } = await supabase.storage.from("sub-bid-files").upload(path, f);
        if (ue) throw ue;
        const { error: ae } = await supabase.from("sub_bid_attachments").insert({
          request_id: data.id,
          file_name: f.name,
          file_path: path,
          mime_type: f.type || null,
          size_bytes: f.size,
        });
        if (ae) throw ae;
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["sub-bid-requests", jobId] });
      toast.success("Bid request saved — log bids at the bottom of Scope breakdown");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save request"),
  });

  const doc = {
    jobName,
    jobAddress: jobAddress ?? "",
    tradeName: trade?.name ?? "",
    items: items.map((i) => ({ description: i.description, scope: i.scope ?? "" })),
    notes,
    exclusions,
    dueDate,
    contact,
    startDate: startDate ?? "",
    specs,
    materials,
    details,
    attachments: [...files, ...photos].map((f) => f.name),
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create sub bid request</DialogTitle>
          <DialogDescription>
            Build a scope-of-work document for one trade, then send the same document to three subs
            so the quotes come back apples to apples.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-2">
            <Label>Trade</Label>
            <div className="flex flex-wrap gap-1.5">
              {trades.map((t) => (
                <Button
                  key={t.id}
                  type="button"
                  size="sm"
                  variant={t.id === tradeId ? "default" : "outline"}
                  onClick={() => setTradeId(t.id)}
                >
                  {t.name}
                </Button>
              ))}
            </div>
          </div>

          <div className="overflow-hidden rounded-md border">
            <div className="border-b bg-muted/40 px-3 py-2 text-xs uppercase tracking-[0.14em] text-muted-foreground">
              Scope items — uncheck anything the sub is not bidding
            </div>
            <ul className="max-h-56 divide-y overflow-y-auto text-sm">
              {(trade?.items ?? []).map((i) => (
                <li key={i.id} className="flex items-start gap-2 px-3 py-2">
                  <Checkbox
                    checked={!excluded[i.id]}
                    onCheckedChange={(v) =>
                      setExcluded((prev) => ({ ...prev, [i.id]: v !== true }))
                    }
                  />
                  <div>
                    <div>{i.description}</div>
                    {i.scope && <div className="text-xs text-muted-foreground">{i.scope}</div>}
                  </div>
                </li>
              ))}
              {(trade?.items ?? []).length === 0 && (
                <li className="px-3 py-4 text-muted-foreground">
                  No scope items in this trade yet.
                </li>
              )}
            </ul>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Bids due</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Send bids to</Label>
              <Input
                value={contact}
                placeholder="Name / email"
                onChange={(e) => setContact(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap gap-1.5">
              <Button
                type="button"
                size="sm"
                variant={panel === "specs" ? "default" : "outline"}
                onClick={() => setPanel(panel === "specs" ? null : "specs")}
              >
                Specs{specs.trim() ? " ✓" : ""}
              </Button>
              <Button
                type="button"
                size="sm"
                variant={panel === "materials" ? "default" : "outline"}
                onClick={() => setPanel(panel === "materials" ? null : "materials")}
              >
                Materials{materials.trim() ? " ✓" : ""}
              </Button>
              <Button
                type="button"
                size="sm"
                variant={panel === "details" ? "default" : "outline"}
                onClick={() => setPanel(panel === "details" ? null : "details")}
              >
                Details{details.trim() || files.length ? " ✓" : ""}
              </Button>
              <Button
                type="button"
                size="sm"
                variant={panel === "photos" ? "default" : "outline"}
                onClick={() => setPanel(panel === "photos" ? null : "photos")}
              >
                Photos{photos.length ? " ✓" : ""}
              </Button>
            </div>
            {panel === "specs" && (
              <div className="space-y-1.5">
                <Label>Specs & measurements</Label>
                <Textarea
                  rows={4}
                  value={specs}
                  placeholder={
                    "Square footages, linear footages, ceiling heights, counts, etc.\ne.g. Drywall: 2,450 sf board, 18 lf soffit, 9' ceilings"
                  }
                  onChange={(e) => setSpecs(e.target.value)}
                />
              </div>
            )}
            {panel === "materials" && (
              <div className="space-y-2">
                <Label>Required materials</Label>
                <div className="space-y-2">
                  {materialList.map((m, idx) => (
                    <div key={idx} className="flex gap-2">
                      <Input
                        className="flex-1"
                        value={m.name}
                        placeholder={'Material — e.g. 5/8" Type X board, Level 5 finish'}
                        onChange={(e) =>
                          setMaterialList((prev) =>
                            prev.map((x, i) => (i === idx ? { ...x, name: e.target.value } : x)),
                          )
                        }
                      />
                      <Input
                        className="flex-1"
                        value={m.url}
                        placeholder="Link (product page or photo)"
                        onChange={(e) =>
                          setMaterialList((prev) =>
                            prev.map((x, i) => (i === idx ? { ...x, url: e.target.value } : x)),
                          )
                        }
                      />
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          setMaterialList((prev) =>
                            prev.length === 1
                              ? [{ name: "", url: "" }]
                              : prev.filter((_, i) => i !== idx),
                          )
                        }
                      >
                        ✕
                      </Button>
                    </div>
                  ))}
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => setMaterialList((prev) => [...prev, { name: "", url: "" }])}
                >
                  Add material
                </Button>
              </div>
            )}
            {panel === "details" && (
              <div className="space-y-2">
                <div className="space-y-1.5">
                  <Label>Details</Label>
                  <Textarea
                    rows={4}
                    value={details}
                    placeholder="How you want the work performed, sequencing, site rules, anything else the sub should know"
                    onChange={(e) => setDetails(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Attach files (site plans, drawings, cut sheets)</Label>
                  <Input
                    type="file"
                    multiple
                    onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
                  />
                  {files.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      {files.map((f) => f.name).join(", ")} — uploaded when you save the request.
                    </p>
                  )}
                </div>
              </div>
            )}
            {panel === "photos" && (
              <div className="space-y-1.5">
                <Label>Site photos</Label>
                <Input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => setPhotos(Array.from(e.target.files ?? []))}
                />
                <p className="text-xs text-muted-foreground">
                  {photos.length
                    ? `${photos.length} photo${photos.length === 1 ? "" : "s"} — uploaded when you save the request.`
                    : "Existing conditions, access, demo areas — anything the sub should see before bidding."}
                </p>
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>General requirements</Label>
            <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Exclusions</Label>
            <Textarea rows={2} value={exclusions} onChange={(e) => setExclusions(e.target.value)} />
          </div>
        </div>

        <DialogFooter className="flex-wrap gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button
            variant="outline"
            onClick={() => saveRequest.mutate()}
            disabled={items.length === 0 || saveRequest.isPending}
          >
            Save request
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              void navigator.clipboard
                .writeText(bidRequestToText(doc))
                .then(() => toast.success("Bid request copied"))
                .catch(() => toast.error("Could not copy"));
            }}
          >
            Copy text
          </Button>
          <Button
            onClick={() => {
              if (!printBidRequest(doc)) toast.error("Allow pop-ups to print or save as PDF");
            }}
            disabled={items.length === 0}
          >
            Print / save as PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
