import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { combinedStageFor, type ScheduleBasis } from "@/lib/domain";
import { num } from "@/lib/estimate-math";
import { money } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type NewItem = Database["public"]["Tables"]["payment_schedule_items"]["Insert"];

export type ScheduleFormat = ScheduleBasis | "itemized";

export type PhaseAmount = {
  phase: { id: string; name: string };
  cost: number;
  price: number;
};

export type LineAmount = {
  id: string;
  phase_id: string;
  description: string;
  price: number;
};

const FORMATS: { value: ScheduleFormat; label: string; blurb: string }[] = [
  {
    value: "equal_percent",
    label: "Equal % draws",
    blurb: "Simple series of even progress payments — e.g. 4 draws at 25% each.",
  },
  {
    value: "combined",
    label: "Combined stages",
    blurb: "A handful of larger milestones like demo, rough-in, finishes.",
  },
  {
    value: "per_phase",
    label: "One payment per phase",
    blurb: "Every estimate phase becomes its own milestone.",
  },
  {
    value: "itemized",
    label: "Itemized by line",
    blurb: "Maximum detail — every estimate line item gets its own row.",
  },
];

export function ScheduleFormatDialog({
  open,
  onOpenChange,
  scheduleId,
  jobId,
  isCostPlus,
  contractTotal,
  phaseAmounts,
  lines,
  tailRows,
  currentBasis,
  onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  scheduleId: string;
  jobId: string;
  isCostPlus: boolean;
  contractTotal: number;
  phaseAmounts: PhaseAmount[];
  lines: LineAmount[];
  tailRows: { name: string; amount: number; is_fee?: boolean; is_contingency?: boolean }[];
  currentBasis: ScheduleBasis;
  onDone: () => void;
}) {
  const [format, setFormat] = useState<ScheduleFormat>(currentBasis);
  const [drawCount, setDrawCount] = useState("4");
  const [depositPct, setDepositPct] = useState("10");

  // Cost plus rows carry cost targets; fixed price rows carry client price.
  const amountOf = (p: PhaseAmount) => (isCostPlus ? p.cost : p.price);
  const baseTotal = phaseAmounts.reduce((s, p) => s + amountOf(p), 0);
  const tailTotal = tailRows.reduce((s, t) => s + t.amount, 0);

  const preview = buildRows({
    format,
    isCostPlus,
    baseTotal,
    phaseAmounts,
    lines,
    amountOf,
    depositCents: isCostPlus ? 0 : Math.round(baseTotal * (num(depositPct, 0) / 100)),
    drawCount: Math.max(2, Math.min(12, Math.round(num(drawCount, 4)))),
  });

  const apply = useMutation({
    mutationFn: async () => {
      const rows = preview;
      const { error: de } = await supabase
        .from("payment_schedule_items")
        .delete()
        .eq("schedule_id", scheduleId);
      if (de) throw de;

      const payload: NewItem[] = [
        ...rows.map((r, i) => ({
          schedule_id: scheduleId,
          name: r.name,
          scheduled_value_cents: r.amount,
          percent_of_contract: r.percent ?? null,
          trigger: r.trigger,
          is_contingency: false,
          is_fee: false,
          sort_order: i,
        })),
        ...tailRows.map((t, i) => ({
          schedule_id: scheduleId,
          name: t.name,
          scheduled_value_cents: t.amount,
          percent_of_contract: null,
          trigger: "progress" as const,
          is_contingency: !!t.is_contingency,
          is_fee: !!t.is_fee,
          sort_order: rows.length + i,
        })),
      ];

      const { data: inserted, error: ie } = await supabase
        .from("payment_schedule_items")
        .insert(payload)
        .select("id, sort_order");
      if (ie) throw ie;

      const links: { item_id: string; phase_id: string }[] = [];
      rows.forEach((r, i) => {
        if (!r.phases?.length) return;
        const match = (inserted ?? []).find((x) => x.sort_order === i);
        if (!match) return;
        for (const phaseId of r.phases) links.push({ item_id: match.id, phase_id: phaseId });
      });
      if (links.length > 0) {
        const { error: le } = await supabase.from("payment_item_phases").insert(links);
        if (le) throw le;
      }

      const total = payload.reduce((s, r) => s + (r.scheduled_value_cents ?? 0), 0);
      const { error: se } = await supabase
        .from("payment_schedules")
        .update({
          basis: format === "itemized" ? "per_phase" : format,
          deposit_cents: isCostPlus ? 0 : Math.round(baseTotal * (num(depositPct, 0) / 100)),
          contract_total_cents: total,
        })
        .eq("id", scheduleId);
      if (se) throw se;

      const { error: je } = await supabase
        .from("jobs")
        .update({ contract_amount_cents: total })
        .eq("id", jobId);
      if (je) throw je;
    },
    onSuccess: () => {
      onDone();
      onOpenChange(false);
      toast.success("Schedule reformatted");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not change the schedule"),
  });

  const previewTotal = preview.reduce((s, r) => s + r.amount, 0) + tailTotal;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Change schedule format</DialogTitle>
          <DialogDescription>
            Rebuild how the {money(contractTotal)} contract is broken into payments. Try formats
            until it reads the way you want in the contract.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-2">
            {FORMATS.map((f) => (
              <button
                key={f.value}
                type="button"
                onClick={() => setFormat(f.value)}
                className={cn(
                  "rounded-md border p-3 text-left transition-colors",
                  format === f.value
                    ? "border-primary bg-primary/5"
                    : "hover:border-muted-foreground/40",
                )}
              >
                <div className="text-sm font-medium">{f.label}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">{f.blurb}</div>
              </button>
            ))}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {!isCostPlus && (
              <div className="space-y-1.5">
                <Label>Deposit % on signing</Label>
                <Input
                  className="num"
                  value={depositPct}
                  onChange={(e) => setDepositPct(e.target.value)}
                />
              </div>
            )}
            {format === "equal_percent" && (
              <div className="space-y-1.5">
                <Label>Number of equal draws</Label>
                <Select value={drawCount} onValueChange={setDrawCount}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2, 3, 4, 5, 6, 8, 10, 12].map((n) => (
                      <SelectItem key={n} value={String(n)}>
                        {n} payments of {Math.round(100 / n)}%
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="overflow-hidden rounded-md border">
            <div className="border-b bg-muted/40 px-3 py-2 text-xs uppercase tracking-[0.14em] text-muted-foreground">
              Preview — {preview.length + tailRows.length} rows
            </div>
            <ul className="max-h-64 divide-y overflow-y-auto text-sm">
              {[
                ...preview.map((r) => ({ name: r.name, amount: r.amount })),
                ...tailRows.map((t) => ({ name: t.name, amount: t.amount })),
              ].map((r, i) => (
                <li key={i} className="flex justify-between gap-4 px-3 py-1.5">
                  <span className="truncate">{r.name}</span>
                  <span className="num">{money(r.amount)}</span>
                </li>
              ))}
            </ul>
            <div className="flex justify-between gap-4 border-t bg-secondary/50 px-3 py-2 text-sm font-medium">
              <span>Total</span>
              <span className="num">{money(previewTotal)}</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={() => apply.mutate()} disabled={apply.isPending || preview.length === 0}>
            Apply format
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

type BuiltRow = {
  name: string;
  amount: number;
  trigger: Database["public"]["Enums"]["payment_trigger"];
  percent?: number;
  phases?: string[];
};

function buildRows(opts: {
  format: ScheduleFormat;
  isCostPlus: boolean;
  baseTotal: number;
  phaseAmounts: PhaseAmount[];
  lines: LineAmount[];
  amountOf: (p: PhaseAmount) => number;
  depositCents: number;
  drawCount: number;
}): BuiltRow[] {
  const { format, baseTotal, phaseAmounts, lines, amountOf, depositCents, drawCount } = opts;
  const rows: BuiltRow[] = [];
  if (depositCents > 0) {
    rows.push({ name: "Deposit on signing", amount: depositCents, trigger: "on_signing" });
  }
  const remaining = baseTotal - depositCents;
  const scale = baseTotal > 0 ? remaining / baseTotal : 0;

  if (format === "equal_percent") {
    const n = drawCount;
    const each = Math.round(remaining / n);
    for (let i = 0; i < n; i++) {
      rows.push({
        name: `Progress payment ${i + 1} of ${n} — ${Math.round(((i + 1) / n) * 100)}% complete`,
        amount: i === n - 1 ? remaining - each * (n - 1) : each,
        percent: Number((1 / n).toFixed(4)),
        trigger: "progress",
      });
    }
  } else if (format === "combined") {
    const groups = new Map<string, { total: number; phases: string[] }>();
    phaseAmounts.forEach((p) => {
      const key = combinedStageFor(p.phase.name);
      const g = groups.get(key) ?? { total: 0, phases: [] };
      g.total += amountOf(p);
      g.phases.push(p.phase.id);
      groups.set(key, g);
    });
    for (const [name, g] of groups) {
      rows.push({
        name,
        amount: Math.round(g.total * scale),
        trigger: "phase_complete",
        phases: g.phases,
      });
    }
  } else if (format === "itemized") {
    phaseAmounts.forEach((p) => {
      lines
        .filter((l) => l.phase_id === p.phase.id)
        .forEach((l) => {
          rows.push({
            name: `${p.phase.name} — ${l.description}`,
            amount: Math.round(l.price * scale),
            trigger: "phase_complete",
            phases: [p.phase.id],
          });
        });
    });
  } else {
    phaseAmounts.forEach((p) => {
      rows.push({
        name: p.phase.name,
        amount: Math.round(amountOf(p) * scale),
        trigger: "phase_complete",
        phases: [p.phase.id],
      });
    });
  }
  return rows;
}
