import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import {
  drawRequestsQuery,
  linesQuery,
  phasesQuery,
  scheduleItemsQuery,
  scheduleQuery,
} from "@/lib/queries";
import {
  PAYMENT_TRIGGERS,
  SCHEDULE_BASES,
  combinedStageFor,
  type ContractType,
  type FeeStyle,
  type PaymentTrigger,
  type ScheduleBasis,
} from "@/lib/domain";
import { costPlusTotals, lineCostCents, lineSellCents, num } from "@/lib/estimate-math";
import { money, parseMoneyToCents, pct } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import {
  Download,
  FilePlus,
  FileText,
  Lock,
  RefreshCw,
  SlidersHorizontal,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { BillingDialog } from "@/components/payments/BillingDialog";
import { DrawAttachments } from "@/components/payments/DrawAttachments";
import { ScheduleFormatDialog } from "@/components/payments/ScheduleFormatDialog";
import {
  downloadFile,
  printSchedule,
  scheduleToCsv,
  scheduleToText,
} from "@/lib/schedule-export";


type ItemPatch = Database["public"]["Tables"]["payment_schedule_items"]["Update"];

type Job = {
  id: string;
  name: string;
  contract_type: ContractType;
  fee_style: FeeStyle;
  fee_percent: number | string;
  contingency_percent: number | string;
};

export function PaymentScheduleTab({
  job,
  estimateId,
  estimateDefaultMultiplier,
  contractOnly = false,
}: {
  job: Job;
  estimateId: string;
  estimateDefaultMultiplier: number;
  /** Contract-agreement view: no invoicing/draw creation, export + reformat instead. */
  contractOnly?: boolean;
}) {
  const qc = useQueryClient();
  const schedule = useQuery(scheduleQuery(job.id));
  const scheduleId = schedule.data?.id ?? "";
  const items = useQuery(scheduleItemsQuery(scheduleId));
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const draws = useQuery(drawRequestsQuery(job.id));

  const [basis, setBasis] = useState<ScheduleBasis>("per_phase");
  const [drawCount, setDrawCount] = useState("4");
  const [depositPct, setDepositPct] = useState("10");
  const [viewDraw, setViewDraw] = useState<string | null>(null);
  const [billingOpen, setBillingOpen] = useState(false);
  const [formatOpen, setFormatOpen] = useState(false);

  const isCostPlus = job.contract_type === "cost_plus";
  const scheduleTitle = isCostPlus ? "Schedule of values" : "Payment schedule";

  const allPhases = phases.data ?? [];
  const allLines = lines.data ?? [];

  const phaseAmounts = allPhases.map((p) => {
    const pLines = allLines.filter((l) => l.phase_id === p.id);
    return {
      phase: p,
      cost: pLines.reduce((s, l) => s + lineCostCents(l), 0),
      price: pLines.reduce((s, l) => s + lineSellCents(l, p, estimateDefaultMultiplier), 0),
    };
  });
  const estCost = phaseAmounts.reduce((s, p) => s + p.cost, 0);
  const estPrice = phaseAmounts.reduce((s, p) => s + p.price, 0);
  const cp = costPlusTotals({
    cost: estCost,
    sell: estPrice,
    feeStyle: job.fee_style,
    feePercent: job.fee_percent,
    contingencyPercent: job.contingency_percent,
  });
  const contractTotal = isCostPlus ? cp.total : estPrice;

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["schedule", job.id] });
    void qc.invalidateQueries({ queryKey: ["schedule-items", scheduleId] });
    void qc.invalidateQueries({ queryKey: ["draw-requests", job.id] });
  };

  const generate = useMutation({
    mutationFn: async () => {
      const { data: sched, error } = await supabase
        .from("payment_schedules")
        .insert({
          job_id: job.id,
          estimate_id: estimateId,
          contract_type: job.contract_type,
          basis: isCostPlus ? "per_phase" : basis,
          deposit_cents: isCostPlus ? 0 : Math.round(estPrice * (num(depositPct, 0) / 100)),
          contract_total_cents: contractTotal,
        })
        .select("id")
        .single();
      if (error) throw error;

      type NewItem = Database["public"]["Tables"]["payment_schedule_items"]["Insert"];
      const rows: (NewItem & { _phases?: string[] })[] = [];

      if (isCostPlus) {
        phaseAmounts.forEach((p, i) => {
          rows.push({
            schedule_id: sched.id,
            name: p.phase.name,
            scheduled_value_cents: p.cost,
            trigger: "progress",
            sort_order: i,
            _phases: [p.phase.id],
          });
        });
        if (cp.contingency > 0) {
          rows.push({
            schedule_id: sched.id,
            name: `Contingency (${pct(num(job.contingency_percent), 0)})`,
            scheduled_value_cents: cp.contingency,
            trigger: "progress",
            is_contingency: true,
            sort_order: rows.length,
          });
        }
        rows.push({
          schedule_id: sched.id,
          name:
            job.fee_style === "percent_of_cost"
              ? `Builder fee (${pct(num(job.fee_percent), 0)} of cost)`
              : "Builder fee",
          scheduled_value_cents: cp.fee,
          trigger: "progress",
          is_fee: true,
          sort_order: rows.length,
        });
      } else {
        const deposit = Math.round(estPrice * (num(depositPct, 0) / 100));
        if (deposit > 0) {
          rows.push({
            schedule_id: sched.id,
            name: "Deposit on signing",
            scheduled_value_cents: deposit,
            trigger: "on_signing",
            sort_order: 0,
          });
        }
        const remaining = estPrice - deposit;

        if (basis === "per_phase") {
          const scale = estPrice > 0 ? remaining / estPrice : 0;
          phaseAmounts.forEach((p) => {
            rows.push({
              schedule_id: sched.id,
              name: p.phase.name,
              scheduled_value_cents: Math.round(p.price * scale),
              trigger: "phase_complete",
              sort_order: rows.length,
              _phases: [p.phase.id],
            });
          });
        } else if (basis === "combined") {
          const groups = new Map<string, { total: number; phases: string[] }>();
          phaseAmounts.forEach((p) => {
            const key = combinedStageFor(p.phase.name);
            const g = groups.get(key) ?? { total: 0, phases: [] };
            g.total += p.price;
            g.phases.push(p.phase.id);
            groups.set(key, g);
          });
          const scale = estPrice > 0 ? remaining / estPrice : 0;
          for (const [name, g] of groups) {
            rows.push({
              schedule_id: sched.id,
              name,
              scheduled_value_cents: Math.round(g.total * scale),
              trigger: "phase_complete",
              sort_order: rows.length,
              _phases: g.phases,
            });
          }
        } else {
          const n = Math.max(2, Math.min(12, Math.round(num(drawCount, 4))));
          const each = Math.round(remaining / n);
          for (let i = 0; i < n; i++) {
            const amount = i === n - 1 ? remaining - each * (n - 1) : each;
            rows.push({
              schedule_id: sched.id,
              name: `Progress payment ${i + 1} of ${n} — ${Math.round(((i + 1) / n) * 100)}% complete`,
              scheduled_value_cents: amount,
              percent_of_contract: Number((1 / n).toFixed(4)),
              trigger: "progress",
              sort_order: rows.length,
            });
          }
        }
      }

      // PostgREST rejects a bulk insert whose objects have differing key sets,
      // so every row is normalized to the same shape here.
      const payload: NewItem[] = rows.map((r) => ({
        schedule_id: sched.id,
        name: r.name ?? "",
        scheduled_value_cents: r.scheduled_value_cents ?? 0,
        percent_of_contract: r.percent_of_contract ?? null,
        trigger: r.trigger ?? "phase_complete",
        is_contingency: r.is_contingency ?? false,
        is_fee: r.is_fee ?? false,
        sort_order: r.sort_order ?? 0,
      }));

      const { data: inserted, error: ie } = await supabase
        .from("payment_schedule_items")
        .insert(payload)
        .select("id, sort_order");
      if (ie) throw ie;

      const links: { item_id: string; phase_id: string }[] = [];
      for (const row of rows) {
        if (!row._phases?.length) continue;
        const match = (inserted ?? []).find((i) => i.sort_order === row.sort_order);
        if (!match) continue;
        for (const phaseId of row._phases) links.push({ item_id: match.id, phase_id: phaseId });
      }
      if (links.length > 0) {
        const { error: le } = await supabase.from("payment_item_phases").insert(links);
        if (le) throw le;
      }
      return sched;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Payment schedule generated");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not generate schedule"),
  });

  const updateItem = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: ItemPatch }) => {
      const { error } = await supabase.from("payment_schedule_items").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const removeItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("payment_schedule_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const resetSchedule = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("payment_schedules").delete().eq("id", scheduleId);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const approve = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("payment_schedules")
        .update({ approved_at: new Date().toISOString(), contract_total_cents: itemTotal })
        .eq("id", scheduleId);
      if (error) throw error;
      const { error: je } = await supabase
        .from("jobs")
        .update({ stage: "production", contract_amount_cents: itemTotal })
        .eq("id", job.id);
      if (je) throw je;
    },
    onSuccess: () => {
      invalidate();
      void qc.invalidateQueries({ queryKey: ["job", job.id] });
      void qc.invalidateQueries({ queryKey: ["jobs"] });
      toast.success("Schedule approved — targets locked, job moved to Production");
    },
  });

  const rows = items.data ?? [];
  const itemTotal = rows.reduce((s, r) => s + r.scheduled_value_cents, 0);
  const variance = itemTotal - contractTotal;

  const totalPrev = rows.reduce((s, r) => s + r.completed_previous_cents, 0);
  const totalThis = rows.reduce((s, r) => s + r.completed_this_period_cents, 0);
  const totalStored = rows.reduce((s, r) => s + r.materials_stored_cents, 0);
  const retainagePct = num(schedule.data?.retainage_percent, 0);
  const completedToDate = totalPrev + totalThis + totalStored;
  const retainage = Math.round(completedToDate * retainagePct);
  // G702: on site materials are billable this period alongside completed work.
  const requestedThisPeriod = totalThis + totalStored;

  const createChangeOrder = useMutation({
    mutationFn: async ({ name, amount }: { name: string; amount: string }) => {
      const cents = parseMoneyToCents(amount);
      const coCount = rows.filter((r) => r.name.startsWith("Change order")).length;
      const { error } = await supabase.from("payment_schedule_items").insert({
        schedule_id: scheduleId,
        name: `Change order #${coCount + 1} — ${name}`,
        scheduled_value_cents: cents,
        trigger: "progress",
        sort_order: rows.length + 1,
      });
      if (error) throw error;
      const newTotal = itemTotal + cents;
      const { error: se } = await supabase
        .from("payment_schedules")
        .update({ contract_total_cents: newTotal })
        .eq("id", scheduleId);
      if (se) throw se;
      const { error: je } = await supabase
        .from("jobs")
        .update({ contract_amount_cents: newTotal })
        .eq("id", job.id);
      if (je) throw je;
    },
    onSuccess: () => {
      invalidate();
      void qc.invalidateQueries({ queryKey: ["job", job.id] });
      void qc.invalidateQueries({ queryKey: ["jobs"] });
      toast.success(
        isCostPlus
          ? "Change order added to the schedule of values"
          : "Change order added to the payment schedule",
      );
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add change order"),
  });

  if (!estimateId) {
    return <p className="text-sm text-muted-foreground">Build the estimate first.</p>;
  }

  if (!schedule.data) {
    return (
      <div className="max-w-2xl space-y-5 rounded-lg border p-6">
        <div>
          <h3 className="font-display text-xl">
            Generate the {isCostPlus ? "schedule of values" : "payment schedule"}
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Built from the estimate — {money(estCost)} estimated cost, {money(contractTotal)}{" "}
            {isCostPlus ? "estimated total" : "contract price"}.
          </p>
        </div>

        {isCostPlus ? (
          <div className="rounded-md border bg-muted/30 p-3 text-sm">
            <p>
              Cost plus bills on a schedule of values: one row per phase at target cost, a visible
              contingency row to draw against, and your fee line.
            </p>
          </div>
        ) : (
          <>
            <div className="space-y-2">
              <Label>How should payments be broken up?</Label>
              <div className="grid gap-2">
                {SCHEDULE_BASES.map((b) => (
                  <button
                    key={b.value}
                    type="button"
                    onClick={() => setBasis(b.value)}
                    className={cn(
                      "rounded-md border p-3 text-left transition-colors",
                      basis === b.value
                        ? "border-primary bg-primary/5"
                        : "hover:border-muted-foreground/40",
                    )}
                  >
                    <div className="text-sm font-medium">{b.label}</div>
                    <div className="mt-0.5 text-xs text-muted-foreground">{b.blurb}</div>
                  </button>
                ))}
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Deposit % on signing</Label>
                <Input
                  className="num"
                  value={depositPct}
                  onChange={(e) => setDepositPct(e.target.value)}
                />
              </div>
              {basis === "equal_percent" && (
                <div className="space-y-1.5">
                  <Label>Number of equal draws</Label>
                  <Select value={drawCount} onValueChange={setDrawCount}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[3, 4, 5, 6, 8].map((n) => (
                        <SelectItem key={n} value={String(n)}>
                          {n} payments of {Math.round(100 / n)}%
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </>
        )}

        <Button
          onClick={() => generate.mutate()}
          disabled={generate.isPending || contractTotal === 0}
        >
          Generate schedule
        </Button>
      </div>
    );
  }

  const locked = !!schedule.data.approved_at;
  const shown = viewDraw ? (draws.data ?? []).find((d) => d.id === viewDraw) : null;
  const snapshotLines =
    (
      shown?.snapshot as {
        lines?: {
          name: string;
          scheduled_value_cents: number;
          completed_previous_cents: number;
          completed_this_period_cents: number;
          materials_stored_cents: number;
        }[];
      } | null
    )?.lines ?? [];

  const netChangeOrders = rows
    .filter((r) => r.name.startsWith("Change order"))
    .reduce((s, r) => s + r.scheduled_value_cents, 0);
  const originalContract = itemTotal - netChangeOrders;
  const earnedLessRetainage = completedToDate - retainage;
  const previousCertificates = (draws.data ?? []).reduce((s, d) => s + d.amount_requested_cents, 0);
  const currentDue = Math.max(0, earnedLessRetainage - previousCertificates);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
          {isCostPlus ? "Schedule of values" : "Milestone payment schedule"}
          {locked && (
            <Badge variant="outline" className="ml-2 gap-1 text-[10px]">
              <Lock className="h-3 w-3" /> Approved{" "}
              {new Date(schedule.data.approved_at!).toLocaleDateString()}
            </Badge>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Download className="mr-1.5 h-3.5 w-3.5" /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onSelect={() => {
                  if (!printSchedule({ jobName: job.name, title: scheduleTitle, rows, total: itemTotal }))
                    toast.error("Allow pop-ups to print or save as PDF");
                }}
              >
                Print / save as PDF
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  downloadFile(
                    `${job.name} — ${scheduleTitle}.csv`,
                    scheduleToCsv(rows, itemTotal, !isCostPlus),
                    "text/csv",
                  );
                  toast.success("CSV downloaded");
                }}
              >
                Download CSV (Excel)
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  void navigator.clipboard
                    .writeText(scheduleToText(rows, itemTotal))
                    .then(() => toast.success("Copied to clipboard"))
                    .catch(() => toast.error("Could not copy"));
                }}
              >
                Copy to clipboard
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {!locked && (
            <>
              <Button variant="outline" size="sm" onClick={() => setFormatOpen(true)}>
                <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" /> Schedule format
              </Button>
              <Button variant="ghost" size="sm" onClick={() => resetSchedule.mutate()}>
                <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Regenerate
              </Button>
              <Button size="sm" onClick={() => approve.mutate()} disabled={approve.isPending}>
                Approve schedule
              </Button>
            </>
          )}
          {locked && contractOnly && (
            <Button variant="outline" size="sm" onClick={() => setFormatOpen(true)}>
              <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" /> Schedule format
            </Button>
          )}
          {locked && !contractOnly && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const name = window.prompt("Change order description");
                  if (!name?.trim()) return;
                  const amount = window.prompt("Change order amount (can be negative)");
                  if (amount === null) return;
                  createChangeOrder.mutate({ name: name.trim(), amount });
                }}
                disabled={createChangeOrder.isPending}
              >
                <FilePlus className="mr-1.5 h-3.5 w-3.5" /> Create change order
              </Button>
              <Button size="sm" onClick={() => setBillingOpen(true)}>
                <FileText className="mr-1.5 h-3.5 w-3.5" />{" "}
                {isCostPlus ? "Create draw request" : "Create invoice"}
              </Button>
            </>
          )}

        </div>

      </div>

      {!isCostPlus && variance !== 0 && (
        <div className="rounded-md border border-warning/40 bg-warning/5 px-3 py-2 text-sm text-warning">
          Milestones total {money(itemTotal)} against a {money(contractTotal)} contract —{" "}
          {variance > 0 ? "over by " : "short by "}
          {money(Math.abs(variance))}. Adjust before sending.
        </div>
      )}

      {!isCostPlus && (
        <div className="rounded-lg border">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b px-3 py-2">
            <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
              Contract billing summary
            </div>
            <div className="text-xs text-muted-foreground">
              Invoice #{(draws.data ?? []).length + 1} · through {new Date().toLocaleDateString()}
            </div>
          </div>
          <dl className="divide-y text-sm">
            <SummaryRow n={1} label="Original contract sum" value={money(originalContract)} />
            <SummaryRow n={2} label="Net change by change orders" value={money(netChangeOrders)} />
            <SummaryRow n={3} label="Contract sum to date" value={money(itemTotal)} strong />
            <SummaryRow n={4} label="Total billed to date" value={money(completedToDate)} />
            <SummaryRow n={5} label="Less previous invoices" value={money(previousCertificates)} />
            <SummaryRow n={6} label="Current amount due" value={money(currentDue)} strong />
            <SummaryRow
              n={7}
              label="Balance to finish"
              value={money(itemTotal - completedToDate)}
            />
          </dl>
        </div>
      )}

      {isCostPlus && (
        <div className="rounded-lg border">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b px-3 py-2">
            <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
              Application for payment — summary
            </div>
            <div className="text-xs text-muted-foreground">
              Application #{(draws.data ?? []).length + 1} · through{" "}
              {new Date().toLocaleDateString()}
            </div>
          </div>
          <dl className="divide-y text-sm">
            <SummaryRow n={1} label="Original contract sum" value={money(originalContract)} />
            <SummaryRow n={2} label="Net change by change orders" value={money(netChangeOrders)} />
            <SummaryRow n={3} label="Contract sum to date" value={money(itemTotal)} strong />
            <SummaryRow
              n={4}
              label="Total completed and on site to date"
              value={money(completedToDate)}
            />
            <SummaryRow
              n={5}
              label={`Retainage (${pct(retainagePct, 0)})`}
              value={money(retainage)}
            />
            <SummaryRow
              n={6}
              label="Total earned less retainage"
              value={money(earnedLessRetainage)}
            />
            <SummaryRow
              n={7}
              label="Less previous applications for payment"
              value={money(previousCertificates)}
            />
            <SummaryRow n={8} label="Current payment due" value={money(currentDue)} strong />
            <SummaryRow
              n={9}
              label="Balance to finish plus retainage"
              value={money(itemTotal - earnedLessRetainage)}
            />
          </dl>
        </div>
      )}

      <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
        {isCostPlus ? "Continuation sheet — line detail" : "Milestones"}
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            {isCostPlus ? (
              <tr>
                <th className="w-[26%] px-2 py-2 font-medium">Item</th>
                <th className="px-2 py-2 text-right font-medium">Scheduled value</th>
                <th className="px-2 py-2 text-right font-medium">Previous</th>
                <th className="px-2 py-2 text-right font-medium">This period</th>
                <th className="px-2 py-2 text-right font-medium">On site materials</th>
                <th className="px-2 py-2 text-right font-medium">Total to date</th>
                <th className="px-2 py-2 text-right font-medium">%</th>
                <th className="px-2 py-2 text-right font-medium">Balance</th>
                <th className="w-8" />
              </tr>
            ) : (
              <tr>
                <th className="w-[40%] px-2 py-2 font-medium">Milestone</th>
                <th className="px-2 py-2 font-medium">Trigger</th>
                <th className="px-2 py-2 text-right font-medium">Amount</th>
                <th className="px-2 py-2 text-right font-medium">% of contract</th>
                <th className="px-2 py-2 text-right font-medium">Billed</th>
                <th className="w-8" />
              </tr>
            )}
          </thead>
          <tbody>
            {rows.map((r) => {
              const toDate =
                r.completed_previous_cents +
                r.completed_this_period_cents +
                r.materials_stored_cents;
              return (
                <tr
                  key={r.id}
                  className={cn(
                    "border-t hover:bg-muted/30",
                    r.is_contingency && "bg-warning/5",
                    r.is_fee && "bg-secondary/40",
                  )}
                >
                  <td className="px-2 py-1">
                    <Cell
                      value={r.name}
                      onCommit={(v) => updateItem.mutate({ id: r.id, patch: { name: v } })}
                    />
                  </td>
                  {isCostPlus ? (
                    <>
                      <td className="px-2 py-1 text-right">
                        <Cell
                          align="right"
                          value={(r.scheduled_value_cents / 100).toFixed(2)}
                          disabled={locked}
                          onCommit={(v) =>
                            updateItem.mutate({
                              id: r.id,
                              patch: { scheduled_value_cents: parseMoneyToCents(v) },
                            })
                          }
                        />
                      </td>
                      <td className="num px-2 py-1 text-right text-muted-foreground">
                        {money(r.completed_previous_cents)}
                      </td>
                      <td className="px-2 py-1 text-right">
                        <Cell
                          align="right"
                          value={(r.completed_this_period_cents / 100).toFixed(2)}
                          onCommit={(v) =>
                            updateItem.mutate({
                              id: r.id,
                              patch: { completed_this_period_cents: parseMoneyToCents(v) },
                            })
                          }
                        />
                      </td>
                      <td className="px-2 py-1 text-right">
                        <Cell
                          align="right"
                          value={(r.materials_stored_cents / 100).toFixed(2)}
                          onCommit={(v) =>
                            updateItem.mutate({
                              id: r.id,
                              patch: { materials_stored_cents: parseMoneyToCents(v) },
                            })
                          }
                        />
                      </td>
                      <td className="num px-2 py-1 text-right font-medium">{money(toDate)}</td>
                      <td className="num px-2 py-1 text-right text-muted-foreground">
                        {r.scheduled_value_cents > 0
                          ? pct(toDate / r.scheduled_value_cents, 0)
                          : "—"}
                      </td>
                      <td className="num px-2 py-1 text-right">
                        {money(r.scheduled_value_cents - toDate)}
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="px-2 py-1">
                        <Select
                          value={r.trigger}
                          onValueChange={(v) =>
                            updateItem.mutate({
                              id: r.id,
                              patch: { trigger: v as PaymentTrigger },
                            })
                          }
                        >
                          <SelectTrigger className="h-7 w-[140px] border-transparent bg-transparent px-1.5 text-xs shadow-none focus:border-input focus:bg-background">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {PAYMENT_TRIGGERS.map((t) => (
                              <SelectItem key={t.value} value={t.value} className="text-xs">
                                {t.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="px-2 py-1 text-right">
                        <Cell
                          align="right"
                          value={(r.scheduled_value_cents / 100).toFixed(2)}
                          disabled={locked}
                          onCommit={(v) =>
                            updateItem.mutate({
                              id: r.id,
                              patch: { scheduled_value_cents: parseMoneyToCents(v) },
                            })
                          }
                        />
                      </td>
                      <td className="num px-2 py-1 text-right text-muted-foreground">
                        {itemTotal > 0 ? pct(r.scheduled_value_cents / itemTotal, 1) : "—"}
                      </td>
                      <td className="num px-2 py-1 text-right">
                        {r.completed_previous_cents + r.completed_this_period_cents >=
                          r.scheduled_value_cents && r.scheduled_value_cents > 0
                          ? "Billed"
                          : money(r.completed_previous_cents + r.completed_this_period_cents)}
                      </td>
                    </>
                  )}
                  <td className="px-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      disabled={locked}
                      onClick={() => removeItem.mutate(r.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr className="border-t-2 bg-secondary/60 font-medium">
              <td className="px-2 py-2">Totals</td>
              {isCostPlus ? (
                <>
                  <td className="num px-2 py-2 text-right">{money(itemTotal)}</td>
                  <td className="num px-2 py-2 text-right">{money(totalPrev)}</td>
                  <td className="num px-2 py-2 text-right">{money(totalThis)}</td>
                  <td className="num px-2 py-2 text-right">{money(totalStored)}</td>
                  <td className="num px-2 py-2 text-right">{money(completedToDate)}</td>
                  <td className="num px-2 py-2 text-right">
                    {itemTotal > 0 ? pct(completedToDate / itemTotal, 0) : "—"}
                  </td>
                  <td className="num px-2 py-2 text-right">{money(itemTotal - completedToDate)}</td>
                </>
              ) : (
                <>
                  <td />
                  <td className="num px-2 py-2 text-right">{money(itemTotal)}</td>
                  <td className="num px-2 py-2 text-right">{itemTotal > 0 ? "100.0%" : "—"}</td>
                  <td className="num px-2 py-2 text-right">{money(totalPrev + totalThis)}</td>
                </>
              )}
              <td />
            </tr>
          </tfoot>
        </table>
      </div>

      {isCostPlus && (
        <div className="grid gap-3 sm:grid-cols-3">
          <Mini label="Requested this period" value={money(requestedThisPeriod)} />
          <Mini label="Retainage held" value={money(retainage)} />
          <Mini label="Balance to finish" value={money(itemTotal - completedToDate)} />
        </div>
      )}

      {!contractOnly && (draws.data ?? []).length > 0 && (
        <div className="rounded-lg border">
          <div className="border-b px-3 py-2 text-xs uppercase tracking-[0.14em] text-muted-foreground">
            {isCostPlus ? "Draw request history" : "Invoice history"}
          </div>
          <ul className="divide-y">
            {(draws.data ?? []).map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-4 px-3 py-2 text-sm">
                <span>
                  {isCostPlus ? "Draw" : "Invoice"} #{d.number}
                  <span className="ml-2 text-xs text-muted-foreground">
                    {d.period_to ?? ""} · {d.status}
                  </span>
                </span>
                <span className="flex items-center gap-3">
                  <span className="num">{money(d.amount_requested_cents)}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewDraw(viewDraw === d.id ? null : d.id)}
                  >
                    {viewDraw === d.id ? "Hide" : "View"}
                  </Button>
                </span>
              </li>
            ))}
          </ul>
          {shown && (
            <div className="border-t bg-muted/30 p-3">
              <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                {isCostPlus ? "Draw" : "Invoice"} #{shown.number} — saved version
              </div>

              {!isCostPlus ? (
                <div className="mt-2 overflow-hidden rounded-md border bg-background">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                      <tr>
                        <th className="px-2 py-2 font-medium">Milestone billed</th>
                        <th className="px-2 py-2 text-right font-medium">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {snapshotLines.map((l, i) => (
                        <tr key={i} className="border-t">
                          <td className="px-2 py-1">{l.name}</td>
                          <td className="num px-2 py-1 text-right">
                            {money(l.completed_this_period_cents)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 bg-secondary/60 font-medium">
                        <td className="px-2 py-2">Invoice total</td>
                        <td className="num px-2 py-2 text-right">
                          {money(shown.amount_requested_cents)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                  {(() => {
                    const s = (shown.snapshot ?? {}) as {
                      contract_total_cents?: number;
                      completed_to_date_cents?: number;
                    };
                    const contract = s.contract_total_cents ?? itemTotal;
                    const toDate = s.completed_to_date_cents ?? shown.amount_requested_cents;
                    const prior = Math.max(0, toDate - shown.amount_requested_cents);
                    return (
                      <dl className="divide-y border-t text-sm">
                        <SummaryRow n={1} label="Contract sum to date" value={money(contract)} />
                        <SummaryRow n={2} label="Total billed to date" value={money(toDate)} />
                        <SummaryRow n={3} label="Less previous invoices" value={money(prior)} />
                        <SummaryRow
                          n={4}
                          label="Current amount due"
                          value={money(shown.amount_requested_cents)}
                          strong
                        />
                        <SummaryRow
                          n={5}
                          label="Balance to finish"
                          value={money(contract - toDate)}
                        />
                      </dl>
                    );
                  })()}
                </div>
              ) : (
                <div className="mt-2 overflow-x-auto rounded-md border bg-background">
                  <table className="w-full min-w-[900px] text-sm">
                    <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                      <tr>
                        <th className="w-[26%] px-2 py-2 font-medium">Item</th>
                        <th className="px-2 py-2 text-right font-medium">Scheduled value</th>
                        <th className="px-2 py-2 text-right font-medium">Previous</th>
                        <th className="px-2 py-2 text-right font-medium">This period</th>
                        <th className="px-2 py-2 text-right font-medium">On site materials</th>
                        <th className="px-2 py-2 text-right font-medium">Total to date</th>
                        <th className="px-2 py-2 text-right font-medium">%</th>
                        <th className="px-2 py-2 text-right font-medium">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {snapshotLines.map((l, i) => {
                        const toDate =
                          l.completed_previous_cents +
                          l.completed_this_period_cents +
                          l.materials_stored_cents;
                        return (
                          <tr key={i} className="border-t">
                            <td className="px-2 py-1">{l.name}</td>
                            <td className="num px-2 py-1 text-right">
                              {money(l.scheduled_value_cents)}
                            </td>
                            <td className="num px-2 py-1 text-right text-muted-foreground">
                              {money(l.completed_previous_cents)}
                            </td>
                            <td className="num px-2 py-1 text-right">
                              {money(l.completed_this_period_cents)}
                            </td>
                            <td className="num px-2 py-1 text-right">
                              {money(l.materials_stored_cents)}
                            </td>
                            <td className="num px-2 py-1 text-right font-medium">
                              {money(toDate)}
                            </td>
                            <td className="num px-2 py-1 text-right text-muted-foreground">
                              {l.scheduled_value_cents > 0
                                ? pct(toDate / l.scheduled_value_cents, 0)
                                : "—"}
                            </td>
                            <td className="num px-2 py-1 text-right">
                              {money(l.scheduled_value_cents - toDate)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 bg-secondary/60 font-medium">
                        <td className="px-2 py-2">Totals</td>
                        {(() => {
                          const t = snapshotLines.reduce(
                            (a, l) => ({
                              sv: a.sv + l.scheduled_value_cents,
                              prev: a.prev + l.completed_previous_cents,
                              this: a.this + l.completed_this_period_cents,
                              stored: a.stored + l.materials_stored_cents,
                            }),
                            { sv: 0, prev: 0, this: 0, stored: 0 },
                          );
                          const toDate = t.prev + t.this + t.stored;
                          return (
                            <>
                              <td className="num px-2 py-2 text-right">{money(t.sv)}</td>
                              <td className="num px-2 py-2 text-right">{money(t.prev)}</td>
                              <td className="num px-2 py-2 text-right">{money(t.this)}</td>
                              <td className="num px-2 py-2 text-right">{money(t.stored)}</td>
                              <td className="num px-2 py-2 text-right">{money(toDate)}</td>
                              <td className="num px-2 py-2 text-right">
                                {t.sv > 0 ? pct(toDate / t.sv, 0) : "—"}
                              </td>
                              <td className="num px-2 py-2 text-right">{money(t.sv - toDate)}</td>
                            </>
                          );
                        })()}
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}

              {isCostPlus && <DrawAttachments jobId={job.id} drawId={shown.id} />}
            </div>
          )}
        </div>
      )}

      {locked && !contractOnly && (
        <BillingDialog
          open={billingOpen}
          onOpenChange={setBillingOpen}
          isCostPlus={isCostPlus}
          jobId={job.id}
          jobName={job.name}
          scheduleId={scheduleId}
          rows={rows}
          retainagePct={retainagePct}
          previousCertificates={previousCertificates}
          nextNumber={((draws.data ?? [])[0]?.number ?? 0) + 1}
          onDone={invalidate}
        />
      )}

      {scheduleId && (!locked || contractOnly) && (
        <ScheduleFormatDialog
          open={formatOpen}
          onOpenChange={setFormatOpen}
          scheduleId={scheduleId}
          jobId={job.id}
          isCostPlus={isCostPlus}
          contractTotal={contractTotal}
          currentBasis={(schedule.data?.basis ?? "per_phase") as ScheduleBasis}
          phaseAmounts={phaseAmounts.map((p) => ({
            phase: { id: p.phase.id, name: p.phase.name },
            cost: p.cost,
            price: p.price,
          }))}
          lines={allLines.map((l) => {
            const phase = allPhases.find((p) => p.id === l.phase_id);
            return {
              id: l.id,
              phase_id: l.phase_id,
              description: l.description,
              price: isCostPlus
                ? lineCostCents(l)
                : phase
                  ? lineSellCents(l, phase, estimateDefaultMultiplier)
                  : lineCostCents(l),
            };
          })}
          tailRows={
            isCostPlus
              ? [
                  ...(cp.contingency > 0
                    ? [
                        {
                          name: `Contingency (${pct(num(job.contingency_percent), 0)})`,
                          amount: cp.contingency,
                          is_contingency: true,
                        },
                      ]
                    : []),
                  {
                    name:
                      job.fee_style === "percent_of_cost"
                        ? `Builder fee (${pct(num(job.fee_percent), 0)} of cost)`
                        : "Builder fee",
                    amount: cp.fee,
                    is_fee: true,
                  },
                ]
              : []
          }
          onDone={invalidate}
        />
      )}

    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-card px-3 py-2.5">
      <div className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{label}</div>
      <div className="num mt-1 text-lg font-medium">{value}</div>
    </div>
  );
}

function Cell({
  value,
  onCommit,
  align = "left",
  disabled,
}: {
  value: string;
  onCommit: (v: string) => void;
  align?: "left" | "right";
  disabled?: boolean;
}) {
  return (
    <Input
      key={value}
      defaultValue={value}
      disabled={disabled}
      onBlur={(e) => {
        if (e.target.value !== value) onCommit(e.target.value);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
      }}
      className={cn(
        "h-7 border-transparent bg-transparent px-1.5 shadow-none focus-visible:border-input focus-visible:bg-background disabled:opacity-100",
        align === "right" && "num text-right",
      )}
    />
  );
}

function SummaryRow({
  n,
  label,
  value,
  strong,
}: {
  n: number;
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-4 px-3 py-1.5",
        strong && "bg-secondary/40 font-medium",
      )}
    >
      <dt className="flex gap-2">
        <span className="num w-4 text-muted-foreground">{n}</span>
        <span>{label}</span>
      </dt>
      <dd className="num">{value}</dd>
    </div>
  );
}
