import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { drawAttachmentsQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Download, Paperclip, Trash2 } from "lucide-react";
import { toast } from "sonner";

const kb = (n: number) =>
  n > 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`;

export function DrawAttachments({ jobId, drawId }: { jobId: string; drawId: string }) {
  const qc = useQueryClient();
  const all = useQuery(drawAttachmentsQuery(jobId));
  const files = (all.data ?? []).filter((f) => f.draw_id === drawId);

  const open = useMutation({
    mutationFn: async (path: string) => {
      const { data, error } = await supabase.storage
        .from("draw-backup")
        .createSignedUrl(path, 60 * 10);
      if (error) throw error;
      window.open(data.signedUrl, "_blank", "noopener");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not open file"),
  });

  const remove = useMutation({
    mutationFn: async (f: { id: string; file_path: string }) => {
      await supabase.storage.from("draw-backup").remove([f.file_path]);
      const { error } = await supabase.from("draw_attachments").delete().eq("id", f.id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["draw-attachments", jobId] }),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not remove file"),
  });

  return (
    <div className="mt-3 border-t pt-3">
      <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
        Backup ({files.length})
      </div>
      {files.length === 0 ? (
        <p className="mt-1.5 text-xs text-muted-foreground">No backup attached.</p>
      ) : (
        <ul className="mt-1.5 divide-y">
          {files.map((f) => (
            <li key={f.id} className="flex items-center justify-between gap-3 py-1.5 text-sm">
              <span className="flex min-w-0 items-center gap-2">
                <Paperclip className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="truncate">{f.label || f.file_name}</span>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {f.file_name} · {kb(f.size_bytes)}
                </span>
              </span>
              <span className="flex shrink-0 items-center">
                <Button variant="ghost" size="icon" onClick={() => open.mutate(f.file_path)}>
                  <Download className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => remove.mutate(f)}>
                  <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
                </Button>
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
