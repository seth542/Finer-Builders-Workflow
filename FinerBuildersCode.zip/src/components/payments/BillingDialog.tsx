import { useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { money, parseMoneyToCents, pct } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { suggestBackup } from "@/lib/backup-requirements";
import { Paperclip, Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";

export type BillingRow = {
  id: string;
  name: string;
  scheduled_value_cents: number;
  completed_previous_cents: number;
  completed_this_period_cents: number;
  materials_stored_cents: number;
  is_contingency: boolean;
  is_fee: boolean;
};

export function BillingDialog({
  open,
  onOpenChange,
  isCostPlus,
  jobId,
  jobName,
  scheduleId,
  rows,
  retainagePct,
  previousCertificates,
  nextNumber,
  onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  isCostPlus: boolean;
  jobId: string;
  jobName: string;
  scheduleId: string;
  rows: BillingRow[];
  retainagePct: number;
  previousCertificates: number;
  nextNumber: number;
  onDone: () => void;
}) {
  const qc = useQueryClient();
  const [periodTo, setPeriodTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState("");

  // Cost plus: editable progress per line. Fixed price: pick which milestones to bill.
  const [progress, setProgress] = useState<Record<string, { work: string; stored: string }>>(() =>
    Object.fromEntries(
      rows.map((r) => [
        r.id,
        {
          work: (r.completed_this_period_cents / 100).toFixed(2),
          stored: (r.materials_stored_cents / 100).toFixed(2),
        },
      ]),
    ),
  );
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  // Backup files keyed by requirement id; "other" holds anything extra.
  const [files, setFiles] = useState<Record<string, File[]>>({});

  const addFiles = (key: string, list: FileList | null) => {
    if (!list?.length) return;
    setFiles((f) => ({ ...f, [key]: [...(f[key] ?? []), ...Array.from(list)] }));
  };
  const removeFile = (key: string, idx: number) =>
    setFiles((f) => ({ ...f, [key]: (f[key] ?? []).filter((_, i) => i !== idx) }));

  const billedToDate = (r: BillingRow) =>
    r.completed_previous_cents + r.completed_this_period_cents;
  const billable = rows.filter((r) => billedToDate(r) < r.scheduled_value_cents);

  const draft = useMemo(
    () =>
      rows.map((r) => {
        if (isCostPlus) {
          const p = progress[r.id] ?? { work: "0", stored: "0" };
          return {
            ...r,
            work: parseMoneyToCents(p.work),
            stored: parseMoneyToCents(p.stored),
          };
        }
        const on = !!selected[r.id];
        return {
          ...r,
          work: on ? r.scheduled_value_cents - billedToDate(r) : 0,
          stored: 0,
        };
      }),
    [rows, isCostPlus, progress, selected],
  );

  const thisPeriod = draft.reduce((s, r) => s + r.work + r.stored, 0);
  const completedToDate = draft.reduce(
    (s, r) => s + r.completed_previous_cents + r.work + r.stored,
    0,
  );
  const retainage = isCostPlus ? Math.round(completedToDate * retainagePct) : 0;
  const amountDue = Math.max(0, completedToDate - retainage - previousCertificates);

  const requirements = useMemo(
    () => (isCostPlus ? suggestBackup(draft, isCostPlus) : []),
    [draft, isCostPlus],
  );
  const attachedCount = Object.values(files).reduce((s, list) => s + list.length, 0);
  const missingRequired = requirements.filter((q) => q.required && !(files[q.id] ?? []).length);

  const submit = useMutation({
    mutationFn: async () => {
      const snapshot = {
        job: jobName,
        kind: isCostPlus ? "draw_request" : "invoice",
        created_at: new Date().toISOString(),
        period_to: periodTo,
        contract_total_cents: rows.reduce((s, r) => s + r.scheduled_value_cents, 0),
        completed_to_date_cents: completedToDate,
        retainage_cents: retainage,
        amount_requested_cents: amountDue,
        lines: draft
          .filter((r) => (isCostPlus ? true : r.work > 0))
          .map((r) => ({
            name: r.name,
            scheduled_value_cents: r.scheduled_value_cents,
            completed_previous_cents: r.completed_previous_cents,
            completed_this_period_cents: r.work,
            ...(isCostPlus ? { materials_stored_cents: r.stored } : {}),
            is_contingency: r.is_contingency,
            is_fee: r.is_fee,
          })),
      };

      const { data: created, error } = await supabase
        .from("draw_requests")
        .insert({
          job_id: jobId,
          schedule_id: scheduleId,
          number: nextNumber,
          period_to: periodTo,
          status: "sent",
          amount_requested_cents: amountDue,
          retainage_cents: retainage,
          notes: notes.trim() || null,
          snapshot: isCostPlus
            ? {
                ...snapshot,
                required_backup: requirements.map((q) => ({
                  id: q.id,
                  label: q.label,
                  required: q.required,
                  attached: (files[q.id] ?? []).length,
                })),
              }
            : snapshot,
        })
        .select("id")
        .single();
      if (error) throw error;

      for (const [key, list] of Object.entries(files)) {
        const label = requirements.find((q) => q.id === key)?.label ?? "Additional backup";
        for (const file of list) {
          const safe = file.name.replace(/[^\w.-]+/g, "_");
          const path = `${jobId}/${created.id}/${key}-${Date.now()}-${safe}`;
          const { error: se } = await supabase.storage
            .from("draw-backup")
            .upload(path, file, file.type ? { contentType: file.type } : {});
          if (se) throw se;
          const { error: ae } = await supabase.from("draw_attachments").insert({
            draw_id: created.id,
            job_id: jobId,
            category: key,
            label,
            file_name: file.name,
            file_path: path,
            mime_type: file.type || null,
            size_bytes: file.size,
          });
          if (ae) throw ae;
        }
      }

      // Keep the schedule layout intact: the requested amounts stay visible in the
      // "This period" column. Any prior period's amounts roll into "Previous" now.
      for (const r of draft) {
        const previous = r.completed_previous_cents + r.completed_this_period_cents;
        if (r.work === 0 && r.stored === 0 && previous === r.completed_previous_cents) continue;
        const { error: ue } = await supabase
          .from("payment_schedule_items")
          .update({
            completed_previous_cents: previous,
            completed_this_period_cents: r.work,
            materials_stored_cents: isCostPlus ? r.stored : 0,
          })
          .eq("id", r.id);
        if (ue) throw ue;
      }
    },
    onSuccess: () => {
      toast.success(
        isCostPlus
          ? `Draw request #${nextNumber} created${attachedCount ? ` with ${attachedCount} backup file${attachedCount > 1 ? "s" : ""}` : ""}`
          : `Invoice #${nextNumber} created for ${money(amountDue)}`,
      );
      void qc.invalidateQueries({ queryKey: ["draw-attachments", jobId] });
      setFiles({});
      onOpenChange(false);
      onDone();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not create billing"),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isCostPlus ? `Draw request #${nextNumber}` : `Invoice #${nextNumber}`}
          </DialogTitle>
          <DialogDescription>
            {isCostPlus
              ? "Enter work completed and on site materials for this period. Retainage and prior applications are deducted automatically."
              : "Pick the milestones that are complete. Each one bills at its full scheduled value."}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Period through</Label>
            <Input type="date" value={periodTo} onChange={(e) => setPeriodTo(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Notes (optional)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              {isCostPlus ? (
                <tr>
                  <th className="px-2 py-2 font-medium">Item</th>
                  <th className="px-2 py-2 text-right font-medium">Scheduled</th>
                  <th className="px-2 py-2 text-right font-medium">Previous</th>
                  <th className="px-2 py-2 text-right font-medium">This period</th>
                  <th className="px-2 py-2 text-right font-medium">On site materials</th>
                </tr>
              ) : (
                <tr>
                  <th className="w-10 px-2 py-2 font-medium">Bill</th>
                  <th className="px-2 py-2 font-medium">Milestone</th>
                  <th className="px-2 py-2 text-right font-medium">Amount</th>
                  <th className="px-2 py-2 text-right font-medium">Status</th>
                </tr>
              )}
            </thead>
            <tbody>
              {(isCostPlus ? rows : rows).map((r) => {
                const billed = billedToDate(r) >= r.scheduled_value_cents;
                return (
                  <tr key={r.id} className="border-t">
                    {isCostPlus ? (
                      <>
                        <td className="px-2 py-1">{r.name}</td>
                        <td className="num px-2 py-1 text-right text-muted-foreground">
                          {money(r.scheduled_value_cents)}
                        </td>
                        <td className="num px-2 py-1 text-right text-muted-foreground">
                          {money(r.completed_previous_cents)}
                        </td>
                        <td className="px-2 py-1 text-right">
                          <Input
                            className="num h-7 text-right"
                            value={progress[r.id]?.work ?? "0.00"}
                            onChange={(e) =>
                              setProgress((p) => ({
                                ...p,
                                [r.id]: { work: e.target.value, stored: p[r.id]?.stored ?? "0.00" },
                              }))
                            }
                          />
                        </td>
                        <td className="px-2 py-1 text-right">
                          <Input
                            className="num h-7 text-right"
                            value={progress[r.id]?.stored ?? "0.00"}
                            onChange={(e) =>
                              setProgress((p) => ({
                                ...p,
                                [r.id]: { work: p[r.id]?.work ?? "0.00", stored: e.target.value },
                              }))
                            }
                          />
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-2 py-1">
                          <Checkbox
                            checked={!!selected[r.id]}
                            disabled={billed}
                            onCheckedChange={(v) =>
                              setSelected((s) => ({ ...s, [r.id]: v === true }))
                            }
                          />
                        </td>
                        <td className="px-2 py-1">{r.name}</td>
                        <td className="num px-2 py-1 text-right">
                          {money(r.scheduled_value_cents)}
                        </td>
                        <td className="px-2 py-1 text-right text-xs text-muted-foreground">
                          {billed ? "Billed" : "Open"}
                        </td>
                      </>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {isCostPlus && (
          <div className="rounded-lg border">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b px-3 py-2">
              <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                Backup documents
              </div>
              <div className="text-xs text-muted-foreground">
                {attachedCount} attached
                {missingRequired.length > 0 &&
                  ` · ${missingRequired.length} suggested item${missingRequired.length > 1 ? "s" : ""} missing`}
              </div>
            </div>
            <ul className="divide-y">
              {requirements.map((q) => {
                const list = files[q.id] ?? [];
                return (
                  <li key={q.id} className="px-3 py-2">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-medium">{q.label}</span>
                          <span
                            className={cn(
                              "rounded-full border px-1.5 py-0.5 text-[10px] uppercase tracking-wider",
                              q.required
                                ? list.length
                                  ? "border-primary/40 text-primary"
                                  : "border-warning/50 text-warning"
                                : "text-muted-foreground",
                            )}
                          >
                            {q.required ? (list.length ? "Attached" : "Required") : "Optional"}
                          </span>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground">{q.detail}</p>
                      </div>
                      <label className="shrink-0">
                        <input
                          type="file"
                          multiple
                          className="hidden"
                          onChange={(e) => {
                            addFiles(q.id, e.target.files);
                            e.target.value = "";
                          }}
                        />
                        <span className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs hover:bg-muted">
                          <Upload className="h-3.5 w-3.5" /> Attach
                        </span>
                      </label>
                    </div>
                    {list.length > 0 && (
                      <ul className="mt-1.5 space-y-1">
                        {list.map((f, i) => (
                          <li
                            key={`${f.name}-${i}`}
                            className="flex items-center justify-between gap-2 rounded bg-muted/50 px-2 py-1 text-xs"
                          >
                            <span className="flex min-w-0 items-center gap-1.5">
                              <Paperclip className="h-3 w-3 shrink-0 text-muted-foreground" />
                              <span className="truncate">{f.name}</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => removeFile(q.id, i)}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </li>
                );
              })}
              <li className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
                <div>
                  <div className="text-sm font-medium">Other backup</div>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Anything else you want attached to this request
                  </p>
                  {(files["other"] ?? []).length > 0 && (
                    <ul className="mt-1.5 space-y-1">
                      {(files["other"] ?? []).map((f, i) => (
                        <li
                          key={`${f.name}-${i}`}
                          className="flex items-center justify-between gap-2 rounded bg-muted/50 px-2 py-1 text-xs"
                        >
                          <span className="flex min-w-0 items-center gap-1.5">
                            <Paperclip className="h-3 w-3 shrink-0 text-muted-foreground" />
                            <span className="truncate">{f.name}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => removeFile("other", i)}
                            className="text-muted-foreground hover:text-foreground"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <label className="shrink-0">
                  <input
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      addFiles("other", e.target.files);
                      e.target.value = "";
                    }}
                  />
                  <span className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs hover:bg-muted">
                    <Upload className="h-3.5 w-3.5" /> Attach
                  </span>
                </label>
              </li>
            </ul>
          </div>
        )}

        <dl className="rounded-lg border text-sm">
          <Row label="Billed this period" value={money(thisPeriod)} />
          {isCostPlus && (
            <>
              <Row label="Total completed and on site to date" value={money(completedToDate)} />
              <Row label={`Retainage (${pct(retainagePct, 0)})`} value={money(retainage)} />
              <Row label="Less previous applications" value={money(previousCertificates)} />
            </>
          )}
          <Row
            label={isCostPlus ? "Amount requested" : "Invoice total"}
            value={money(amountDue)}
            strong
          />
        </dl>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => submit.mutate()}
            disabled={submit.isPending || amountDue === 0 || (!isCostPlus && billable.length === 0)}
          >
            {submit.isPending ? "Saving…" : isCostPlus ? "Create draw request" : "Create invoice"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b px-3 py-2 last:border-0">
      <dt className={strong ? "font-medium" : "text-muted-foreground"}>{label}</dt>
      <dd className={strong ? "num font-medium" : "num"}>{value}</dd>
    </div>
  );
}
