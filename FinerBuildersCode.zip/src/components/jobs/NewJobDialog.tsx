import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CONTRACT_TYPES,
  FEE_STYLES,
  JOB_TYPES,
  type ContractType,
  type FeeStyle,
  type JobType,
} from "@/lib/domain";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export function NewJobDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [client, setClient] = useState("");
  const [address, setAddress] = useState("");
  const [jobType, setJobType] = useState<JobType>("whole_house_remodel");
  const [contractType, setContractType] = useState<ContractType>("fixed_price");
  const [feeStyle, setFeeStyle] = useState<FeeStyle>("percent_of_cost");
  const [fee, setFee] = useState("20");
  const [contingency, setContingency] = useState("5");
  const [target, setTarget] = useState("25");
  const [floor, setFloor] = useState("18");
  const [notes, setNotes] = useState("");
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { user } = useAuth();

  const create = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("jobs")
        .insert({
          name,
          client_name: client || null,
          address: address || null,
          job_type: jobType,
          contract_type: contractType,
          fee_style: feeStyle,
          fee_percent: Number(fee) / 100,
          contingency_percent: contractType === "cost_plus" ? Number(contingency) / 100 : 0,
          target_margin: Number(target) / 100,
          margin_floor: Number(floor) / 100,
          notes: notes || null,
          created_by: user?.id ?? null,
        })
        .select("id")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (job) => {
      void qc.invalidateQueries({ queryKey: ["jobs"] });
      setOpen(false);
      setName("");
      setClient("");
      setAddress("");
      setNotes("");
      void navigate({ to: "/jobs/$jobId", params: { jobId: job.id } });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not create job"),
  });

  const costPlus = contractType === "cost_plus";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="mr-1.5 h-4 w-4" /> New job
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">New job</DialogTitle>
          <DialogDescription>
            Contract type decides how this job gets proposed, billed, and tracked — set it now.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="grid gap-2 sm:grid-cols-2">
            {CONTRACT_TYPES.map((c) => (
              <button
                key={c.value}
                type="button"
                onClick={() => setContractType(c.value)}
                className={cn(
                  "rounded-md border p-3 text-left transition-colors",
                  contractType === c.value
                    ? "border-primary bg-primary/5"
                    : "hover:border-muted-foreground/40",
                )}
              >
                <div className="text-sm font-medium">{c.label}</div>
                <div className="mt-0.5 text-xs leading-snug text-muted-foreground">{c.blurb}</div>
              </button>
            ))}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="job-name">Job name</Label>
            <Input
              id="job-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Hillcrest kitchen"
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="client">Client</Label>
              <Input id="client" value={client} onChange={(e) => setClient(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Job type</Label>
              <Select value={jobType} onValueChange={(v) => setJobType(v as JobType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {JOB_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="address">Address</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>

          {costPlus && (
            <div className="space-y-4 rounded-md border bg-muted/30 p-3">
              <div className="space-y-1.5">
                <Label>Fee style</Label>
                <Select value={feeStyle} onValueChange={(v) => setFeeStyle(v as FeeStyle)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FEE_STYLES.map((f) => (
                      <SelectItem key={f.value} value={f.value}>
                        {f.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {FEE_STYLES.find((f) => f.value === feeStyle)?.blurb}
                </p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {feeStyle === "percent_of_cost" && (
                  <div className="space-y-1.5">
                    <Label htmlFor="fee">Fee %</Label>
                    <Input
                      id="fee"
                      className="num"
                      value={fee}
                      onChange={(e) => setFee(e.target.value)}
                    />
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="contingency">Contingency %</Label>
                  <Input
                    id="contingency"
                    className="num"
                    value={contingency}
                    onChange={(e) => setContingency(e.target.value)}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="target">Target margin %</Label>
              <Input
                id="target"
                className="num"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="floor">Margin floor %</Label>
              <Input
                id="floor"
                className="num"
                value={floor}
                onChange={(e) => setFloor(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => create.mutate()} disabled={!name.trim() || create.isPending}>
            Create job
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
