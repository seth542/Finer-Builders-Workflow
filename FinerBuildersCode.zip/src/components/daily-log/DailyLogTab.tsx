import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { dailyLogsQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { Camera, ImageOff, Loader2, Trash2, X } from "lucide-react";
import { formatDate } from "@/lib/format";

const kb = (n: number) =>
  n > 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`;

function sanitizeFileName(name: string) {
  return name.replace(/[^a-zA-Z0-9.-]/g, "_").toLowerCase();
}

function uniquePath(jobId: string, logId: string, fileName: string) {
  const base = `${jobId}/${logId}/${Date.now()}_${sanitizeFileName(fileName)}`;
  return base.replace(/\/+/g, "/");
}

function profileDisplayName(profile: unknown): string {
  if (profile && typeof profile === "object") {
    const p = profile as { full_name?: string | null; email?: string | null };
    return p.full_name ?? p.email ?? "Team member";
  }
  return "Team member";
}

function LogPhotoThumbnail({
  photo,
  onClick,
}: {
  photo: {
    id: string;
    file_path: string | null;
    file_name: string;
    mime_type: string | null;
    size_bytes: number;
  };
  onClick: () => void;
}) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!photo.file_path) return;
    let mounted = true;
    supabase.storage
      .from("daily-log-photos")
      .createSignedUrl(photo.file_path, 60 * 60)
      .then(({ data, error }) => {
        if (mounted && data && !error) setUrl(data.signedUrl);
      });
    return () => {
      mounted = false;
    };
  }, [photo.file_path]);

  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative h-20 w-20 overflow-hidden rounded-md border bg-muted"
    >
      {url ? (
        <img
          src={url}
          alt={photo.file_name}
          className="h-full w-full object-cover transition group-hover:scale-105"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}
      <span className="absolute inset-0 flex items-center justify-center bg-black/0 text-[10px] text-white opacity-0 transition group-hover:bg-black/40 group-hover:opacity-100">
        {kb(photo.size_bytes)}
      </span>
    </button>
  );
}

export function DailyLogTab({ jobId }: { jobId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const logs = useQuery(dailyLogsQuery(jobId));
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState<string>(() => new Date().toISOString().split("T")[0] ?? "");
  const [notes, setNotes] = useState<string>("");
  const [weather, setWeather] = useState<string>("");
  const [files, setFiles] = useState<File[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);

  const createLog = useMutation({
    mutationFn: async () => {
      const { data: log, error } = await supabase
        .from("daily_logs")
        .insert({ job_id: jobId, log_date: date, notes, weather, created_by: user?.id ?? null })
        .select("id")
        .single();
      if (error) throw error;

      if (files.length > 0) {
        const uploads = await Promise.all(
          files.map(async (file) => {
            const path = uniquePath(jobId, log.id, file.name);
            const { error: up } = await supabase.storage
              .from("daily-log-photos")
              .upload(path, file);
            if (up) throw up;
            return {
              log_id: log.id,
              file_name: file.name,
              file_path: path,
              mime_type: file.type,
              size_bytes: file.size,
            };
          }),
        );
        const { error: ie } = await supabase.from("daily_log_photos").insert(uploads);
        if (ie) throw ie;
      }
      return log;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["daily-logs", jobId] });
      setDate(new Date().toISOString().split("T")[0] ?? "");
      setNotes("");
      setWeather("");
      setFiles([]);
      setOpen(false);
      toast.success("Daily log saved");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save log"),
  });

  const deleteLog = useMutation({
    mutationFn: async (id: string) => {
      const { data: photos } = await supabase
        .from("daily_log_photos")
        .select("file_path")
        .eq("log_id", id);
      const paths = (photos ?? [])
        .map((p) => p.file_path)
        .filter((p): p is string => typeof p === "string");
      if (paths.length > 0) {
        const { error: se } = await supabase.storage.from("daily-log-photos").remove(paths);
        if (se) throw se;
      }
      const { error } = await supabase.from("daily_logs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["daily-logs", jobId] }),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not delete log"),
  });

  const openPhoto = useMutation({
    mutationFn: async (path: string) => {
      const { data, error } = await supabase.storage
        .from("daily-log-photos")
        .createSignedUrl(path, 60 * 10);
      if (error) throw error;
      return data.signedUrl;
    },
    onSuccess: (url) => setLightbox(url),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not open photo"),
  });

  const entries = logs.data ?? [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl tracking-tight">Daily log</h2>
          <p className="text-sm text-muted-foreground">Field notes and photos for this job.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Camera className="mr-2 h-4 w-4" /> New daily log
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>New daily log</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Date</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Notes</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="What happened on site today?"
                  rows={4}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Weather</Label>
                <Input
                  value={weather}
                  onChange={(e) => setWeather(e.target.value)}
                  placeholder="e.g. Sunny, 72°F"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Photos</Label>
                <Input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
                />
                {files.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {files.length} file{files.length === 1 ? "" : "s"} selected
                  </p>
                )}
              </div>
              <Button
                className="w-full"
                onClick={() => createLog.mutate()}
                disabled={createLog.isPending || !date}
              >
                {createLog.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save daily log
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {entries.length === 0 ? (
        <div className="rounded-lg border border-dashed p-10 text-center">
          <ImageOff className="mx-auto h-8 w-8 text-muted-foreground" />
          <h3 className="mt-3 font-display text-lg">No daily logs yet</h3>
          <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">
            Add a log entry to keep track of site progress, notes, and photos.
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {entries.map((entry) => (
            <Card key={entry.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-display text-lg">{formatDate(entry.log_date)}</div>
                    <div className="text-xs text-muted-foreground">
                      {profileDisplayName(entry.profiles)}
                      {entry.weather && ` · ${entry.weather}`}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={() => deleteLog.mutate(entry.id)}
                    disabled={deleteLog.isPending}
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              </CardHeader>
              {entry.notes && (
                <CardContent className="pb-3 pt-0">
                  <p className="whitespace-pre-wrap text-sm">{entry.notes}</p>
                </CardContent>
              )}
              {(entry.daily_log_photos ?? []).length > 0 && (
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-2">
                    {(entry.daily_log_photos ?? [])
                      .filter((p) => !!p.file_path)
                      .map((photo) => (
                        <LogPhotoThumbnail
                          key={photo.id}
                          photo={photo}
                          onClick={() => openPhoto.mutate(photo.file_path!)}
                        />
                      ))}
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!lightbox} onOpenChange={() => setLightbox(null)}>
        <DialogContent className="max-w-3xl p-0">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2 z-10 bg-black/40 text-white hover:bg-black/60"
              onClick={() => setLightbox(null)}
            >
              <X className="h-4 w-4" />
            </Button>
            {lightbox && (
              <img
                src={lightbox}
                alt="Photo"
                className="max-h-[80vh] w-full rounded-lg object-contain"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
