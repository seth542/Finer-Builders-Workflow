import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { syncQuickbooksCosts } from "@/lib/integrations.functions";
import { qbInboxQuery } from "@/lib/queries";
import { formatDate, money } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Inbox, RefreshCw, X } from "lucide-react";
import { toast } from "sonner";

type Line = { id: string; description: string; phase_id: string };
type Phase = { id: string; name: string };

function guessCostType(accountName: string | null, vendor: string | null) {
  const s = `${accountName ?? ""} ${vendor ?? ""}`.toLowerCase();
  if (/sub|install|labor.*sub|framing|plumb|electric|hvac|drywall|roof/.test(s)) return "sub";
  if (/material|supply|lumber|home depot|hardware|tile|fixture/.test(s)) return "material";
  if (/payroll|wages|labor/.test(s)) return "labor";
  if (/rental|equipment|dumpster|tool/.test(s)) return "equipment";
  return "other";
}

export function CostInbox({
  jobId,
  phases,
  lines,
}: {
  jobId: string;
  phases: Phase[];
  lines: Line[];
}) {
  const qc = useQueryClient();
  const inbox = useQuery(qbInboxQuery(jobId));
  const sync = useServerFn(syncQuickbooksCosts);
  const [showUnassigned, setShowUnassigned] = useState(false);

  const rows = useMemo(() => {
    const all = inbox.data ?? [];
    return showUnassigned ? all : all.filter((r) => r.job_id === jobId);
  }, [inbox.data, jobId, showUnassigned]);

  const otherCount = (inbox.data ?? []).filter((r) => r.job_id !== jobId).length;

  const runSync = useMutation({
    mutationFn: async () => sync({ data: {} }),
    onSuccess: (r) => {
      void qc.invalidateQueries({ queryKey: ["qb-inbox", jobId] });
      toast.success(`Pulled ${r.pulled} transactions · ${r.matched} auto-matched to a job`);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "QuickBooks sync failed"),
  });

  const assign = useMutation({
    mutationFn: async ({ txn, lineId }: { txn: any; lineId: string }) => {
      const line = lines.find((l) => l.id === lineId);
      const externalRef = `${txn.qb_type}:${txn.qb_id}`;
      // Safety net: never log the same QuickBooks transaction twice.
      const { data: existing } = await supabase
        .from("job_costs")
        .select("id")
        .eq("external_ref", externalRef)
        .maybeSingle();
      if (existing) {
        await supabase
          .from("qb_transactions")
          .update({ status: "matched", matched_cost_id: existing.id })
          .eq("id", txn.id);
        throw new Error("That QuickBooks transaction was already logged as a cost.");
      }
      const { data: cost, error } = await supabase
        .from("job_costs")
        .insert({
          job_id: jobId,
          line_item_id: lineId || null,
          phase_id: line?.phase_id ?? null,
          cost_type: guessCostType(txn.account_name, txn.vendor) as never,
          vendor: txn.vendor,
          description: txn.memo || txn.account_name || `${txn.qb_type} ${txn.doc_number ?? ""}`,
          amount_cents: txn.amount_cents,
          incurred_on: txn.txn_date,
          source: "quickbooks",
          external_ref: externalRef,
        })
        .select("id")
        .single();
      if (error) {
        if (error.code === "23505" || /duplicate key/i.test(error.message))
          throw new Error("That QuickBooks transaction was already logged as a cost.");
        throw error;
      }
      const { error: upErr } = await supabase
        .from("qb_transactions")
        .update({ status: "matched", job_id: jobId, matched_cost_id: cost.id })
        .eq("id", txn.id);
      if (upErr) throw upErr;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["qb-inbox", jobId] });
      void qc.invalidateQueries({ queryKey: ["job-costs", jobId] });
      toast.success("Cost matched to the budget");
    },
    onError: (e) => {
      void qc.invalidateQueries({ queryKey: ["qb-inbox", jobId] });
      toast.error(e instanceof Error ? e.message : "Could not match cost");
    },
  });


  const ignore = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("qb_transactions")
        .update({ status: "ignored" })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["qb-inbox", jobId] }),
  });

  return (
    <section className="rounded-xl border bg-card">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-3">
        <div>
          <h4 className="flex items-center gap-1.5 font-display text-sm">
            <Inbox className="h-4 w-4 text-muted-foreground" /> QuickBooks cost inbox
            {rows.length > 0 && (
              <Badge variant="secondary" className="num">
                {rows.length}
              </Badge>
            )}
          </h4>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Read-only pull from QuickBooks — nothing is sent back. Transactions are matched to this
            job by the QuickBooks job name, then you drop each one on a budget line. A transaction
            can only be logged once.
          </p>

        </div>
        <div className="flex items-center gap-2">
          {otherCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs"
              onClick={() => setShowUnassigned((v) => !v)}
            >
              {showUnassigned ? "Hide" : `Show ${otherCount} unmatched`}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            disabled={runSync.isPending}
            onClick={() => runSync.mutate()}
          >
            <RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${runSync.isPending ? "animate-spin" : ""}`} />
            {runSync.isPending ? "Syncing" : "Sync QuickBooks"}
          </Button>
        </div>
      </header>

      {rows.length === 0 ? (
        <p className="px-4 py-6 text-center text-xs text-muted-foreground">
          Nothing waiting. Run a sync to pull the latest bills and expenses.
        </p>
      ) : (
        <ul className="divide-y">
          {rows.map((t) => (
            <li key={t.id} className="flex flex-wrap items-center gap-2 px-4 py-2.5 text-sm">
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{t.vendor || "Unknown vendor"}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {formatDate(t.txn_date)} · {t.qb_type}
                  {t.doc_number ? ` #${t.doc_number}` : ""}
                  {t.qb_customer ? ` · ${t.qb_customer}` : ""}
                  {t.memo ? ` · ${t.memo}` : ""}
                </p>
              </div>
              <span className="num shrink-0 font-medium">{money(t.amount_cents)}</span>
              <Select onValueChange={(lineId) => assign.mutate({ txn: t, lineId })}>
                <SelectTrigger className="h-8 w-full text-xs sm:w-56">
                  <SelectValue placeholder="Match to budget line" />
                </SelectTrigger>
                <SelectContent>
                  {phases.map((p) => (
                    <SelectGroup key={p.id}>
                      <SelectLabel>{p.name}</SelectLabel>
                      {lines
                        .filter((l) => l.phase_id === p.id)
                        .map((l) => (
                          <SelectItem key={l.id} value={l.id}>
                            {l.description || "Untitled line"}
                          </SelectItem>
                        ))}
                    </SelectGroup>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0"
                title="Ignore"
                onClick={() => ignore.mutate(t.id)}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
