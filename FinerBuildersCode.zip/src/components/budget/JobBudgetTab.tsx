import { Fragment, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  drawRequestsQuery,
  jobCostsQuery,
  linesQuery,
  phasesQuery,
  scheduleItemsQuery,
  scheduleQuery,
} from "@/lib/queries";
import { lineCostCents, lineSellCents, num } from "@/lib/estimate-math";
import { formatDate, money, parseMoneyToCents, pct } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronRight, EyeOff, FilePlus, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { BillingDialog } from "@/components/payments/BillingDialog";
import { CostInbox } from "@/components/budget/CostInbox";

const COST_TYPES = [
  { value: "sub", label: "Subcontractor" },
  { value: "material", label: "Material" },
  { value: "labor", label: "Labor" },
  { value: "equipment", label: "Equipment" },
  { value: "other", label: "Other" },
] as const;

type CostType = (typeof COST_TYPES)[number]["value"];

const costTypeLabel = (v: string) => COST_TYPES.find((c) => c.value === v)?.label ?? v;

export function JobBudgetTab({
  job,
  estimateId,
  estimateDefaultMultiplier,
}: {
  job: { id: string; name: string };
  estimateId: string;
  estimateDefaultMultiplier: number;
}) {
  const qc = useQueryClient();
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const costs = useQuery(jobCostsQuery(job.id));
  const schedule = useQuery(scheduleQuery(job.id));
  const scheduleId = schedule.data?.id ?? "";
  const items = useQuery(scheduleItemsQuery(scheduleId));
  const draws = useQuery(drawRequestsQuery(job.id));

  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [billingOpen, setBillingOpen] = useState(false);
  const [entryFor, setEntryFor] = useState<{ lineId: string; label: string } | null>(null);
  const [pendingDup, setPendingDup] = useState<{
    line_item_id: string | null;
    phase_id: string | null;
    cost_type: CostType;
    vendor: string;
    description: string;
    amount_cents: number;
    incurred_on: string;
    force?: boolean;
  } | null>(null);


  const allPhases = phases.data ?? [];
  const allLines = lines.data ?? [];
  const allCosts = costs.data ?? [];

  const actualsByLine = useMemo(() => {
    const map = new Map<string, number>();
    for (const c of allCosts) {
      if (!c.line_item_id) continue;
      map.set(c.line_item_id, (map.get(c.line_item_id) ?? 0) + c.amount_cents);
    }
    return map;
  }, [allCosts]);

  const unassigned = allCosts.filter((c) => !c.line_item_id);
  const unassignedTotal = unassigned.reduce((s, c) => s + c.amount_cents, 0);

  const groups = allPhases.map((p) => {
    const rows = allLines
      .filter((l) => l.phase_id === p.id)
      .map((l) => {
        const budget = lineCostCents(l);
        const price = lineSellCents(l, p, estimateDefaultMultiplier);
        const actual = actualsByLine.get(l.id) ?? 0;
        return { line: l, budget, price, actual, variance: budget - actual, profit: price - actual };
      });
    return {
      phase: p,
      rows,
      budget: rows.reduce((s, r) => s + r.budget, 0),
      price: rows.reduce((s, r) => s + r.price, 0),
      actual: rows.reduce((s, r) => s + r.actual, 0),
    };
  });

  const totalBudget = groups.reduce((s, g) => s + g.budget, 0);
  const totalPrice = groups.reduce((s, g) => s + g.price, 0);
  const totalActual = groups.reduce((s, g) => s + g.actual, 0) + unassignedTotal;
  const projectedProfit = totalPrice - Math.max(totalActual, 0);
  const budgetedProfit = totalPrice - totalBudget;

  const addCost = useMutation({
    mutationFn: async (payload: {
      line_item_id: string | null;
      phase_id: string | null;
      cost_type: CostType;
      vendor: string;
      description: string;
      amount_cents: number;
      incurred_on: string;
      force?: boolean;
    }) => {
      const { force, ...row } = payload;
      // Safety net: block an obvious re-entry of the same cost on this job.
      if (!force) {
        const dup = allCosts.find(
          (c) =>
            c.amount_cents === row.amount_cents &&
            (c.vendor ?? "").trim().toLowerCase() === row.vendor.trim().toLowerCase() &&
            Math.abs(
              (new Date(c.incurred_on).getTime() - new Date(row.incurred_on).getTime()) / 86_400_000,
            ) <= 3,
        );
        if (dup) {
          const err = new Error("duplicate");
          (err as Error & { duplicate?: boolean }).duplicate = true;
          throw err;
        }
      }
      const { error } = await supabase.from("job_costs").insert({ job_id: job.id, ...row });
      if (error) {
        if (error.code === "23505" || /duplicate key/i.test(error.message))
          throw new Error("That QuickBooks transaction is already logged on a job.");
        throw error;
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["job-costs", job.id] });
      toast.success("Cost logged");
      setEntryFor(null);
      setPendingDup(null);
    },
    onError: (e, vars) => {
      if ((e as Error & { duplicate?: boolean }).duplicate) {
        setPendingDup(vars);
        return;
      }
      toast.error(e instanceof Error ? e.message : "Could not log cost");
    },
  });


  const removeCost = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("job_costs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["job-costs", job.id] }),
  });

  const scheduleRows = items.data ?? [];
  const retainagePct = num(schedule.data?.retainage_percent, 0);
  const previousCertificates = (draws.data ?? []).reduce(
    (s, d) => s + d.amount_requested_cents,
    0,
  );
  const scheduleReady = !!schedule.data?.approved_at && scheduleRows.length > 0;

  if (!estimateId || allLines.length === 0) {
    return (
      <div className="rounded-xl border border-dashed bg-card px-5 py-10 text-center">
        <h3 className="font-display text-lg">Job budget</h3>
        <p className="mx-auto mt-1.5 max-w-md text-sm text-muted-foreground">
          The budget is built from the estimate. Add estimate line items first.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg">Job budget</h3>
          <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
            <EyeOff className="h-3.5 w-3.5" /> Internal only — never shown to clients. Client
            billing runs off the payment schedule.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setEntryFor({ lineId: "", label: "Unassigned" })}
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Log cost
          </Button>
          <Button size="sm" disabled={!scheduleReady} onClick={() => setBillingOpen(true)}>
            <FilePlus className="mr-1.5 h-3.5 w-3.5" /> Create invoice
          </Button>
        </div>
      </div>

      {!scheduleReady && (
        <p className="text-xs text-muted-foreground">
          Approve the payment schedule to enable invoicing.
        </p>
      )}

      <div className="grid gap-3 sm:grid-cols-4">
        <Mini label="Contract price" value={money(totalPrice)} />
        <Mini label="Budgeted cost" value={money(totalBudget)} />
        <Mini
          label="Actual cost"
          value={money(totalActual)}
          {...(totalActual > totalBudget ? { tone: "alert" as const } : {})}
        />
        <Mini
          label="Projected profit"
          value={`${money(projectedProfit)} · ${totalPrice > 0 ? pct(projectedProfit / totalPrice) : "—"}`}
          tone={projectedProfit < budgetedProfit ? "warning" : "ok"}
        />
      </div>

      <CostInbox jobId={job.id} phases={allPhases} lines={allLines} />

      <div className="overflow-x-auto rounded-xl border bg-card">
        <table className="w-full min-w-[900px] text-sm">
          <thead>
            <tr className="border-b bg-secondary/40 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
              <th className="px-3 py-2 text-left font-medium">Line</th>
              <th className="px-3 py-2 text-right font-medium">Budget cost</th>
              <th className="px-3 py-2 text-right font-medium">Actual cost</th>
              <th className="px-3 py-2 text-right font-medium">Variance</th>
              <th className="px-3 py-2 text-right font-medium">Price</th>
              <th className="px-3 py-2 text-right font-medium">Profit</th>
              <th className="w-24 px-3 py-2" />
            </tr>
          </thead>
          {groups.map((g) => (
            <tbody key={g.phase.id} className="border-b last:border-b-0">
              <tr className="bg-secondary/20">
                <td className="px-3 py-2 font-medium">{g.phase.name}</td>
                <td className="num px-3 py-2 text-right">{money(g.budget)}</td>
                <td className="num px-3 py-2 text-right">{money(g.actual)}</td>
                <td
                  className={cn(
                    "num px-3 py-2 text-right",
                    g.budget - g.actual < 0 && "text-destructive",
                  )}
                >
                  {money(g.budget - g.actual)}
                </td>
                <td className="num px-3 py-2 text-right">{money(g.price)}</td>
                <td className="num px-3 py-2 text-right">{money(g.price - g.actual)}</td>
                <td className="px-3 py-2" />
              </tr>
              {g.rows.map((r) => {
                const entries = allCosts.filter((c) => c.line_item_id === r.line.id);
                const isOpen = !!open[r.line.id];
                return (
                  <Fragment key={r.line.id}>
                    <tr className="border-t">
                      <td className="px-3 py-1.5">
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 text-left hover:underline"
                          onClick={() => setOpen((o) => ({ ...o, [r.line.id]: !isOpen }))}
                        >
                          {isOpen ? (
                            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                          )}
                          {r.line.description || "Untitled line"}
                          {entries.length > 0 && (
                            <Badge variant="secondary" className="ml-1 num">
                              {entries.length}
                            </Badge>
                          )}
                        </button>
                      </td>
                      <td className="num px-3 py-1.5 text-right">{money(r.budget)}</td>
                      <td className="num px-3 py-1.5 text-right">{money(r.actual)}</td>
                      <td
                        className={cn(
                          "num px-3 py-1.5 text-right",
                          r.variance < 0 && "text-destructive",
                        )}
                      >
                        {money(r.variance)}
                      </td>
                      <td className="num px-3 py-1.5 text-right">{money(r.price)}</td>
                      <td
                        className={cn(
                          "num px-3 py-1.5 text-right",
                          r.profit < 0 && "text-destructive",
                        )}
                      >
                        {money(r.profit)}
                      </td>
                      <td className="px-3 py-1.5 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs"
                          onClick={() =>
                            setEntryFor({
                              lineId: r.line.id,
                              label: r.line.description || "Untitled line",
                            })
                          }
                        >
                          <Plus className="mr-1 h-3 w-3" /> Cost
                        </Button>
                      </td>
                    </tr>
                    {isOpen &&
                      (entries.length === 0 ? (
                        <tr key={`${r.line.id}-empty`} className="border-t bg-muted/20">
                          <td colSpan={7} className="px-9 py-2 text-xs text-muted-foreground">
                            No costs logged against this line yet.
                          </td>
                        </tr>
                      ) : (
                        entries.map((c) => (
                          <tr key={c.id} className="border-t bg-muted/20 text-xs">
                            <td className="px-9 py-1.5">
                              <span className="text-muted-foreground">
                                {formatDate(c.incurred_on)} · {costTypeLabel(c.cost_type)}
                                {c.source !== "manual" ? ` · ${c.source}` : ""}
                              </span>{" "}
                              {c.vendor && <span className="font-medium">{c.vendor}</span>}{" "}
                              {c.description}
                            </td>
                            <td />
                            <td className="num px-3 py-1.5 text-right">{money(c.amount_cents)}</td>
                            <td colSpan={3} />
                            <td className="px-3 py-1.5 text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 px-2"
                                onClick={() => removeCost.mutate(c.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </td>
                          </tr>
                        ))
                      ))}
                  </Fragment>
                );
              })}
            </tbody>
          ))}
          <tfoot>
            {unassigned.length > 0 && (
              <tr className="border-t bg-muted/20 text-xs">
                <td className="px-3 py-2 text-muted-foreground">
                  Unassigned costs ({unassigned.length})
                </td>
                <td />
                <td className="num px-3 py-2 text-right">{money(unassignedTotal)}</td>
                <td colSpan={4} />
              </tr>
            )}
            <tr className="border-t bg-secondary/40 font-medium">
              <td className="px-3 py-2">Job total</td>
              <td className="num px-3 py-2 text-right">{money(totalBudget)}</td>
              <td className="num px-3 py-2 text-right">{money(totalActual)}</td>
              <td
                className={cn(
                  "num px-3 py-2 text-right",
                  totalBudget - totalActual < 0 && "text-destructive",
                )}
              >
                {money(totalBudget - totalActual)}
              </td>
              <td className="num px-3 py-2 text-right">{money(totalPrice)}</td>
              <td className="num px-3 py-2 text-right">{money(projectedProfit)}</td>
              <td className="px-3 py-2" />
            </tr>
          </tfoot>
        </table>
      </div>

      <CostEntryDialog
        target={entryFor}
        lines={allLines.map((l) => ({
          id: l.id,
          phase_id: l.phase_id,
          description: l.description || "Untitled line",
        }))}
        phases={allPhases.map((p) => ({ id: p.id, name: p.name }))}
        onClose={() => setEntryFor(null)}
        onSave={(v) => addCost.mutate(v)}
        saving={addCost.isPending}
      />

      <Dialog open={!!pendingDup} onOpenChange={(v) => !v && setPendingDup(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Possible double entry</DialogTitle>
            <DialogDescription>
              This job already has a cost for{" "}
              <span className="num font-medium">{money(pendingDup?.amount_cents ?? 0)}</span>
              {pendingDup?.vendor ? ` from ${pendingDup.vendor}` : ""} around{" "}
              {pendingDup ? formatDate(pendingDup.incurred_on) : ""}. Log it anyway only if this is a
              separate invoice or receipt.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPendingDup(null)}>
              Cancel
            </Button>
            <Button
              disabled={addCost.isPending}
              onClick={() => pendingDup && addCost.mutate({ ...pendingDup, force: true })}
            >
              Log anyway
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {scheduleReady && (
        <BillingDialog
          open={billingOpen}
          onOpenChange={setBillingOpen}
          isCostPlus={false}
          jobId={job.id}
          jobName={job.name}
          scheduleId={scheduleId}
          rows={scheduleRows}
          retainagePct={retainagePct}
          previousCertificates={previousCertificates}
          nextNumber={((draws.data ?? [])[0]?.number ?? 0) + 1}
          onDone={() => {
            void qc.invalidateQueries({ queryKey: ["schedule-items", scheduleId] });
            void qc.invalidateQueries({ queryKey: ["draw-requests", job.id] });
          }}
        />
      )}
    </div>
  );
}

function CostEntryDialog({
  target,
  lines,
  phases,
  onClose,
  onSave,
  saving,
}: {
  target: { lineId: string; label: string } | null;
  lines: { id: string; phase_id: string; description: string }[];
  phases: { id: string; name: string }[];
  onClose: () => void;
  onSave: (v: {
    line_item_id: string | null;
    phase_id: string | null;
    cost_type: CostType;
    vendor: string;
    description: string;
    amount_cents: number;
    incurred_on: string;
  }) => void;
  saving: boolean;
}) {
  const [lineId, setLineId] = useState("");
  const [costType, setCostType] = useState<CostType>("sub");
  const [vendor, setVendor] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  const open = !!target;
  const effectiveLine = target?.lineId || lineId;
  const phaseName = (id: string) => phases.find((p) => p.id === id)?.name ?? "";

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          onClose();
          setLineId("");
          setVendor("");
          setDescription("");
          setAmount("");
        }
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Log actual cost</DialogTitle>
          <DialogDescription>
            Sub invoices and material purchases post against a budget line.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {target?.lineId ? (
            <div className="rounded-lg border bg-secondary/30 px-3 py-2 text-sm">
              {target.label}
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label>Budget line</Label>
              <Select value={lineId} onValueChange={setLineId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a line" />
                </SelectTrigger>
                <SelectContent>
                  {lines.map((l) => (
                    <SelectItem key={l.id} value={l.id}>
                      {phaseName(l.phase_id)} — {l.description}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={costType} onValueChange={(v) => setCostType(v as CostType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {COST_TYPES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Amount</Label>
              <Input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="$0.00"
                className="num"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Vendor / sub</Label>
              <Input value={vendor} onChange={(e) => setVendor(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Note</Label>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Invoice #, PO, receipt detail"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            disabled={saving || !effectiveLine || parseMoneyToCents(amount) === 0}
            onClick={() => {
              const line = lines.find((l) => l.id === effectiveLine);
              onSave({
                line_item_id: effectiveLine || null,
                phase_id: line?.phase_id ?? null,
                cost_type: costType,
                vendor,
                description,
                amount_cents: parseMoneyToCents(amount),
                incurred_on: date,
              });
              setVendor("");
              setDescription("");
              setAmount("");
              setLineId("");
            }}
          >
            Log cost
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Mini({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "ok" | "warning" | "alert" | undefined;
}) {
  return (
    <div className="rounded-lg border bg-card px-3 py-2.5">
      <div className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{label}</div>
      <div
        className={cn(
          "num mt-1 text-lg font-medium",
          tone === "alert" && "text-destructive",
          tone === "warning" && "text-amber-600",
        )}
      >
        {value}
      </div>
    </div>
  );
}
