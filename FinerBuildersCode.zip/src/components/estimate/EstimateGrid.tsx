import { Fragment, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { linesQuery, phasesQuery } from "@/lib/queries";
import { COST_TYPES, METHODS, subtypesFor, type CostType, type EstimateMethod } from "@/lib/domain";
import {
  effectiveMultiplier,
  lineCostCents,
  lineSellCents,
  multiplierForMargin,
  num,
  rollup,
} from "@/lib/estimate-math";
import { money, mult, parseMoneyToCents, pct } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronRight, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { LibraryPanel } from "@/components/estimate/LibraryPanel";

type Line = {
  id: string;
  phase_id: string;
  description: string;
  method: EstimateMethod;
  method_subtype: string;
  cost_type: CostType;
  quantity: number;
  unit_cost_cents: number;
  multiplier: number | null;
  vendor: string | null;
  sort_order: number;
};

export function EstimateGrid({
  estimateId,
  estimateDefaultMultiplier,
  costPlus,
}: {
  estimateId: string;
  estimateDefaultMultiplier: number;
  costPlus?: { feePercent: number; contingencyPercent: number } | null;
}) {
  const qc = useQueryClient();
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));

  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["lines", estimateId] });
    void qc.invalidateQueries({ queryKey: ["phases", estimateId] });
    void qc.invalidateQueries({ queryKey: ["job-totals"] });
  };

  const updateLine = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<Line> }) => {
      const { error } = await supabase.from("estimate_line_items").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save line"),
  });

  const addLine = useMutation({
    mutationFn: async (phaseId: string) => {
      const count = (lines.data ?? []).filter((l) => l.phase_id === phaseId).length;
      const { error } = await supabase.from("estimate_line_items").insert({
        phase_id: phaseId,
        description: "",
        sort_order: count,
      });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const deleteLine = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("estimate_line_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const updatePhase = useMutation({
    mutationFn: async ({ id, multiplier }: { id: string; multiplier: number | null }) => {
      const { error } = await supabase
        .from("estimate_phases")
        .update({ default_multiplier: multiplier })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const addPhase = useMutation({
    mutationFn: async (name: string) => {
      const { error } = await supabase.from("estimate_phases").insert({
        estimate_id: estimateId,
        name,
        sort_order: (phases.data?.length ?? 0) + 1,
      });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const allPhases = phases.data ?? [];
  const allLines = (lines.data ?? []) as Line[];

  const totals = useMemo(
    () => rollup(allLines, allPhases, estimateDefaultMultiplier),
    [allLines, allPhases, estimateDefaultMultiplier],
  );

  const cpContingency = costPlus ? Math.round(totals.cost * costPlus.contingencyPercent) : 0;
  const cpFee = costPlus ? Math.round(totals.cost * costPlus.feePercent) : 0;
  const cpTotal = totals.cost + cpContingency + cpFee;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
          Estimate detail · execution sequence
        </div>
        <div className="flex items-center gap-2">
          <LibraryPanel
            phases={allPhases}
            estimateId={estimateId}
            lineCountFor={(phaseId: string) =>
              allLines.filter((l) => l.phase_id === phaseId).length
            }
            onInserted={invalidate}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const name = window.prompt("Phase name");
              if (name?.trim()) addPhase.mutate(name.trim());
            }}
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Phase
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full min-w-[1100px] text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="w-[26%] px-2 py-2 font-medium">Description</th>
              <th className="px-2 py-2 font-medium">Method</th>
              <th className="px-2 py-2 font-medium">Unit</th>
              <th className="px-2 py-2 font-medium">Type</th>
              <th className="px-2 py-2 text-right font-medium">Qty</th>
              <th className="px-2 py-2 text-right font-medium">Unit cost</th>
              <th className="px-2 py-2 text-right font-medium">Cost</th>
              {!costPlus && (
                <>
                  <th className="px-2 py-2 text-right font-medium">Mult</th>
                  <th className="px-2 py-2 text-right font-medium">Price</th>
                  <th className="px-2 py-2 text-right font-medium">Margin</th>
                </>
              )}

              <th className="w-8" />
            </tr>
          </thead>
          <tbody>
            {allPhases.map((phase) => {
              const phaseLines = allLines.filter((l) => l.phase_id === phase.id);
              const pCost = phaseLines.reduce((s, l) => s + lineCostCents(l), 0);
              const pSell = phaseLines.reduce(
                (s, l) => s + lineSellCents(l, phase, estimateDefaultMultiplier),
                0,
              );
              const isCollapsed = collapsed[phase.id];
              return (
                <Fragment key={phase.id}>
                  <tr className="border-t bg-secondary/40">
                    <td className="px-2 py-1.5" colSpan={4}>
                      <button
                        className="flex items-center gap-1.5 font-semibold"
                        onClick={() => setCollapsed((c) => ({ ...c, [phase.id]: !c[phase.id] }))}
                      >
                        {isCollapsed ? (
                          <ChevronRight className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronDown className="h-3.5 w-3.5" />
                        )}
                        {phase.name}
                        <span className="ml-1 text-xs font-normal text-muted-foreground">
                          {phaseLines.length}
                        </span>
                      </button>
                    </td>
                    <td colSpan={2} />
                    <td className="num px-2 py-1.5 text-right font-medium">{money(pCost)}</td>
                    {!costPlus && (
                      <>
                        <td className="px-2 py-1.5 text-right">
                          <CellInput
                            value={phase.default_multiplier ? String(phase.default_multiplier) : ""}
                            placeholder="—"
                            align="right"
                            onCommit={(v) =>
                              updatePhase.mutate({
                                id: phase.id,
                                multiplier: v.trim() === "" ? null : num(v, 0) || null,
                              })
                            }
                          />
                        </td>
                        <td className="num px-2 py-1.5 text-right font-medium">{money(pSell)}</td>
                        <td className="num px-2 py-1.5 text-right text-muted-foreground">
                          {pSell > 0 ? pct((pSell - pCost) / pSell, 0) : "—"}
                        </td>
                      </>
                    )}

                    <td className="px-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => addLine.mutate(phase.id)}
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                  {!isCollapsed &&
                    phaseLines.map((line) => {
                      const cost = lineCostCents(line);
                      const m = effectiveMultiplier(line, phase, estimateDefaultMultiplier);
                      const sell = Math.round(cost * m);
                      return (
                        <tr key={line.id} className="border-t hover:bg-muted/30">
                          <td className="px-2 py-1">
                            <CellInput
                              value={line.description}
                              placeholder="Scope item…"
                              onCommit={(v) =>
                                updateLine.mutate({ id: line.id, patch: { description: v } })
                              }
                            />
                          </td>
                          <td className="px-2 py-1">
                            <MiniSelect
                              value={line.method}
                              options={METHODS.map((mo) => ({ value: mo.value, label: mo.label }))}
                              onChange={(v) =>
                                updateLine.mutate({
                                  id: line.id,
                                  patch: {
                                    method: v as EstimateMethod,
                                    method_subtype: subtypesFor(v as EstimateMethod)[0] ?? "each",
                                  },
                                })
                              }
                            />
                          </td>
                          <td className="px-2 py-1">
                            <MiniSelect
                              value={line.method_subtype}
                              options={subtypesFor(line.method).map((s) => ({
                                value: s,
                                label: s,
                              }))}
                              onChange={(v) =>
                                updateLine.mutate({ id: line.id, patch: { method_subtype: v } })
                              }
                            />
                          </td>
                          <td className="px-2 py-1">
                            <MiniSelect
                              value={line.cost_type}
                              options={COST_TYPES}
                              onChange={(v) =>
                                updateLine.mutate({
                                  id: line.id,
                                  patch: { cost_type: v as CostType },
                                })
                              }
                            />
                          </td>
                          <td className="px-2 py-1 text-right">
                            <CellInput
                              align="right"
                              value={String(line.quantity)}
                              onCommit={(v) =>
                                updateLine.mutate({
                                  id: line.id,
                                  patch: { quantity: num(v, 0) },
                                })
                              }
                            />
                          </td>
                          <td className="px-2 py-1 text-right">
                            <CellInput
                              align="right"
                              value={(line.unit_cost_cents / 100).toFixed(2)}
                              onCommit={(v) =>
                                updateLine.mutate({
                                  id: line.id,
                                  patch: { unit_cost_cents: parseMoneyToCents(v) },
                                })
                              }
                            />
                          </td>
                          <td className="num px-2 py-1 text-right text-muted-foreground">
                            {money(cost, { cents: true })}
                          </td>
                          {!costPlus && (
                            <>
                              <td className="px-2 py-1 text-right">
                                <CellInput
                                  align="right"
                                  placeholder={m.toFixed(2)}
                                  value={line.multiplier ? String(line.multiplier) : ""}
                                  onCommit={(v) =>
                                    updateLine.mutate({
                                      id: line.id,
                                      patch: {
                                        multiplier: v.trim() === "" ? null : num(v, 0) || null,
                                      },
                                    })
                                  }
                                />
                              </td>
                              <td className="num px-2 py-1 text-right font-medium">
                                {money(sell, { cents: true })}
                              </td>
                              <td className="num px-2 py-1 text-right text-muted-foreground">
                                {sell > 0 ? pct((sell - cost) / sell, 0) : "—"}
                              </td>
                            </>
                          )}

                          <td className="px-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-muted-foreground hover:text-destructive"
                              onClick={() => deleteLine.mutate(line.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                </Fragment>
              );
            })}
          </tbody>
          <tfoot>
            {costPlus ? (
              <>
                <tr className="border-t-2 bg-secondary/40 font-medium">
                  <td className="px-2 py-2" colSpan={6}>
                    Direct cost of work
                  </td>
                  <td className="num px-2 py-2 text-right">{money(totals.cost)}</td>
                  <td />
                </tr>
                <tr className="border-t bg-secondary/40">
                  <td className="px-2 py-2" colSpan={6}>
                    Contingency ({pct(costPlus.contingencyPercent, 1)} of cost)
                  </td>
                  <td className="num px-2 py-2 text-right">{money(cpContingency)}</td>
                  <td />
                </tr>
                <tr className="border-t bg-secondary/40">
                  <td className="px-2 py-2" colSpan={6}>
                    General contractor fee ({pct(costPlus.feePercent, 1)} of cost)
                  </td>
                  <td className="num px-2 py-2 text-right">{money(cpFee)}</td>
                  <td />
                </tr>
                <tr className="border-t-2 bg-secondary/70 font-semibold">
                  <td className="px-2 py-2" colSpan={6}>
                    Estimated total to client · {mult(totals.cost > 0 ? cpTotal / totals.cost : 1)}{" "}
                    of cost
                  </td>
                  <td className="num px-2 py-2 text-right">{money(cpTotal)}</td>
                  <td />
                </tr>
              </>
            ) : (
              <tr className="border-t-2 bg-secondary/60 font-medium">
                <td className="px-2 py-2" colSpan={6}>
                  Estimate total
                </td>
                <td className="num px-2 py-2 text-right">{money(totals.cost)}</td>
                <td className="num px-2 py-2 text-right">{mult(totals.blended || 1)}</td>
                <td className="num px-2 py-2 text-right">{money(totals.sell)}</td>
                <td className="num px-2 py-2 text-right">{pct(totals.margin, 1)}</td>
                <td />
              </tr>
            )}
          </tfoot>
        </table>
      </div>
      <p className="text-xs text-muted-foreground">
        {costPlus
          ? "Cost plus: line multipliers stay at 1.00x so costs pass through at cost. Your money is the contingency and GC fee lines at the bottom."
          : `Blank multiplier inherits the phase multiplier, then the estimate default. Target margin ${pct(0.25, 0)} needs ${mult(multiplierForMargin(0.25))}.`}
      </p>
    </div>
  );
}

function CellInput({
  value,
  onCommit,
  placeholder,
  align = "left",
}: {
  value: string;
  onCommit: (v: string) => void;
  placeholder?: string;
  align?: "left" | "right";
}) {
  const [draft, setDraft] = useState(value);
  const [focused, setFocused] = useState(false);
  return (
    <Input
      value={focused ? draft : value}
      placeholder={placeholder}
      onFocus={() => {
        setDraft(value);
        setFocused(true);
      }}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        setFocused(false);
        if (draft !== value) onCommit(draft);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
        if (e.key === "Escape") {
          setDraft(value);
          (e.target as HTMLInputElement).blur();
        }
      }}
      className={cn(
        "h-7 border-transparent bg-transparent px-1.5 shadow-none focus-visible:border-input focus-visible:bg-background",
        align === "right" && "num text-right",
      )}
    />
  );
}

function MiniSelect({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-7 border-transparent bg-transparent px-1.5 text-xs shadow-none focus:border-input focus:bg-background">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} className="text-xs">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
