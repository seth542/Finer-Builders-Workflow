import { useQuery } from "@tanstack/react-query";
import { linesQuery, phasesQuery } from "@/lib/queries";
import { costPlusTotals, lineCostCents, lineSellCents, num, rollup } from "@/lib/estimate-math";
import { money, pct } from "@/lib/format";
import { LogoHorizontal } from "@/components/Brand";
import type { ContractType, FeeStyle } from "@/lib/domain";
import { buildSchedule, formatDate, formatShort, parseDate } from "@/lib/schedule";

export function ProposalView({
  estimateId,
  estimateDefaultMultiplier,
  jobName,
  clientName,
  address,
  contractType,
  feeStyle,
  feePercent,
  contingencyPercent,
  startDate,
  targetEndDate,
  scheduleNotes,
}: {
  estimateId: string;
  estimateDefaultMultiplier: number;
  jobName: string;
  clientName: string | null;
  address: string | null;
  contractType: ContractType;
  feeStyle: FeeStyle;
  feePercent: number | string | null;
  contingencyPercent: number | string | null;
  startDate?: string | null;
  targetEndDate?: string | null;
  scheduleNotes?: string | null;
}) {
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const allPhases = phases.data ?? [];
  const allLines = lines.data ?? [];
  const totals = rollup(allLines, allPhases, estimateDefaultMultiplier);
  const cp = costPlusTotals({
    cost: totals.cost,
    sell: totals.sell,
    feeStyle,
    feePercent,
    contingencyPercent,
  });
  const isCostPlus = contractType === "cost_plus";

  const constructionStart = parseDate(startDate);
  const built = constructionStart
    ? buildSchedule({
        phases: allPhases.map((p) => {
          const phaseLines = allLines.filter((l) => l.phase_id === p.id);
          return {
            id: p.id,
            name: p.name,
            durationDays: p.duration_days ?? null,
            costCents: phaseLines.reduce(
              (s, l) =>
                s +
                (isCostPlus ? lineCostCents(l) : lineSellCents(l, p, estimateDefaultMultiplier)),
              0,
            ),
          };
        }),
        start: constructionStart,
        targetEnd: parseDate(targetEndDate),
      })
    : null;

  const allowances = allLines.filter((l) => l.method === "allowance");

  return (
    <div className="mx-auto max-w-3xl rounded-lg border bg-card p-8 md:p-12">
      <LogoHorizontal className="h-10" />
      <div className="mt-8 border-b pb-6">
        <h2 className="font-display text-3xl">{jobName}</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {clientName ?? "Client"}
          {address ? ` · ${address}` : ""}
        </p>
        <p className="mt-3 text-xs uppercase tracking-[0.14em] text-muted-foreground">
          {isCostPlus ? "Cost plus proposal" : "Fixed price proposal"}
        </p>
      </div>

      <table className="mt-6 w-full text-sm">
        <tbody>
          {allPhases.map((phase) => {
            const phaseLines = allLines.filter((l) => l.phase_id === phase.id);
            if (phaseLines.length === 0) return null;
            const amount = isCostPlus
              ? phaseLines.reduce((s, l) => s + lineCostCents(l), 0)
              : phaseLines.reduce(
                  (s, l) => s + lineSellCents(l, phase, estimateDefaultMultiplier),
                  0,
                );
            return (
              <tr key={phase.id} className="border-b last:border-0">
                <td className="py-3 align-top">
                  <div className="font-medium">{phase.name}</div>
                  <div className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {phaseLines
                      .map((l) => l.description)
                      .filter(Boolean)
                      .join(" · ")}
                  </div>
                </td>
                <td className="num w-32 py-3 text-right align-top font-medium">{money(amount)}</td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          {isCostPlus ? (
            <>
              <tr className="border-t">
                <td className="pt-4">Estimated cost of work</td>
                <td className="num pt-4 text-right">{money(cp.cost)}</td>
              </tr>
              {cp.contingency > 0 && (
                <tr>
                  <td className="pt-1.5">
                    Contingency ({pct(num(contingencyPercent), 0)} of estimated cost)
                  </td>
                  <td className="num pt-1.5 text-right">{money(cp.contingency)}</td>
                </tr>
              )}
              <tr>
                <td className="pt-1.5">
                  Builder fee
                  {feeStyle === "percent_of_cost" ? ` (${pct(num(feePercent), 0)} of cost)` : ""}
                </td>
                <td className="num pt-1.5 text-right">{money(cp.fee)}</td>
              </tr>
              <tr className="border-t-2">
                <td className="pt-4 font-display text-lg">Estimated total</td>
                <td className="num pt-4 text-right font-display text-lg">{money(cp.total)}</td>
              </tr>
            </>
          ) : (
            <tr className="border-t-2">
              <td className="pt-4 font-display text-lg">Total contract price</td>
              <td className="num pt-4 text-right font-display text-lg">{money(totals.sell)}</td>
            </tr>
          )}
        </tfoot>
      </table>

      {allowances.length > 0 && (
        <div className="mt-8 rounded-md border bg-muted/30 p-4">
          <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Allowances — selections still open
          </h3>
          <ul className="mt-3 space-y-1.5 text-sm">
            {allowances.map((l) => (
              <li key={l.id} className="flex justify-between gap-4">
                <span>{l.description || "Allowance"}</span>
                <span className="num">
                  {money(
                    isCostPlus
                      ? lineCostCents(l)
                      : lineSellCents(
                          l,
                          allPhases.find((p) => p.id === l.phase_id),
                          estimateDefaultMultiplier,
                        ),
                  )}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {built && built.phases.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Estimated schedule
          </h3>
          <p className="mt-2 text-sm">
            Construction start <span className="font-medium">{formatDate(built.start)}</span> ·
            estimated substantial completion{" "}
            <span className="font-medium">
              {formatDate(parseDate(targetEndDate) ?? built.finish)}
            </span>{" "}
            <span className="text-muted-foreground">({built.totalDays} working days)</span>
          </p>
          <table className="mt-3 w-full text-sm">
            <tbody>
              {built.phases.map((p) => (
                <tr key={p.id} className="border-b last:border-0">
                  <td className="py-2">{p.name}</td>
                  <td className="w-48 py-2 text-right text-muted-foreground">
                    {formatShort(p.start)} – {formatShort(p.finish)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
            Dates are estimates based on working days and assume timely selections, permits, and
            inspections. {scheduleNotes ?? ""}
          </p>
        </div>
      )}

      <p className="mt-8 text-xs leading-relaxed text-muted-foreground">
        {isCostPlus
          ? "Costs shown are estimates and are billed at actual cost with the builder fee applied. Progress draws are billed monthly against the schedule of values. Contingency is drawn only as needed and any unused balance stays with you."
          : "Allowances are estimates and will be reconciled at actual cost. Price valid 30 days."}{" "}
        Selections finalized before the corresponding phase begins. Change orders in writing.
      </p>
    </div>
  );
}
