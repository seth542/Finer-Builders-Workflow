import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { assembliesQuery, libraryQuery } from "@/lib/queries";
import { money } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Library } from "lucide-react";
import { toast } from "sonner";

type Phase = { id: string; name: string };

export function LibraryPanel({
  phases,
  lineCountFor,
  onInserted,
}: {
  phases: Phase[];
  estimateId: string;
  lineCountFor: (phaseId: string) => number;
  onInserted: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [phaseId, setPhaseId] = useState(phases[0]?.id ?? "");
  const items = useQuery(libraryQuery());
  const assemblies = useQuery(assembliesQuery());

  const targetPhase = phaseId || phases[0]?.id || "";

  const insertItem = useMutation({
    mutationFn: async (item: {
      name: string;
      method: string;
      method_subtype: string;
      cost_type: string;
      unit_cost_cents: number;
      default_multiplier: number | null;
    }) => {
      if (!targetPhase) throw new Error("Add a phase first");
      const { error } = await supabase.from("estimate_line_items").insert({
        phase_id: targetPhase,
        description: item.name,
        method: item.method as never,
        method_subtype: item.method_subtype,
        cost_type: item.cost_type as never,
        unit_cost_cents: item.unit_cost_cents,
        quantity: 1,
        multiplier: item.default_multiplier,
        sort_order: lineCountFor(targetPhase),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      onInserted();
      toast.success("Added to estimate");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add item"),
  });

  const insertAssembly = useMutation({
    mutationFn: async (assembly: {
      name: string;
      assembly_components: {
        description: string;
        unit: string;
        cost_type: string;
        quantity: number;
        unit_cost_cents: number;
      }[];
    }) => {
      if (!targetPhase) throw new Error("Add a phase first");
      const base = lineCountFor(targetPhase);
      const rows = assembly.assembly_components.map((c, i) => ({
        phase_id: targetPhase,
        description: `${assembly.name} — ${c.description}`,
        method: "assembly" as never,
        method_subtype: c.unit,
        cost_type: c.cost_type as never,
        quantity: c.quantity,
        unit_cost_cents: c.unit_cost_cents,
        sort_order: base + i,
      }));
      const { error } = await supabase.from("estimate_line_items").insert(rows);
      if (error) throw error;
    },
    onSuccess: () => {
      onInserted();
      toast.success("Assembly exploded into lines");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add assembly"),
  });

  const q = search.trim().toLowerCase();
  const filteredItems = (items.data ?? []).filter((i) => i.name.toLowerCase().includes(q));
  const filteredAssemblies = (assemblies.data ?? []).filter((a) =>
    a.name.toLowerCase().includes(q),
  );

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm">
          <Library className="mr-1.5 h-3.5 w-3.5" /> Cost library
        </Button>
      </SheetTrigger>
      <SheetContent className="flex w-full flex-col gap-0 sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="font-display text-xl">Cost library</SheetTitle>
          <SheetDescription>Insert priced items or whole assemblies into a phase.</SheetDescription>
        </SheetHeader>
        <div className="space-y-2 px-4 pb-3">
          <Select value={targetPhase} onValueChange={setPhaseId}>
            <SelectTrigger>
              <SelectValue placeholder="Insert into phase" />
            </SelectTrigger>
            <SelectContent>
              {phases.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input placeholder="Search…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Tabs defaultValue="items" className="flex min-h-0 flex-1 flex-col px-4 pb-4">
          <TabsList className="w-full">
            <TabsTrigger value="items" className="flex-1">
              Items
            </TabsTrigger>
            <TabsTrigger value="assemblies" className="flex-1">
              Assemblies
            </TabsTrigger>
          </TabsList>
          <TabsContent value="items" className="mt-3 min-h-0 flex-1 space-y-1 overflow-y-auto">
            {filteredItems.map((item) => (
              <button
                key={item.id}
                onClick={() =>
                  insertItem.mutate({
                    name: item.name,
                    method: item.method,
                    method_subtype: item.method_subtype,
                    cost_type: item.cost_type,
                    unit_cost_cents: item.unit_cost_cents,
                    default_multiplier: item.default_multiplier,
                  })
                }
                className="flex w-full items-center justify-between rounded-md border px-3 py-2 text-left text-sm transition-colors hover:border-primary/40 hover:bg-muted/40"
              >
                <span>
                  {item.name}
                  <span className="ml-2 text-xs text-muted-foreground">
                    {item.method_subtype} · {item.cost_type}
                  </span>
                </span>
                <span className="num shrink-0 text-xs">
                  {money(item.unit_cost_cents, { cents: true })}
                </span>
              </button>
            ))}
          </TabsContent>
          <TabsContent value="assemblies" className="mt-3 min-h-0 flex-1 space-y-1 overflow-y-auto">
            {filteredAssemblies.map((a) => {
              const total = (a.assembly_components ?? []).reduce(
                (s, c) => s + c.quantity * c.unit_cost_cents,
                0,
              );
              return (
                <button
                  key={a.id}
                  onClick={() => insertAssembly.mutate(a)}
                  className="flex w-full items-center justify-between rounded-md border px-3 py-2 text-left text-sm transition-colors hover:border-primary/40 hover:bg-muted/40"
                >
                  <span>
                    {a.name}
                    <span className="ml-2 text-xs text-muted-foreground">
                      {(a.assembly_components ?? []).length} components / {a.unit}
                    </span>
                  </span>
                  <span className="num shrink-0 text-xs">{money(total)}</span>
                </button>
              );
            })}
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
