import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  linesQuery,
  phasesQuery,
  scheduleItemsQuery,
  scheduleQuery,
  selectionsQuery,
} from "@/lib/queries";
import { lineCostCents, lineSellCents, num } from "@/lib/estimate-math";
import { money } from "@/lib/format";
import {
  DAY_MS,
  buildSchedule,
  formatDate,
  formatShort,
  minusWorkdays,
  parseDate,
  toISODate,
  type ScheduledPhase,
} from "@/lib/schedule";
import type { ContractType } from "@/lib/domain";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { CalendarDays, Eye, Users } from "lucide-react";
import { toast } from "sonner";

type Job = {
  id: string;
  name: string;
  contract_type: ContractType;
  start_date: string | null;
  target_end_date: string | null;
  schedule_notes: string | null;
};

export function ScheduleTab({
  job,
  estimateId,
  estimateDefaultMultiplier,
}: {
  job: Job;
  estimateId: string;
  estimateDefaultMultiplier: number;
}) {
  const qc = useQueryClient();
  const [clientView, setClientView] = useState(false);

  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const selections = useQuery(selectionsQuery(job.id));
  const schedule = useQuery(scheduleQuery(job.id));
  const scheduleId = schedule.data?.id ?? "";
  const items = useQuery(scheduleItemsQuery(scheduleId));

  const isCostPlus = job.contract_type === "cost_plus";
  const allPhases = phases.data ?? [];
  const allLines = lines.data ?? [];

  const updateJob = useMutation({
    mutationFn: async (patch: Partial<Job>) => {
      const { error } = await supabase.from("jobs").update(patch).eq("id", job.id);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["job", job.id] });
      void qc.invalidateQueries({ queryKey: ["jobs"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save"),
  });

  const setDuration = useMutation({
    mutationFn: async ({ phaseId, days }: { phaseId: string; days: number | null }) => {
      const { error } = await supabase
        .from("estimate_phases")
        .update({ duration_days: days })
        .eq("id", phaseId);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["phases", estimateId] }),
  });

  const built = useMemo(() => {
    const start =
      parseDate(job.start_date) ??
      new Date(
        Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate()),
      );
    const input = allPhases.map((p) => {
      const phaseLines = allLines.filter((l) => l.phase_id === p.id);
      const cost = isCostPlus
        ? phaseLines.reduce((s, l) => s + lineCostCents(l), 0)
        : phaseLines.reduce((s, l) => s + lineSellCents(l, p, estimateDefaultMultiplier), 0);
      return {
        id: p.id,
        name: p.name,
        durationDays: p.duration_days ?? null,
        costCents: cost,
      };
    });
    return buildSchedule({ phases: input, start, targetEnd: parseDate(job.target_end_date) });
  }, [
    allPhases,
    allLines,
    isCostPlus,
    estimateDefaultMultiplier,
    job.start_date,
    job.target_end_date,
  ]);

  const byPhase = useMemo(() => new Map(built.phases.map((p) => [p.id, p])), [built.phases]);

  // Payment milestones dated off the phases they cover.
  const milestones = useMemo(() => {
    const out: { id: string; name: string; date: Date | null; amount: number; note: string }[] = [];
    for (const item of items.data ?? []) {
      const phaseIds = (item.payment_item_phases ?? []).map((p) => p.phase_id);
      const covered = phaseIds.map((id) => byPhase.get(id)).filter((p): p is ScheduledPhase => !!p);
      let date: Date | null = null;
      let note = "";
      if (item.trigger === "on_signing") {
        date = built.start;
        note = "On signing";
      } else if (item.trigger === "date") {
        date = parseDate(item.due_date);
        note = "Fixed date";
      } else if (item.trigger === "phase_start" && covered.length > 0) {
        date = covered.reduce((a, b) => (a.start < b.start ? a : b)).start;
        note = "Phase start";
      } else if (covered.length > 0) {
        date = covered.reduce((a, b) => (a.finish > b.finish ? a : b)).finish;
        note = item.trigger === "progress" ? "% complete" : "Phase complete";
      } else {
        date = parseDate(item.due_date);
        note = "Unlinked";
      }
      out.push({
        id: item.id,
        name: item.name || "Payment",
        date,
        amount: item.scheduled_value_cents,
        note,
      });
    }
    return out.sort((a, b) => (a.date?.getTime() ?? 0) - (b.date?.getTime() ?? 0));
  }, [items.data, byPhase, built.start]);

  // Selections must be decided ahead of the phase they feed.
  const selectionDeadlines = useMemo(() => {
    return (selections.data ?? [])
      .map((s) => {
        const phase = s.due_before_phase_id ? byPhase.get(s.due_before_phase_id) : undefined;
        const due = phase ? minusWorkdays(phase.start, 10) : null;
        return { ...s, phaseName: phase?.name ?? null, due };
      })
      .filter((s) => s.status !== "ordered")
      .sort((a, b) => (a.due?.getTime() ?? Infinity) - (b.due?.getTime() ?? Infinity));
  }, [selections.data, byPhase]);

  if (!estimateId) {
    return <p className="text-sm text-muted-foreground">Build the estimate first.</p>;
  }

  const spanStart = built.start.getTime();
  const spanEnd = built.finish?.getTime() ?? spanStart + DAY_MS;
  const span = Math.max(DAY_MS, spanEnd - spanStart);
  const totalAmount = built.phases.reduce((s, p) => s + p.costCents, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Construction start</Label>
            <Input
              type="date"
              className="num w-[160px]"
              key={`start-${job.start_date}`}
              defaultValue={job.start_date ?? ""}
              onChange={(e) => updateJob.mutate({ start_date: e.target.value || null })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Target completion</Label>
            <Input
              type="date"
              className="num w-[160px]"
              key={`end-${job.target_end_date}`}
              defaultValue={job.target_end_date ?? ""}
              onChange={(e) => updateJob.mutate({ target_end_date: e.target.value || null })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Scheduled finish</Label>
            <div className="flex h-9 items-center text-sm font-medium">
              {formatDate(built.finish)}
            </div>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={() => setClientView((v) => !v)}>
          {clientView ? (
            <Users className="mr-1.5 h-3.5 w-3.5" />
          ) : (
            <Eye className="mr-1.5 h-3.5 w-3.5" />
          )}
          {clientView ? "Team view" : "Client view"}
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Metric label="Working days" value={String(built.totalDays)} />
        <Metric label="Phases" value={String(built.phases.length)} />
        <Metric
          label={isCostPlus ? "Estimated cost scheduled" : "Contract value scheduled"}
          value={clientView && isCostPlus ? "—" : money(totalAmount)}
        />
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full min-w-[820px] text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-[0.08em] text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left font-medium">Phase</th>
              <th className="px-3 py-2 text-right font-medium">Days</th>
              <th className="px-3 py-2 text-left font-medium">Start</th>
              <th className="px-3 py-2 text-left font-medium">Finish</th>
              {!clientView && <th className="px-3 py-2 text-right font-medium">Value</th>}
              <th className="px-3 py-2 text-left font-medium">Timeline</th>
            </tr>
          </thead>
          <tbody>
            {built.phases.map((p) => {
              const left = ((p.start.getTime() - spanStart) / span) * 100;
              const width = Math.max(
                2,
                ((p.finish.getTime() - p.start.getTime() + DAY_MS) / span) * 100,
              );
              return (
                <tr key={p.id} className="border-t">
                  <td className="px-3 py-2 font-medium">{p.name}</td>
                  <td className="px-3 py-1.5 text-right">
                    {clientView ? (
                      p.durationDays
                    ) : (
                      <Input
                        className="num h-8 w-16 text-right"
                        key={`d-${p.id}-${p.durationDays}`}
                        defaultValue={String(p.durationDays)}
                        onBlur={(e) => {
                          const v = num(e.target.value, 0);
                          setDuration.mutate({ phaseId: p.id, days: v > 0 ? Math.round(v) : null });
                        }}
                      />
                    )}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatShort(p.start)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatShort(p.finish)}</td>
                  {!clientView && (
                    <td className="num px-3 py-2 text-right">{money(p.costCents)}</td>
                  )}
                  <td className="px-3 py-2">
                    <div className="relative h-2.5 w-full min-w-[180px] rounded-full bg-muted">
                      <div
                        className={cn(
                          "absolute inset-y-0 rounded-full",
                          p.derived ? "bg-primary/45" : "bg-primary",
                        )}
                        style={{ left: `${left}%`, width: `${width}%` }}
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {!clientView && (
        <p className="text-xs text-muted-foreground">
          Lighter bars are durations estimated from each phase&apos;s share of the estimate. Type a
          number of working days to lock a phase; clear it to go back to the estimate-weighted
          guess.
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-lg border p-4">
          <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            <CalendarDays className="h-3.5 w-3.5" />
            {isCostPlus ? "Projected draws" : "Projected payments"}
          </h3>
          {milestones.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              No payment schedule yet — generate one to date the payments.
            </p>
          ) : (
            <ul className="mt-3 space-y-2 text-sm">
              {milestones.map((m) => (
                <li
                  key={m.id}
                  className="flex items-baseline justify-between gap-3 border-b pb-2 last:border-0"
                >
                  <span>
                    <span className="font-medium">{m.name}</span>
                    <span className="ml-2 text-xs text-muted-foreground">{m.note}</span>
                  </span>
                  <span className="flex shrink-0 items-baseline gap-3">
                    <span className="text-xs text-muted-foreground">{formatShort(m.date)}</span>
                    <span className="num">{money(m.amount)}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-lg border p-4">
          <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Selection deadlines
          </h3>
          {selectionDeadlines.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              No open selections tied to a phase.
            </p>
          ) : (
            <ul className="mt-3 space-y-2 text-sm">
              {selectionDeadlines.slice(0, 12).map((s) => (
                <li
                  key={s.id}
                  className="flex items-baseline justify-between gap-3 border-b pb-2 last:border-0"
                >
                  <span>
                    <span className="font-medium">{s.name}</span>
                    {s.phaseName && (
                      <span className="ml-2 text-xs text-muted-foreground">
                        before {s.phaseName}
                      </span>
                    )}
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <Badge variant={s.status === "pending" ? "outline" : "secondary"}>
                      {s.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{formatShort(s.due)}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            Deadlines are set 10 working days ahead of the phase that needs the selection.
          </p>
        </section>
      </div>

      {!clientView && (
        <div className="space-y-1.5">
          <Label>Schedule notes</Label>
          <Textarea
            rows={3}
            key={`notes-${job.schedule_notes ?? ""}`}
            defaultValue={job.schedule_notes ?? ""}
            placeholder="Assumptions the team and client should see — inspection windows, long-lead items, owner-caused delays."
            onBlur={(e) => updateJob.mutate({ schedule_notes: e.target.value || null })}
          />
        </div>
      )}
      {clientView && job.schedule_notes && (
        <p className="text-sm text-muted-foreground">{job.schedule_notes}</p>
      )}
      <p className="text-xs text-muted-foreground">
        Working days only (Mon–Fri). Dates shift automatically when the start date or a phase
        duration changes. Start {formatDate(built.start)} · target{" "}
        {job.target_end_date
          ? formatDate(parseDate(job.target_end_date))
          : toISODate(built.finish ?? built.start)}
      </p>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-card p-3">
      <div className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</div>
      <div className="num mt-1 text-lg font-medium">{value}</div>
    </div>
  );
}
