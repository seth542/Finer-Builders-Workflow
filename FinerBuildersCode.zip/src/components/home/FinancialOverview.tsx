import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { allBillingQuery, allJobTotalsQuery, jobsQuery } from "@/lib/queries";
import { costPlusTotals, type Totals } from "@/lib/estimate-math";
import { money, pct } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const EMPTY: Totals = { cost: 0, sell: 0, profit: 0, margin: 0, blended: 0 };

/** Stages that mean the job is sold (signed / in the ground / wrapping up). */
const SOLD_STAGES = new Set(["contracted", "pre_con", "production", "punch", "closeout"]);

export function FinancialOverview() {
  const jobs = useQuery(jobsQuery());
  const totals = useQuery(allJobTotalsQuery());
  const billing = useQuery(allBillingQuery());

  const summary = useMemo(() => {
    const year = new Date().getFullYear();
    const quarters = [0, 0, 0, 0];
    let sold = 0;
    let soldProfit = 0;
    let soldCost = 0;
    let pipeline = 0;

    for (const job of jobs.data ?? []) {
      const base = totals.data?.[job.id] ?? EMPTY;
      let sell = base.sell;
      let profit = base.profit;
      if (job.contract_type === "cost_plus") {
        const cp = costPlusTotals({
          cost: base.cost,
          sell: base.sell,
          feeStyle: (job.fee_style ?? "percent_of_cost") as "percent_of_cost" | "line_multipliers",
          feePercent: job.fee_percent ?? 0,
          contingencyPercent: job.contingency_percent ?? 0,
        });
        sell = cp.total;
        profit = cp.fee;
      }

      if (SOLD_STAGES.has(job.stage)) {
        const started = new Date(job.start_date ?? job.created_at);
        if (started.getFullYear() === year) {
          sold += sell;
          soldProfit += profit;
          soldCost += base.cost;
          quarters[Math.floor(started.getMonth() / 3)] =
            (quarters[Math.floor(started.getMonth() / 3)] ?? 0) + sell;
        }
      } else {
        pipeline += sell;
      }
    }

    const billed = (billing.data ?? []).reduce((n, d) => n + (d.amount_requested_cents ?? 0), 0);
    const retainage = (billing.data ?? []).reduce((n, d) => n + (d.retainage_cents ?? 0), 0);

    return {
      year,
      sold,
      soldProfit,
      soldMargin: sold > 0 ? soldProfit / sold : 0,
      soldCost,
      pipeline,
      quarters,
      billed,
      retainage,
      remaining: Math.max(sold - billed, 0),
    };
  }, [jobs.data, totals.data, billing.data]);

  const loading = jobs.isLoading || totals.isLoading;
  const quarterMax = Math.max(...summary.quarters, 1);

  const cards = [
    {
      label: `Sold ${summary.year}`,
      value: money(summary.sold),
      hint: "Contract value of signed jobs",
    },
    {
      label: "In pipeline",
      value: money(summary.pipeline),
      hint: "Leads, estimates, proposals out",
    },
    {
      label: "Projected gross profit",
      value: money(summary.soldProfit),
      hint: `${pct(summary.soldMargin)} blended margin on sold work`,
    },
    {
      label: "Billed to date",
      value: money(summary.billed),
      hint: `${money(summary.remaining)} left to bill`,
    },
  ];

  return (
    <section className="mt-10">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl tracking-tight">Financial overview</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Company-wide numbers pulled live from estimates and billing.
          </p>
        </div>
        <Badge variant="outline" className="text-[10px] uppercase tracking-wider">
          {summary.year}
        </Badge>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5 sm:gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="min-w-0 rounded-lg border bg-card p-3 sm:p-4">
            <p className="truncate text-[10px] uppercase tracking-wider text-muted-foreground sm:text-xs">
              {c.label}
            </p>
            <p
              className={cn(
                "mt-1.5 font-display text-xl tracking-tight sm:mt-2 sm:text-2xl",
                loading && "opacity-40",
              )}
            >
              {loading ? "—" : c.value}
            </p>
            <p className="mt-1 text-[11px] leading-snug text-muted-foreground sm:text-xs">
              {c.hint}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-3">
        <div className="rounded-lg border bg-card p-4 lg:col-span-2">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Sold by quarter</p>
          <div className="mt-4 grid grid-cols-4 gap-3">
            {summary.quarters.map((amount, i) => (
              <div key={i} className="flex flex-col justify-end gap-2">
                <div className="flex h-24 items-end">
                  <div
                    className="w-full rounded-t bg-primary/80"
                    style={{ height: `${Math.max((amount / quarterMax) * 100, 2)}%` }}
                  />
                </div>
                <div className="border-t pt-2">
                  <p className="text-xs font-medium">Q{i + 1}</p>
                  <p className="text-xs text-muted-foreground">{money(amount)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Cash position</p>
          <dl className="mt-3 space-y-2 text-sm">
            <Row label="Cost of sold work" value={money(summary.soldCost)} />
            <Row label="Retainage held" value={money(summary.retainage)} />
            <Row label="Left to bill" value={money(summary.remaining)} />
            <Row label="Bank balance" value="Connect QuickBooks" muted />
          </dl>
        </div>
      </div>
    </section>
  );
}

function Row({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className={cn("font-medium tabular-nums", muted && "text-xs text-muted-foreground")}>
        {value}
      </dd>
    </div>
  );
}
