import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { selectionLibraryQuery } from "@/lib/queries";
import { JOB_TYPES, jobTypeLabel, type JobType } from "@/lib/domain";
import { money } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Library, Trash2 } from "lucide-react";
import { toast } from "sonner";

export type LibraryPick = {
  name: string;
  room: string | null;
  phase_hint: string | null;
  allowance_cents: number;
};

export function SelectionLibraryDialog({
  jobType,
  open,
  onOpenChange,
  onInsert,
}: {
  jobType: JobType;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onInsert: (picks: LibraryPick[]) => Promise<void> | void;
}) {
  const qc = useQueryClient();
  const library = useQuery(selectionLibraryQuery());
  const [filterType, setFilterType] = useState<JobType | "all">(jobType);
  const [search, setSearch] = useState("");
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [inserting, setInserting] = useState(false);

  const items = useMemo(() => {
    const all = library.data ?? [];
    const q = search.trim().toLowerCase();
    return all.filter(
      (i) =>
        (filterType === "all" || i.job_type === filterType) &&
        (q === "" ||
          i.name.toLowerCase().includes(q) ||
          (i.room ?? "").toLowerCase().includes(q) ||
          (i.category ?? "").toLowerCase().includes(q)),
    );
  }, [library.data, filterType, search]);

  const selected = items.filter((i) => picked[i.id]);

  const removeItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("selection_library_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["selection-library"] }),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Selection library</DialogTitle>
          <DialogDescription>
            Standard selections saved by project type. Pick the ones this job needs — allowances
            come in as a starting number you can edit.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-wrap gap-2">
          <Select value={filterType} onValueChange={(v) => setFilterType(v as JobType | "all")}>
            <SelectTrigger className="w-[210px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All project types</SelectItem>
              {JOB_TYPES.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            placeholder="Search selections"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-[220px]"
          />
        </div>

        <div className="max-h-[45vh] overflow-y-auto rounded-lg border">
          {items.length === 0 ? (
            <p className="p-6 text-center text-sm text-muted-foreground">
              Nothing saved for {filterType === "all" ? "any type" : jobTypeLabel(filterType)} yet.
            </p>
          ) : (
            <ul className="divide-y">
              {items.map((i) => (
                <li key={i.id} className="flex items-center gap-3 px-3 py-2">
                  <Checkbox
                    checked={!!picked[i.id]}
                    onCheckedChange={(v) => setPicked((p) => ({ ...p, [i.id]: !!v }))}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm">{i.name}</div>
                    <div className="truncate text-xs text-muted-foreground">
                      {[i.room, i.category, i.phase_hint].filter(Boolean).join(" · ")}
                    </div>
                  </div>
                  {filterType === "all" && (
                    <Badge variant="outline" className="hidden shrink-0 sm:inline-flex">
                      {jobTypeLabel(i.job_type as JobType)}
                    </Badge>
                  )}
                  <div className="num w-24 shrink-0 text-right text-sm">
                    {i.default_allowance_cents > 0 ? money(i.default_allowance_cents) : "—"}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => removeItem.mutate(i.id)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <DialogFooter className="sm:justify-between">
          <span className="self-center text-xs text-muted-foreground">
            {selected.length} selected
          </span>
          <Button
            disabled={selected.length === 0 || inserting}
            onClick={async () => {
              setInserting(true);
              try {
                await onInsert(
                  selected.map((i) => ({
                    name: i.name,
                    room: i.room,
                    phase_hint: i.phase_hint,
                    allowance_cents: i.default_allowance_cents,
                  })),
                );
                toast.success(
                  `Added ${selected.length} selection${selected.length === 1 ? "" : "s"}`,
                );
                setPicked({});
                onOpenChange(false);
              } finally {
                setInserting(false);
              }
            }}
          >
            <Library className="mr-1.5 h-3.5 w-3.5" /> Add to job
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
