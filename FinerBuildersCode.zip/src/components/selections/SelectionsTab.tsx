import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { linesQuery, phasesQuery, selectionsQuery } from "@/lib/queries";
import { SELECTION_STATUSES, type JobType, type SelectionStatus } from "@/lib/domain";
import { lineCostCents } from "@/lib/estimate-math";
import { money, parseMoneyToCents } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Library, Plus, Trash2, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { SelectionLibraryDialog, type LibraryPick } from "./SelectionLibraryDialog";

/** Estimate line categories that always imply a client decision. */
const SELECTION_TRIGGERS: { match: RegExp; category: string }[] = [
  { match: /cabinet|vanity|closet system/i, category: "Cabinetry" },
  { match: /countertop|counter top|top[s]?\b|quartz|granite/i, category: "Tops" },
  { match: /tile|stone|backsplash|marble/i, category: "Tile & Stone" },
  { match: /floor|hardwood|lvp|carpet/i, category: "Flooring" },
  {
    match: /plumb.*fixture|faucet|sink|toilet|tub|shower (valve|glass|door)/i,
    category: "Plumbing fixtures",
  },
  { match: /light|pendant|sconce|chandelier|fan\b/i, category: "Lighting" },
  { match: /appliance|range|refrigerator|dishwasher|hood/i, category: "Appliances" },
  { match: /window|exterior door|interior door|door hardware/i, category: "Windows & Doors" },
  { match: /paint|stain|coating/i, category: "Paint" },
  { match: /siding|roof|gutter|trim|fascia/i, category: "Envelope" },
  { match: /hardware|mirror|accessor/i, category: "Specialties" },
];

export function SelectionsTab({
  jobId,
  estimateId,
  jobType,
}: {
  jobId: string;
  estimateId: string;
  jobType: JobType;
}) {
  const qc = useQueryClient();
  const selections = useQuery(selectionsQuery(jobId));
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));
  const rows = selections.data ?? [];
  const allPhases = phases.data ?? [];
  const [libraryOpen, setLibraryOpen] = useState(false);

  const invalidate = () => void qc.invalidateQueries({ queryKey: ["selections", jobId] });

  const add = useMutation({
    mutationFn: async (
      payload: Partial<{
        name: string;
        room: string | null;
        allowance_cents: number;
        line_item_id: string | null;
        due_before_phase_id: string | null;
        sort_order: number;
      }>,
    ) => {
      const { error } = await supabase.from("selections").insert({
        job_id: jobId,
        name: payload.name ?? "New selection",
        room: payload.room ?? null,
        allowance_cents: payload.allowance_cents ?? 0,
        line_item_id: payload.line_item_id ?? null,
        due_before_phase_id: payload.due_before_phase_id ?? null,
        sort_order: payload.sort_order ?? rows.length,
      });
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add selection"),
  });

  const update = useMutation({
    mutationFn: async ({
      id,
      patch,
    }: {
      id: string;
      patch: Database["public"]["Tables"]["selections"]["Update"];
    }) => {
      const { error } = await supabase.from("selections").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("selections").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const phaseIdForHint = (hint: string | null) => {
    if (!hint) return null;
    const h = hint.toLowerCase();
    return (
      allPhases.find((p) => p.name.toLowerCase() === h)?.id ??
      allPhases.find((p) => p.name.toLowerCase().includes(h.split(" ")[0] ?? ""))?.id ??
      null
    );
  };

  const existingNames = new Set(rows.map((r) => r.name.trim().toLowerCase()));
  const trackedLineIds = new Set(rows.map((r) => r.line_item_id).filter(Boolean));
  const allLines = lines.data ?? [];

  /** Every estimate line that implies a client decision: allowances + finish-category lines. */
  const generated = allLines
    .filter((l) => !trackedLineIds.has(l.id))
    .map((l) => {
      const desc = l.description?.trim() ?? "";
      const isAllowance = l.method === "allowance";
      const trigger = SELECTION_TRIGGERS.find((t) => t.match.test(desc));
      if (!isAllowance && !trigger) return null;
      if (!desc && !isAllowance) return null;
      const name = desc || "Allowance";
      if (existingNames.has(name.toLowerCase())) return null;
      return {
        name,
        room: trigger?.category ?? null,
        allowance_cents: lineCostCents(l),
        line_item_id: l.id,
        due_before_phase_id: l.phase_id,
      };
    })
    .filter((v): v is NonNullable<typeof v> => v !== null);

  const pending = rows.filter((r) => r.status === "pending").length;
  const openAllowance = rows
    .filter((r) => r.status === "pending")
    .reduce((s, r) => s + r.allowance_cents, 0);

  const insertLibraryPicks = async (picks: LibraryPick[]) => {
    let i = rows.length;
    for (const p of picks) {
      await add.mutateAsync({
        name: p.name,
        room: p.room,
        allowance_cents: p.allowance_cents,
        due_before_phase_id: phaseIdForHint(p.phase_hint),
        sort_order: i++,
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {rows.length} selection{rows.length === 1 ? "" : "s"} · {pending} pending ·{" "}
          {money(openAllowance)} of allowance still undecided
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setLibraryOpen(true)}>
            <Library className="mr-1.5 h-3.5 w-3.5" /> Selection library
          </Button>
          {generated.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                let i = rows.length;
                for (const g of generated) {
                  await add.mutateAsync({ ...g, sort_order: i++ });
                }
                toast.success(
                  `Generated ${generated.length} selection${generated.length === 1 ? "" : "s"} from the estimate`,
                );
              }}
            >
              <Wand2 className="mr-1.5 h-3.5 w-3.5" /> Auto-generate {generated.length} from
              estimate
            </Button>
          )}
          <Button size="sm" onClick={() => add.mutate({})}>
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Selection
          </Button>
        </div>
      </div>

      <SelectionLibraryDialog
        jobType={jobType}
        open={libraryOpen}
        onOpenChange={setLibraryOpen}
        onInsert={insertLibraryPicks}
      />

      {rows.length === 0 ? (
        <div className="rounded-lg border border-dashed p-10 text-center">
          <h3 className="font-display text-xl">No selections tracked</h3>
          <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
            Every allowance in the estimate is a decision the client still owes you. Pull them in
            here and give each one a deadline phase.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="w-[24%] px-2 py-2 font-medium">Item</th>
                <th className="px-2 py-2 font-medium">Room</th>
                <th className="px-2 py-2 font-medium">Due before</th>
                <th className="px-2 py-2 text-right font-medium">Allowance</th>
                <th className="px-2 py-2 text-right font-medium">Actual</th>
                <th className="px-2 py-2 text-right font-medium">Variance</th>
                <th className="px-2 py-2 font-medium">Status</th>
                <th className="w-8" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const variance =
                  r.actual_cents === null ? null : r.actual_cents - r.allowance_cents;
                return (
                  <tr key={r.id} className="border-t hover:bg-muted/30">
                    <td className="px-2 py-1">
                      <Cell
                        value={r.name}
                        onCommit={(v) => update.mutate({ id: r.id, patch: { name: v } })}
                      />
                    </td>
                    <td className="px-2 py-1">
                      <Cell
                        value={r.room ?? ""}
                        placeholder="—"
                        onCommit={(v) => update.mutate({ id: r.id, patch: { room: v || null } })}
                      />
                    </td>
                    <td className="px-2 py-1">
                      <Select
                        value={r.due_before_phase_id ?? "none"}
                        onValueChange={(v) =>
                          update.mutate({
                            id: r.id,
                            patch: { due_before_phase_id: v === "none" ? null : v },
                          })
                        }
                      >
                        <SelectTrigger className="h-7 border-transparent bg-transparent px-1.5 text-xs shadow-none focus:border-input focus:bg-background">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none" className="text-xs">
                            —
                          </SelectItem>
                          {allPhases.map((p) => (
                            <SelectItem key={p.id} value={p.id} className="text-xs">
                              {p.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-2 py-1 text-right">
                      <Cell
                        align="right"
                        value={(r.allowance_cents / 100).toFixed(2)}
                        onCommit={(v) =>
                          update.mutate({
                            id: r.id,
                            patch: { allowance_cents: parseMoneyToCents(v) },
                          })
                        }
                      />
                    </td>
                    <td className="px-2 py-1 text-right">
                      <Cell
                        align="right"
                        placeholder="—"
                        value={r.actual_cents === null ? "" : (r.actual_cents / 100).toFixed(2)}
                        onCommit={(v) =>
                          update.mutate({
                            id: r.id,
                            patch: {
                              actual_cents: v.trim() === "" ? null : parseMoneyToCents(v),
                            },
                          })
                        }
                      />
                    </td>
                    <td
                      className={cn(
                        "num px-2 py-1 text-right",
                        variance !== null && variance > 0 && "text-destructive",
                        variance !== null && variance < 0 && "text-success",
                      )}
                    >
                      {variance === null
                        ? "—"
                        : `${variance > 0 ? "+" : ""}${money(variance, { cents: true })}`}
                    </td>
                    <td className="px-2 py-1">
                      <Select
                        value={r.status}
                        onValueChange={(v) =>
                          update.mutate({ id: r.id, patch: { status: v as SelectionStatus } })
                        }
                      >
                        <SelectTrigger className="h-7 w-[110px] border-transparent bg-transparent px-1.5 text-xs shadow-none focus:border-input focus:bg-background">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {SELECTION_STATUSES.map((s) => (
                            <SelectItem key={s.value} value={s.value} className="text-xs">
                              {s.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-muted-foreground hover:text-destructive"
                        onClick={() => remove.mutate(r.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {pending > 0 && (
        <Badge variant="outline" className="text-warning">
          {pending} selection{pending === 1 ? "" : "s"} must be decided before their phase starts
        </Badge>
      )}
    </div>
  );
}

function Cell({
  value,
  onCommit,
  placeholder,
  align = "left",
}: {
  value: string;
  onCommit: (v: string) => void;
  placeholder?: string;
  align?: "left" | "right";
}) {
  return (
    <Input
      key={value}
      defaultValue={value}
      placeholder={placeholder}
      onBlur={(e) => {
        if (e.target.value !== value) onCommit(e.target.value);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
      }}
      className={cn(
        "h-7 border-transparent bg-transparent px-1.5 shadow-none focus-visible:border-input focus-visible:bg-background",
        align === "right" && "num text-right",
      )}
    />
  );
}
