export type BackupRequirement = {
  id: string;
  label: string;
  detail: string;
  required: boolean;
};

type DraftLine = {
  name: string;
  work: number;
  stored: number;
  is_contingency: boolean;
  is_fee: boolean;
};

/**
 * Backup options offered with a draw request or invoice.
 * Kept deliberately short: subcontractor invoices, material receipts,
 * and on site material photos.
 */
export function suggestBackup(lines: DraftLine[], _isCostPlus: boolean): BackupRequirement[] {
  const billed = lines.filter((l) => l.work > 0 || l.stored > 0);
  const onSite = billed.filter((l) => l.stored > 0);

  return [
    {
      id: "sub-invoices",
      label: "Subcontractor invoices",
      detail: "Invoices for sub work included in this request",
      required: false,
    },
    {
      id: "material-receipts",
      label: "Material receipts",
      detail: "Supplier receipts and invoices for materials billed",
      required: false,
    },
    {
      id: "onsite-material-photos",
      label: "On site material photos",
      detail:
        onSite.length > 0
          ? onSite.map((l) => l.name).join(", ")
          : "Photos of materials delivered and on site",
      required: onSite.length > 0,
    },
  ];
}
