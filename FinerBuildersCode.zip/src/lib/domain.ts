import type { Database } from "@/integrations/supabase/types";

export type JobStage = Database["public"]["Enums"]["job_stage"];
export type JobType = Database["public"]["Enums"]["job_type"];
export type EstimateMethod = Database["public"]["Enums"]["estimate_method"];
export type CostType = Database["public"]["Enums"]["cost_type"];

export const JOB_STAGES: { value: JobStage; label: string }[] = [
  { value: "lead", label: "Lead" },
  { value: "estimating", label: "Estimating" },
  { value: "proposal_sent", label: "Proposal Sent" },
  { value: "contracted", label: "Contracted" },
  { value: "pre_con", label: "Pre-Con" },
  { value: "production", label: "Production" },
  { value: "punch", label: "Punch" },
  { value: "closeout", label: "Closeout" },
];

export const JOB_TYPES: { value: JobType; label: string }[] = [
  { value: "kitchen_remodel", label: "Kitchen Remodel" },
  { value: "bath_remodel", label: "Bath Remodel" },
  { value: "whole_house_remodel", label: "Whole-House Remodel" },
  { value: "addition", label: "Addition" },
  { value: "custom_home", label: "Custom Home" },
  { value: "adu_garage", label: "ADU / Garage Conversion" },
  { value: "exterior_only", label: "Exterior / Envelope Only" },
  { value: "other", label: "Other" },
];

export const COST_TYPES: { value: CostType; label: string }[] = [
  { value: "labor", label: "Labor" },
  { value: "material", label: "Material" },
  { value: "sub", label: "Sub" },
  { value: "equipment", label: "Equipment" },
  { value: "other", label: "Other" },
];

export const METHODS: {
  value: EstimateMethod;
  label: string;
  subtypes: string[];
  qtyLabel: string;
}[] = [
  {
    value: "square_foot",
    label: "Square Foot",
    subtypes: ["floor area", "wall area", "roof area", "counter area"],
    qtyLabel: "SF",
  },
  {
    value: "unit_cost",
    label: "Unit Cost",
    subtypes: ["each", "LF", "SF", "SY", "CY", "ton", "sheet", "gallon", "day", "hour"],
    qtyLabel: "Qty",
  },
  { value: "assembly", label: "Assembly", subtypes: ["each", "SF", "LF"], qtyLabel: "Qty" },
  { value: "allowance", label: "Allowance", subtypes: ["lump sum"], qtyLabel: "Qty" },
  { value: "sub_bid", label: "Subcontract Bid", subtypes: ["lump sum"], qtyLabel: "Qty" },
  { value: "labor", label: "Labor", subtypes: ["hour", "day"], qtyLabel: "Hrs" },
];

export function methodLabel(method: EstimateMethod) {
  return METHODS.find((m) => m.value === method)?.label ?? method;
}

export function subtypesFor(method: EstimateMethod) {
  return METHODS.find((m) => m.value === method)?.subtypes ?? ["each"];
}

export function stageLabel(stage: JobStage) {
  return JOB_STAGES.find((s) => s.value === stage)?.label ?? stage;
}

export function jobTypeLabel(type: JobType) {
  return JOB_TYPES.find((t) => t.value === type)?.label ?? type;
}

export type ContractType = Database["public"]["Enums"]["contract_type"];
export type FeeStyle = Database["public"]["Enums"]["fee_style"];
export type SelectionStatus = Database["public"]["Enums"]["selection_status"];
export type PaymentTrigger = Database["public"]["Enums"]["payment_trigger"];
export type ScheduleBasis = Database["public"]["Enums"]["schedule_basis"];

export const CONTRACT_TYPES: { value: ContractType; label: string; blurb: string }[] = [
  {
    value: "fixed_price",
    label: "Fixed Price",
    blurb: "Client sees one lump sum. Billed on a milestone payment schedule.",
  },
  {
    value: "cost_plus",
    label: "Cost Plus",
    blurb: "Client sees estimated costs, contingency, and your fee. Billed on progress draws.",
  },
];

export const FEE_STYLES: { value: FeeStyle; label: string; blurb: string }[] = [
  {
    value: "percent_of_cost",
    label: "Percent fee on cost",
    blurb: "One visible fee line, a flat percent of estimated cost.",
  },
  {
    value: "line_multipliers",
    label: "Per-line multipliers",
    blurb: "Keep line multipliers; total markup shows as a single fee amount.",
  },
];

export const SELECTION_STATUSES: { value: SelectionStatus; label: string }[] = [
  { value: "pending", label: "Pending" },
  { value: "decided", label: "Decided" },
  { value: "ordered", label: "Ordered" },
];

export const PAYMENT_TRIGGERS: { value: PaymentTrigger; label: string }[] = [
  { value: "on_signing", label: "On signing" },
  { value: "phase_start", label: "Phase start" },
  { value: "phase_complete", label: "Phase complete" },
  { value: "date", label: "Date" },
  { value: "progress", label: "% complete" },
];

export const SCHEDULE_BASES: { value: ScheduleBasis; label: string; blurb: string }[] = [
  {
    value: "per_phase",
    label: "One payment per phase",
    blurb: "Most detailed — every phase becomes its own milestone.",
  },
  {
    value: "combined",
    label: "Combined stages",
    blurb: "Groups phases into a handful of larger milestones.",
  },
  {
    value: "equal_percent",
    label: "Equal % draws",
    blurb: "Split the contract into equal progress payments.",
  },
];

export function contractLabel(t: ContractType) {
  return CONTRACT_TYPES.find((c) => c.value === t)?.label ?? t;
}

export function feeStyleLabel(f: FeeStyle) {
  return FEE_STYLES.find((s) => s.value === f)?.label ?? f;
}

/** Coarse construction stages used when combining estimate phases into fewer payments. */
export const COMBINED_STAGES: { name: string; match: RegExp }[] = [
  { name: "Demo, site & structure", match: /demo|sitework|concrete|foundation|framing|structur/i },
  {
    name: "Dry-in & rough-ins",
    match: /roof|envelope|window|door|mechanical|plumb|electric|hvac/i,
  },
  { name: "Insulation & drywall", match: /insulat|drywall/i },
  { name: "Finishes & cabinetry", match: /finish|cabinet|top|floor|tile|stone|paint|coating/i },
  {
    name: "Fixtures, exterior & completion",
    match: /special|fixture|landscape|exterior|general|supervis|punch/i,
  },
];

export function combinedStageFor(phaseName: string) {
  return COMBINED_STAGES.find((s) => s.match.test(phaseName))?.name ?? "Other work";
}
