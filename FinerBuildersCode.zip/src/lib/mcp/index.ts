import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listJobs from "./tools/list-jobs";
import getJob from "./tools/get-job";
import listEstimateLines from "./tools/list-estimate-lines";
import listBilling from "./tools/list-billing";
import setJobStage from "./tools/set-job-stage";

const projectRef = import.meta.env["VITE_SUPABASE_PROJECT_ID"] ?? "project-ref-unset";

export default defineMcp({
  name: "finer-builders",
  title: "Finer Builders",
  version: "0.1.0",
  instructions:
    "Tools for the Finer Builders project management app. Read jobs, estimates and billing, and move jobs through the pipeline. All money values are in cents.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  // exactOptionalPropertyTypes makes the SDK's tool union reject the inferred
  // definitions (optional outputSchema); the shapes are correct at runtime.
  tools: [listJobs, getJob, listEstimateLines, listBilling, setJobStage] as unknown as Parameters<
    typeof defineMcp
  >[0]["tools"],
});
