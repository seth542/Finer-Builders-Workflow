import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

const STAGES = [
  "lead",
  "estimating",
  "proposal_sent",
  "contracted",
  "pre_con",
  "production",
  "punch",
  "closeout",
] as const;

export default defineTool({
  name: "set_job_stage",
  title: "Move job stage",
  description: "Move a job to a different pipeline stage.",
  inputSchema: {
    job_id: z.string().uuid().describe("The job id."),
    stage: z.enum(STAGES).describe("The new pipeline stage."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ job_id, stage }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text" as const, text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("jobs")
      .update({ stage })
      .eq("id", job_id)
      .select("id, name, stage")
      .maybeSingle();
    if (error) return { content: [{ type: "text" as const, text: error.message }], isError: true };
    return { content: [{ type: "text" as const, text: JSON.stringify(data, null, 2) }] };
  },
});
