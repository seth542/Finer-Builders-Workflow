import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "get_job",
  title: "Get job",
  description: "Full detail for one job, including its selections list.",
  inputSchema: { job_id: z.string().uuid().describe("The job id.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ job_id }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text" as const, text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const { data: job, error } = await supabase
      .from("jobs")
      .select("*")
      .eq("id", job_id)
      .maybeSingle();
    if (error) return { content: [{ type: "text" as const, text: error.message }], isError: true };
    if (!job) return { content: [{ type: "text" as const, text: "Job not found" }], isError: true };
    const { data: selections } = await supabase
      .from("selections")
      .select("name, category, status, allowance_cents, due_date")
      .eq("job_id", job_id);
    return {
      content: [
        {
          type: "text" as const,
          text: JSON.stringify({ job, selections: selections ?? [] }, null, 2),
        },
      ],
    };
  },
});
