import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_billing",
  title: "List billing",
  description:
    "Schedule of values plus invoice / draw request history for a job, with amounts in cents.",
  inputSchema: { job_id: z.string().uuid().describe("The job id.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ job_id }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text" as const, text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const { data: schedule, error } = await supabase
      .from("payment_schedules")
      .select("id, kind, retainage_percent")
      .eq("job_id", job_id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) return { content: [{ type: "text" as const, text: error.message }], isError: true };
    const items = schedule
      ? (
          await supabase
            .from("payment_schedule_items")
            .select("*")
            .eq("schedule_id", schedule.id)
            .order("sort_order")
        ).data
      : [];
    const { data: draws } = await supabase
      .from("draw_requests")
      .select("number, status, amount_requested_cents, created_at")
      .eq("job_id", job_id)
      .order("number");
    return {
      content: [
        {
          type: "text" as const,
          text: JSON.stringify({ schedule, items: items ?? [], draws: draws ?? [] }, null, 2),
        },
      ],
    };
  },
});
