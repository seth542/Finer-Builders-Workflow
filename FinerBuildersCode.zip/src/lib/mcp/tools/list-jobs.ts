import { defineTool } from "@lovable.dev/mcp-js";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_jobs",
  title: "List jobs",
  description: "List every job with its stage, contract type, client and address.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text" as const, text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("jobs")
      .select(
        "id, name, client_name, address, stage, job_type, contract_type, fee_percent, contingency_percent",
      )
      .order("created_at", { ascending: false });
    if (error) return { content: [{ type: "text" as const, text: error.message }], isError: true };
    return { content: [{ type: "text" as const, text: JSON.stringify(data, null, 2) }] };
  },
});
