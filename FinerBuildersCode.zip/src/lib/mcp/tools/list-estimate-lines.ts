import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_estimate_lines",
  title: "List estimate lines",
  description: "Estimate phases and line items for a job, with costs and multipliers.",
  inputSchema: { job_id: z.string().uuid().describe("The job id.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ job_id }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text" as const, text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("estimates")
      .select(
        "id, default_multiplier, estimate_phases(name, sort_order, default_multiplier, estimate_line_items(description, quantity, unit, unit_cost_cents, multiplier, cost_type, sort_order))",
      )
      .eq("job_id", job_id);
    if (error) return { content: [{ type: "text" as const, text: error.message }], isError: true };
    return { content: [{ type: "text" as const, text: JSON.stringify(data, null, 2) }] };
  },
});
