/**
 * QuickBooks Online API helpers. Server-only.
 *
 * READ-ONLY BY DESIGN: data flows QuickBooks -> this app and never back.
 * The only calls made against the QuickBooks company are GET /query reads, plus
 * the OAuth token endpoint needed to keep the connection alive. Do not add
 * create/update/delete/void/sparse-update calls here.
 */

const TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer";
const API_BASE = "https://quickbooks.api.intuit.com/v3/company";


type Secrets = {
  access_token: string | null;
  refresh_token: string | null;
  realm_id: string | null;
  expires_at: string | null;
};

export type QbTxn = {
  qb_id: string;
  qb_type: string;
  doc_number: string | null;
  vendor: string | null;
  qb_customer: string | null;
  memo: string | null;
  txn_date: string;
  amount_cents: number;
  account_name: string | null;
  raw: unknown;
};

/** Fetch stored tokens, refreshing them when they are close to expiry. */
export async function getQuickbooksAccess(): Promise<{ token: string; realmId: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("integration_secrets")
    .select("access_token, refresh_token, realm_id, expires_at")
    .eq("provider", "quickbooks")
    .maybeSingle();
  const secrets = data as Secrets | null;
  if (!secrets?.refresh_token || !secrets.realm_id) {
    throw new Error("QuickBooks isn't connected yet. Connect it from Integrations first.");
  }

  const fresh =
    secrets.access_token &&
    secrets.expires_at &&
    new Date(secrets.expires_at).getTime() - Date.now() > 60_000;
  if (fresh) return { token: secrets.access_token!, realmId: secrets.realm_id };

  const clientId = process.env["QUICKBOOKS_CLIENT_ID"];
  const clientSecret = process.env["QUICKBOOKS_CLIENT_SECRET"];
  if (!clientId || !clientSecret) throw new Error("QuickBooks app credentials are missing.");

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      accept: "application/json",
      authorization: `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: secrets.refresh_token,
    }).toString(),
  });
  if (!res.ok) throw new Error("QuickBooks session expired. Reconnect it from Integrations.");
  const tokens = (await res.json()) as {
    access_token: string;
    refresh_token: string;
    expires_in: number;
  };
  await supabaseAdmin.from("integration_secrets").upsert({
    provider: "quickbooks",
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token,
    realm_id: secrets.realm_id,
    expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
    updated_at: new Date().toISOString(),
  });
  return { token: tokens.access_token, realmId: secrets.realm_id };
}

async function query(token: string, realmId: string, sql: string): Promise<any> {
  // Read-only guard: only SELECT-style reads may leave this app.
  if (!/^\s*select\s/i.test(sql)) throw new Error("QuickBooks access is read-only.");
  const res = await fetch(
    `${API_BASE}/${realmId}/query?query=${encodeURIComponent(sql)}&minorversion=70`,
    { method: "GET", headers: { authorization: `Bearer ${token}`, accept: "application/json" } },
  );

  if (!res.ok) throw new Error(`QuickBooks request failed (${res.status})`);
  const body = (await res.json()) as { QueryResponse?: Record<string, any[]> };
  return body.QueryResponse ?? {};
}

const cents = (n: unknown) => Math.round(Number(n ?? 0) * 100);

/** Pull Bills, Purchases (expenses/checks/cards) and Vendor Credits since a date. */
export async function fetchQuickbooksCosts(since: string): Promise<QbTxn[]> {
  const { token, realmId } = await getQuickbooksAccess();
  const out: QbTxn[] = [];

  const bills = await query(
    token,
    realmId,
    `select * from Bill where TxnDate >= '${since}' maxresults 500`,
  );
  for (const b of bills.Bill ?? []) {
    out.push(...splitLines("Bill", b, b.VendorRef?.name ?? null));
  }

  const purchases = await query(
    token,
    realmId,
    `select * from Purchase where TxnDate >= '${since}' maxresults 500`,
  );
  for (const p of purchases.Purchase ?? []) {
    out.push(...splitLines("Purchase", p, p.EntityRef?.name ?? null));
  }

  return out.filter((t) => t.amount_cents !== 0);
}

/** One staged row per line so each can be matched to its own budget line. */
function splitLines(type: string, doc: any, vendor: string | null): QbTxn[] {
  const lines: any[] = Array.isArray(doc.Line) ? doc.Line : [];
  const detailed = lines.filter((l) => l?.Amount != null);
  const base = {
    qb_type: type,
    doc_number: doc.DocNumber ?? null,
    vendor,
    txn_date: String(doc.TxnDate ?? "").slice(0, 10),
    raw: doc,
  };
  if (detailed.length === 0) {
    return [
      {
        ...base,
        qb_id: String(doc.Id),
        qb_customer: doc.CustomerRef?.name ?? null,
        memo: doc.PrivateNote ?? null,
        amount_cents: cents(doc.TotalAmt),
        account_name: null,
      },
    ];
  }
  return detailed.map((l) => {
    const detail = l.AccountBasedExpenseLineDetail ?? l.ItemBasedExpenseLineDetail ?? {};
    return {
      ...base,
      qb_id: `${doc.Id}:${l.Id ?? l.LineNum ?? Math.random().toString(36).slice(2)}`,
      qb_customer: detail.CustomerRef?.name ?? doc.CustomerRef?.name ?? null,
      memo: l.Description ?? doc.PrivateNote ?? null,
      amount_cents: cents(l.Amount),
      account_name: detail.AccountRef?.name ?? detail.ItemRef?.name ?? null,
    };
  });
}

const normalize = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

/** Match a staged transaction to a job by the QuickBooks customer/job name text. */
export function matchJob(
  txn: QbTxn,
  jobs: { id: string; name: string; client_name: string | null; address: string | null }[],
): string | null {
  const haystack = normalize(
    [txn.qb_customer, txn.memo, txn.doc_number].filter(Boolean).join(" | "),
  );
  if (!haystack) return null;

  let best: { id: string; score: number } | null = null;
  for (const job of jobs) {
    const candidates = [job.name, job.client_name, job.address].filter(Boolean) as string[];
    for (const raw of candidates) {
      const needle = normalize(raw);
      if (!needle) continue;
      let score = 0;
      if (haystack.includes(needle)) {
        score = needle.length * 2;
      } else {
        const words = needle.split(" ").filter((w) => w.length > 3);
        const hits = words.filter((w) => haystack.includes(w));
        if (words.length > 0 && hits.length === words.length) score = needle.length;
        else if (hits.length > 0) score = hits.join("").length / 2;
      }
      if (score >= 6 && (!best || score > best.score)) best = { id: job.id, score };
    }
  }
  return best?.id ?? null;
}
