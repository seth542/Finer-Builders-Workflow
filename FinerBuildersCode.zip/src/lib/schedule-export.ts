export type ExportRow = {
  name: string;
  scheduled_value_cents: number;
  trigger?: string;
  due_date?: string | null;
};

const dollars = (cents: number) => (cents / 100).toFixed(2);

export function scheduleToCsv(rows: ExportRow[], total: number, includeTrigger: boolean) {
  const head = includeTrigger
    ? ["Item", "Trigger", "Amount", "% of contract"]
    : ["Item", "Amount", "% of contract"];
  const body = rows.map((r) => {
    const p = total > 0 ? ((r.scheduled_value_cents / total) * 100).toFixed(2) + "%" : "";
    const cells = includeTrigger
      ? [r.name, r.trigger ?? "", dollars(r.scheduled_value_cents), p]
      : [r.name, dollars(r.scheduled_value_cents), p];
    return cells;
  });
  const totalRow = includeTrigger
    ? ["Total", "", dollars(total), "100.00%"]
    : ["Total", dollars(total), "100.00%"];
  return [head, ...body, totalRow]
    .map((cells) => cells.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

export function scheduleToText(rows: ExportRow[], total: number) {
  const lines = rows.map((r) => `${r.name}\t$${dollars(r.scheduled_value_cents)}`);
  return [...lines, `Total\t$${dollars(total)}`].join("\n");
}

export function downloadFile(name: string, contents: string, mime: string) {
  const blob = new Blob([contents], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function printSchedule(opts: {
  jobName: string;
  title: string;
  rows: ExportRow[];
  total: number;
}) {
  const body = opts.rows
    .map(
      (r) => `<tr><td>${escapeHtml(r.name)}</td><td class="n">$${dollars(
        r.scheduled_value_cents,
      )}</td><td class="n">${
        opts.total > 0 ? ((r.scheduled_value_cents / opts.total) * 100).toFixed(1) + "%" : "—"
      }</td></tr>`,
    )
    .join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(
    opts.jobName,
  )} — ${escapeHtml(opts.title)}</title><style>
    body{font-family:Georgia,serif;margin:40px;color:#241a15}
    h1{font-size:20px;margin:0 0 2px}
    h2{font-size:13px;font-weight:400;color:#6b5d55;margin:0 0 24px;letter-spacing:.08em;text-transform:uppercase}
    table{width:100%;border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:12px}
    th,td{padding:7px 8px;border-bottom:1px solid #e5ded9;text-align:left}
    th{font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#6b5d55}
    .n{text-align:right;font-variant-numeric:tabular-nums}
    tfoot td{border-top:2px solid #241a15;font-weight:700}
  </style></head><body>
  <h1>${escapeHtml(opts.jobName)}</h1><h2>${escapeHtml(opts.title)}</h2>
  <table><thead><tr><th>Item</th><th class="n">Amount</th><th class="n">% of contract</th></tr></thead>
  <tbody>${body}</tbody>
  <tfoot><tr><td>Total</td><td class="n">$${dollars(opts.total)}</td><td class="n">100.0%</td></tr></tfoot>
  </table></body></html>`;
  const w = window.open("", "_blank", "width=900,height=1000");
  if (!w) return false;
  w.document.write(html);
  w.document.close();
  w.focus();
  w.print();
  return true;
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
}
