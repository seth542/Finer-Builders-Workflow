export type LineLike = {
  quantity: number | string;
  unit_cost_cents: number;
  multiplier: number | string | null;
};

export type PhaseLike = {
  default_multiplier: number | string | null;
};

export const num = (v: number | string | null | undefined, fallback = 0) => {
  if (v === null || v === undefined || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

/** Markup is always a multiplier: sell = cost x multiplier. */
export function effectiveMultiplier(
  line: LineLike,
  phase: PhaseLike | undefined,
  estimateDefault: number | string | null,
): number {
  const line_m = num(line.multiplier, 0);
  if (line_m > 0) return line_m;
  const phase_m = num(phase?.default_multiplier ?? null, 0);
  if (phase_m > 0) return phase_m;
  const est_m = num(estimateDefault, 1);
  return est_m > 0 ? est_m : 1;
}

export function lineCostCents(line: LineLike): number {
  return Math.round(num(line.quantity) * line.unit_cost_cents);
}

export function lineSellCents(
  line: LineLike,
  phase: PhaseLike | undefined,
  estimateDefault: number | string | null,
): number {
  return Math.round(lineCostCents(line) * effectiveMultiplier(line, phase, estimateDefault));
}

export type Totals = {
  cost: number;
  sell: number;
  profit: number;
  margin: number;
  blended: number;
};

export function rollup(
  lines: (LineLike & { phase_id: string })[],
  phases: (PhaseLike & { id: string })[],
  estimateDefault: number | string | null,
): Totals {
  let cost = 0;
  let sell = 0;
  const byId = new Map(phases.map((p) => [p.id, p]));
  for (const l of lines) {
    cost += lineCostCents(l);
    sell += lineSellCents(l, byId.get(l.phase_id), estimateDefault);
  }
  return finish(cost, sell);
}

export function finish(cost: number, sell: number): Totals {
  const profit = sell - cost;
  return {
    cost,
    sell,
    profit,
    margin: sell > 0 ? profit / sell : 0,
    blended: cost > 0 ? sell / cost : 0,
  };
}

/** Multiplier required to hit a target gross margin: 1 / (1 - margin). */
export function multiplierForMargin(margin: number): number {
  const m = Math.min(Math.max(margin, 0), 0.95);
  return Number((1 / (1 - m)).toFixed(4));
}

export function marginState(
  margin: number,
  target: number,
  floor: number,
): "ok" | "warning" | "alert" {
  if (margin < floor) return "alert";
  if (margin < target) return "warning";
  return "ok";
}

export type CostPlusTotals = {
  cost: number;
  contingency: number;
  fee: number;
  total: number;
};

/**
 * Cost-plus client-facing math. Costs are transparent; the fee is one visible line.
 * percent_of_cost: fee = cost x feePercent. line_multipliers: fee = price - cost.
 */
export function costPlusTotals({
  cost,
  sell,
  feeStyle,
  feePercent,
  contingencyPercent,
}: {
  cost: number;
  sell: number;
  feeStyle: "percent_of_cost" | "line_multipliers";
  feePercent: number | string | null;
  contingencyPercent: number | string | null;
}): CostPlusTotals {
  const contingency = Math.round(cost * num(contingencyPercent, 0));
  const fee =
    feeStyle === "percent_of_cost"
      ? Math.round(cost * num(feePercent, 0))
      : Math.max(sell - cost, 0);
  return { cost, contingency, fee, total: cost + contingency + fee };
}
