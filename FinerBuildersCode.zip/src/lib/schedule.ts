/**
 * Construction schedule math. Phases run back-to-back on working days
 * (Mon–Fri) starting from the job's construction start date.
 */

export const DAY_MS = 86_400_000;

export function parseDate(value: string | null | undefined): Date | null {
  if (!value) return null;
  const [y, m, d] = value.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(Date.UTC(y, m - 1, d));
}

export function toISODate(date: Date) {
  return date.toISOString().slice(0, 10);
}

export function isWeekend(date: Date) {
  const day = date.getUTCDay();
  return day === 0 || day === 6;
}

/** Next working day at or after the given date. */
export function nextWorkday(date: Date) {
  const d = new Date(date.getTime());
  while (isWeekend(d)) d.setUTCDate(d.getUTCDate() + 1);
  return d;
}

/** Adds N working days to a start date, counting the start as day 1. */
export function addWorkdays(start: Date, days: number) {
  const d = nextWorkday(start);
  let remaining = Math.max(1, Math.round(days)) - 1;
  while (remaining > 0) {
    d.setUTCDate(d.getUTCDate() + 1);
    if (!isWeekend(d)) remaining -= 1;
  }
  return d;
}

/** Inclusive count of working days between two dates. */
export function workdaysBetween(start: Date, end: Date) {
  if (end.getTime() < start.getTime()) return 0;
  let count = 0;
  const d = new Date(start.getTime());
  while (d.getTime() <= end.getTime()) {
    if (!isWeekend(d)) count += 1;
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return count;
}

/** Subtracts N working days (used for selection lead times). */
export function minusWorkdays(date: Date, days: number) {
  const d = new Date(date.getTime());
  let remaining = Math.max(0, Math.round(days));
  while (remaining > 0) {
    d.setUTCDate(d.getUTCDate() - 1);
    if (!isWeekend(d)) remaining -= 1;
  }
  return nextWorkday(d);
}

export function formatDate(date: Date | null) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  }).format(date);
}

export function formatShort(date: Date | null) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(date);
}

export type SchedulePhaseInput = {
  id: string;
  name: string;
  durationDays: number | null;
  costCents: number;
};

export type ScheduledPhase = {
  id: string;
  name: string;
  costCents: number;
  durationDays: number;
  /** true when the duration came from cost weighting instead of a saved value */
  derived: boolean;
  start: Date;
  finish: Date;
};

/**
 * Lays phases out sequentially. Phases without a saved duration get one
 * derived from their share of estimated cost, spread across either the
 * window to the target end date or a default 5-day-per-phase pace.
 */
export function buildSchedule({
  phases,
  start,
  targetEnd,
}: {
  phases: SchedulePhaseInput[];
  start: Date;
  targetEnd?: Date | null;
}): { phases: ScheduledPhase[]; start: Date; finish: Date | null; totalDays: number } {
  const active = phases.filter((p) => p.costCents > 0 || p.durationDays);
  const list = active.length > 0 ? active : phases;
  const savedDays = list.reduce((s, p) => s + (p.durationDays ?? 0), 0);
  const derivedPhases = list.filter((p) => !p.durationDays);
  const derivedCost = derivedPhases.reduce((s, p) => s + p.costCents, 0);

  const windowDays = targetEnd ? workdaysBetween(nextWorkday(start), targetEnd) : 0;
  const budget = windowDays > savedDays ? windowDays - savedDays : derivedPhases.length * 5;

  let cursor = nextWorkday(start);
  const out: ScheduledPhase[] = [];
  for (const p of list) {
    let duration = p.durationDays ?? 0;
    if (!p.durationDays) {
      const share = derivedCost > 0 ? p.costCents / derivedCost : 1 / (derivedPhases.length || 1);
      duration = Math.max(2, Math.round(share * budget));
    }
    const phaseStart = nextWorkday(cursor);
    const finish = addWorkdays(phaseStart, duration);
    out.push({
      id: p.id,
      name: p.name,
      costCents: p.costCents,
      durationDays: duration,
      derived: !p.durationDays,
      start: phaseStart,
      finish,
    });
    cursor = new Date(finish.getTime() + DAY_MS);
  }

  const finish = out.length > 0 ? out[out.length - 1]!.finish : null;
  return {
    phases: out,
    start: nextWorkday(start),
    finish,
    totalDays: out.reduce((s, p) => s + p.durationDays, 0),
  };
}
