import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { finish, lineCostCents, lineSellCents, type Totals } from "@/lib/estimate-math";

export const jobsQuery = () =>
  queryOptions({
    queryKey: ["jobs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("jobs")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export const jobQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["job", jobId],
    queryFn: async () => {
      const { data, error } = await supabase.from("jobs").select("*").eq("id", jobId).single();
      if (error) throw error;
      return data;
    },
  });

/** Cost/sell rollup for every job, computed from estimate lines. */
export const allJobTotalsQuery = () =>
  queryOptions({
    queryKey: ["job-totals"],
    queryFn: async (): Promise<Record<string, Totals>> => {
      const { data, error } = await supabase
        .from("estimates")
        .select(
          "id, job_id, default_multiplier, estimate_phases(id, default_multiplier, estimate_line_items(quantity, unit_cost_cents, multiplier))",
        );
      if (error) throw error;
      const acc: Record<string, { cost: number; sell: number }> = {};
      for (const est of data ?? []) {
        const bucket = (acc[est.job_id] ??= { cost: 0, sell: 0 });
        for (const phase of est.estimate_phases ?? []) {
          for (const line of phase.estimate_line_items ?? []) {
            bucket.cost += lineCostCents(line);
            bucket.sell += lineSellCents(line, phase, est.default_multiplier);
          }
        }
      }
      return Object.fromEntries(
        Object.entries(acc).map(([jobId, v]) => [jobId, finish(v.cost, v.sell)]),
      );
    },
  });

export const estimateQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["estimate", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("estimates")
        .select("*")
        .eq("job_id", jobId)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const phasesQuery = (estimateId: string) =>
  queryOptions({
    queryKey: ["phases", estimateId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("estimate_phases")
        .select("*")
        .eq("estimate_id", estimateId)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!estimateId,
  });

export const linesQuery = (estimateId: string) =>
  queryOptions({
    queryKey: ["lines", estimateId],
    queryFn: async () => {
      const { data: phases, error: pe } = await supabase
        .from("estimate_phases")
        .select("id")
        .eq("estimate_id", estimateId);
      if (pe) throw pe;
      const ids = (phases ?? []).map((p) => p.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from("estimate_line_items")
        .select("*")
        .in("phase_id", ids)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!estimateId,
  });

export const templatesQuery = () =>
  queryOptions({
    queryKey: ["templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sequence_templates")
        .select("*, template_phases(id, name, sort_order)")
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

export const libraryQuery = () =>
  queryOptions({
    queryKey: ["library"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cost_library_items")
        .select("*")
        .order("name", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

export const assembliesQuery = () =>
  queryOptions({
    queryKey: ["assemblies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assemblies")
        .select("*, assembly_components(*)")
        .order("name", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

export const selectionsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["selections", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("selections")
        .select("*")
        .eq("job_id", jobId)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

export const selectionLibraryQuery = () =>
  queryOptions({
    queryKey: ["selection-library"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("selection_library_items")
        .select("*")
        .order("job_type", { ascending: true })
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

export const scheduleQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["schedule", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("payment_schedules")
        .select("*")
        .eq("job_id", jobId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

export const scheduleItemsQuery = (scheduleId: string) =>
  queryOptions({
    queryKey: ["schedule-items", scheduleId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("payment_schedule_items")
        .select("*, payment_item_phases(phase_id)")
        .eq("schedule_id", scheduleId)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!scheduleId,
  });

export const drawRequestsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["draw-requests", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("draw_requests")
        .select("*")
        .eq("job_id", jobId)
        .order("number", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

export const drawAttachmentsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["draw-attachments", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("draw_attachments")
        .select("*")
        .eq("job_id", jobId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

/** Every draw request / invoice across all jobs, for financial rollups. */
export const allBillingQuery = () =>
  queryOptions({
    queryKey: ["all-billing"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("draw_requests")
        .select("id, job_id, number, amount_requested_cents, retainage_cents, status, created_at");
      if (error) throw error;
      return data;
    },
  });

export const dailyLogsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["daily-logs", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("daily_logs")
        .select("*, daily_log_photos(*), profiles:created_by(full_name, email)")
        .eq("job_id", jobId)
        .order("log_date", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

/** Internal actual-cost entries (subs, materials, labor) logged against a job. */
export const jobCostsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["job-costs", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_costs")
        .select("*")
        .eq("job_id", jobId)
        .order("incurred_on", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

/** Saved sub bid requests for a job, newest first. */
export const subBidRequestsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["sub-bid-requests", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sub_bid_requests")
        .select("*")
        .eq("job_id", jobId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

/** Bids logged against every saved request on a job. */
export const subBidResponsesQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["sub-bid-responses", jobId],
    queryFn: async () => {
      const { data: reqs, error: re } = await supabase
        .from("sub_bid_requests")
        .select("id")
        .eq("job_id", jobId);
      if (re) throw re;
      const ids = (reqs ?? []).map((r) => r.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from("sub_bid_responses")
        .select("*")
        .in("request_id", ids)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!jobId,
  });

/** Staged QuickBooks transactions waiting to be matched to budget lines. */
export const qbInboxQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["qb-inbox", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("qb_transactions")
        .select("*")
        .eq("status", "unmatched")
        .or(`job_id.eq.${jobId},job_id.is.null`)
        .order("txn_date", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data;
    },
  });
