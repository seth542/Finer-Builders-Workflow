import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Build the QuickBooks consent URL. Requires the QuickBooks app credentials. */
export const quickbooksAuthUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { origin: string }) => input)
  .handler(async ({ data }) => {
    const clientId = process.env["QUICKBOOKS_CLIENT_ID"];
    if (!clientId)
      throw new Error(
        "QuickBooks isn't configured yet — the Intuit app client ID and secret are needed first.",
      );
    const params = new URLSearchParams({
      client_id: clientId,
      response_type: "code",
      scope: "com.intuit.quickbooks.accounting",
      redirect_uri: `${data.origin}/api/public/quickbooks/callback`,
      state: crypto.randomUUID(),
    });
    return { url: `https://appcenter.intuit.com/connect/oauth2?${params.toString()}` };
  });

export const disconnectQuickbooks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("integration_secrets").delete().eq("provider", "quickbooks");
    const { error } = await context.supabase
      .from("integrations")
      .update({ status: "disconnected", connected_at: null, config: {} })
      .eq("provider", "quickbooks");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Pull bills/expenses from QuickBooks into the cost inbox and auto-match them to jobs. */
export const syncQuickbooksCosts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { since?: string }) => input ?? {})
  .handler(async ({ data, context }) => {
    const { fetchQuickbooksCosts, matchJob } = await import("@/lib/quickbooks.server");
    const since =
      data.since ?? new Date(Date.now() - 1000 * 60 * 60 * 24 * 365).toISOString().slice(0, 10);

    const txns = await fetchQuickbooksCosts(since);

    const { data: jobs, error: jobsError } = await context.supabase
      .from("jobs")
      .select("id, name, client_name, address");
    if (jobsError) throw new Error(jobsError.message);

    let matched = 0;
    const rows = txns.map((t) => {
      const jobId = matchJob(t, jobs ?? []);
      if (jobId) matched += 1;
      return {
        qb_id: t.qb_id,
        qb_type: t.qb_type,
        doc_number: t.doc_number,
        vendor: t.vendor,
        qb_customer: t.qb_customer,
        memo: t.memo,
        txn_date: t.txn_date,
        amount_cents: t.amount_cents,
        account_name: t.account_name,
        job_id: jobId,
        raw: t.raw as never,
      };
    });

    if (rows.length > 0) {
      const { error } = await context.supabase
        .from("qb_transactions")
        .upsert(rows, { onConflict: "qb_type,qb_id", ignoreDuplicates: true });
      if (error) throw new Error(error.message);
    }

    return { pulled: rows.length, matched, since };
  });
