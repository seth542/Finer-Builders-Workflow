export type BidRequestDoc = {
  jobName: string;
  jobAddress: string;
  tradeName: string;
  items: { description: string; scope: string }[];
  notes: string;
  exclusions: string;
  dueDate: string;
  contact: string;
  startDate: string;
  specs?: string;
  materials?: string;
  details?: string;
  attachments?: string[];
};

export function bidRequestToText(d: BidRequestDoc) {
  const lines = [
    `SUB BID REQUEST — ${d.tradeName}`,
    `Project: ${d.jobName}${d.jobAddress ? ` · ${d.jobAddress}` : ""}`,
    d.startDate ? `Anticipated start: ${d.startDate}` : "",
    d.dueDate ? `Bids due: ${d.dueDate}` : "",
    d.contact ? `Send bids to: ${d.contact}` : "",
    "",
    "SCOPE OF WORK",
    ...d.items.map((i, n) => `${n + 1}. ${i.description}${i.scope ? ` — ${i.scope}` : ""}`),
    ...(d.specs ? ["", "SPECS / MEASUREMENTS", d.specs] : []),
    ...(d.materials
      ? [
          "",
          "REQUIRED MATERIALS",
          ...parseMaterials(d.materials).map((m) => `- ${m.name}${m.url ? ` — ${m.url}` : ""}`),
        ]
      : []),
    ...(d.details ? ["", "DETAILS", d.details] : []),
    ...(d.attachments?.length ? ["", "ATTACHMENTS", ...d.attachments.map((a) => `- ${a}`)] : []),
    "",
    "GENERAL REQUIREMENTS",
    d.notes,
    "",
    "EXCLUSIONS",
    d.exclusions,
  ];
  return lines.filter((l) => l !== "").join("\n");
}

export function printBidRequest(d: BidRequestDoc) {
  const items = d.items
    .map(
      (i, n) =>
        `<tr><td class="n">${n + 1}</td><td><strong>${esc(i.description)}</strong>${
          i.scope ? `<div class="s">${esc(i.scope)}</div>` : ""
        }</td></tr>`,
    )
    .join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(
    d.jobName,
  )} — Sub bid request (${esc(d.tradeName)})</title><style>
    body{font-family:Georgia,serif;margin:40px;color:#241a15}
    h1{font-size:20px;margin:0 0 2px}
    h2{font-size:12px;font-weight:400;color:#6b5d55;margin:0 0 20px;letter-spacing:.1em;text-transform:uppercase}
    h3{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#6b5d55;margin:22px 0 6px}
    table{width:100%;border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:12px}
    td{padding:7px 8px;border-bottom:1px solid #e5ded9;vertical-align:top}
    td.n{width:26px;color:#6b5d55}
    .s{color:#6b5d55;font-size:11px;margin-top:2px}
    .meta{font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:1.6}
    p{font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:1.6;white-space:pre-wrap;margin:0}
  </style></head><body>
  <h1>${esc(d.jobName)}</h1>
  <h2>Sub bid request — ${esc(d.tradeName)}</h2>
  <div class="meta">
    ${d.jobAddress ? `${esc(d.jobAddress)}<br>` : ""}
    ${d.startDate ? `Anticipated start: ${esc(d.startDate)}<br>` : ""}
    ${d.dueDate ? `Bids due: ${esc(d.dueDate)}<br>` : ""}
    ${d.contact ? `Send bids to: ${esc(d.contact)}` : ""}
  </div>
  <h3>Scope of work</h3>
  <table><tbody>${items}</tbody></table>
  ${d.specs ? `<h3>Specs / measurements</h3><p>${esc(d.specs)}</p>` : ""}
  ${d.materials ? `<h3>Required materials</h3>${materialsListHtml(d.materials)}` : ""}
  ${d.details ? `<h3>Details</h3><p>${esc(d.details)}</p>` : ""}
  ${
    d.attachments?.length
      ? `<h3>Attachments</h3><p>${d.attachments.map((a) => esc(a)).join("\n")}</p>`
      : ""
  }
  <h3>General requirements</h3><p>${esc(d.notes)}</p>
  <h3>Exclusions</h3><p>${esc(d.exclusions)}</p>
  </body></html>`;
  const w = window.open("", "_blank", "width=900,height=1000");
  if (!w) return false;
  w.document.write(html);
  w.document.close();
  w.focus();
  w.print();
  return true;
}

function esc(s: string) {
  return s.replace(
    /[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!,
  );
}

export type MaterialEntry = { name: string; url: string };

export function parseMaterials(raw: string): MaterialEntry[] {
  return raw
    .split("\n")
    .map((l) => l.replace(/^[-•]\s*/, "").trim())
    .filter(Boolean)
    .map((l) => {
      const m = /^(.*?)\s+—\s+(\S+)$/.exec(l);
      if (m) return { name: m[1]!.trim(), url: m[2]! };
      return { name: l, url: "" };
    });
}

export function serializeMaterials(list: MaterialEntry[]): string {
  return list
    .filter((m) => m.name.trim() || m.url.trim())
    .map((m) => (m.url.trim() ? `${m.name.trim()} — ${m.url.trim()}` : m.name.trim()))
    .join("\n");
}

export function materialsListHtml(raw: string): string {
  const rows = parseMaterials(raw)
    .map(
      (m) =>
        `<li>${esc(m.name)}${
          m.url ? ` — <a href="${esc(m.url)}">${esc(m.url)}</a>` : ""
        }</li>`,
    )
    .join("");
  return `<ul style="font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:1.6;margin:0;padding-left:18px">${rows}</ul>`;
}
