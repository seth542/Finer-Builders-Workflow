import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { NewJobDialog } from "@/components/jobs/NewJobDialog";
import { allJobTotalsQuery, jobsQuery } from "@/lib/queries";
import {
  JOB_STAGES,
  jobTypeLabel,
  contractLabel,
  stageLabel,
  type ContractType,
  type JobStage,
  type JobType,
} from "@/lib/domain";
import { costPlusTotals, marginState, type Totals } from "@/lib/estimate-math";
import { money, pct } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { LayoutGrid, Table2 } from "lucide-react";

export const Route = createFileRoute("/jobs/")({
  head: () => ({
    meta: [
      { title: "Job Board — Finer Builders" },
      {
        name: "description",
        content:
          "Every Finer Builders remodel and custom home, staged from lead to closeout with live margin health.",
      },
      { property: "og:title", content: "Job Board — Finer Builders" },
      {
        property: "og:description",
        content: "Every job staged from lead to closeout with live margin health.",
      },
    ],
  }),
  component: Dashboard,
});

const EMPTY: Totals = { cost: 0, sell: 0, profit: 0, margin: 0, blended: 0 };

function Dashboard() {
  const [view, setView] = useState<"board" | "table">("board");
  const jobs = useQuery(jobsQuery());
  const totals = useQuery(allJobTotalsQuery());

  const rows = useMemo(
    () =>
      (jobs.data ?? []).map((j) => {
        const base = totals.data?.[j.id] ?? EMPTY;
        if (j.contract_type !== "cost_plus") return { job: j, totals: base };
        // Cost plus is billed at cost + contingency + fee.
        const cp = costPlusTotals({
          cost: base.cost,
          sell: base.sell,
          feeStyle: (j.fee_style ?? "percent_of_cost") as "percent_of_cost" | "line_multipliers",
          feePercent: j.fee_percent ?? 0,
          contingencyPercent: j.contingency_percent ?? 0,
        });
        return {
          job: j,
          totals: {
            ...base,
            sell: cp.total,
            profit: cp.fee,
            margin: cp.total > 0 ? cp.fee / cp.total : 0,
            blended: base.cost > 0 ? cp.total / base.cost : 0,
          },
        };
      }),
    [jobs.data, totals.data],
  );

  const pipeline = rows.reduce(
    (acc, r) => {
      acc.sell += r.totals.sell;
      acc.profit += r.totals.profit;
      return acc;
    },
    { sell: 0, profit: 0 },
  );

  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Job board</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {rows.length} job{rows.length === 1 ? "" : "s"} · {money(pipeline.sell)} contract value
            · {money(pipeline.profit)} projected gross profit
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-md border p-0.5">
            <Button
              variant={view === "board" ? "secondary" : "ghost"}
              size="sm"
              className="h-7 px-2"
              onClick={() => setView("board")}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant={view === "table" ? "secondary" : "ghost"}
              size="sm"
              className="h-7 px-2"
              onClick={() => setView("table")}
            >
              <Table2 className="h-3.5 w-3.5" />
            </Button>
          </div>
          <NewJobDialog />
        </div>
      </div>

      {rows.length === 0 && !jobs.isLoading && (
        <div className="mt-16 rounded-lg border border-dashed py-16 text-center">
          <h2 className="font-display text-xl">No jobs yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Start with a lead, build the estimate, protect the margin.
          </p>
        </div>
      )}

      {view === "board" ? (
        <div className="mt-6 grid gap-4 overflow-x-auto pb-4 md:grid-flow-col md:auto-cols-[minmax(250px,1fr)]">
          {JOB_STAGES.map((stage) => {
            const stageRows = rows.filter((r) => r.job.stage === stage.value);
            return (
              <div key={stage.value} className="min-w-[240px]">
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    {stage.label}
                  </span>
                  <span className="text-xs text-muted-foreground">{stageRows.length}</span>
                </div>
                <div className="mt-3 space-y-2">
                  {stageRows.map((r) => (
                    <JobCard key={r.job.id} job={r.job} totals={r.totals} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-lg border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-3 py-2 font-medium">Job</th>
                <th className="px-3 py-2 font-medium">Type</th>
                <th className="px-3 py-2 font-medium">Contract</th>
                <th className="px-3 py-2 font-medium">Stage</th>
                <th className="px-3 py-2 text-right font-medium">Cost</th>
                <th className="px-3 py-2 text-right font-medium">Contract</th>
                <th className="px-3 py-2 text-right font-medium">Profit</th>
                <th className="px-3 py-2 text-right font-medium">Margin</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ job, totals: t }) => {
                const health = marginState(t.margin, job.target_margin, job.margin_floor);
                return (
                  <tr key={job.id} className="border-t hover:bg-muted/40">
                    <td className="px-3 py-2">
                      <Link
                        to="/jobs/$jobId"
                        params={{ jobId: job.id }}
                        className="font-medium underline-offset-4 hover:underline"
                      >
                        {job.name}
                      </Link>
                      {job.client_name && (
                        <div className="text-xs text-muted-foreground">{job.client_name}</div>
                      )}
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {jobTypeLabel(job.job_type as JobType)}
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {contractLabel(job.contract_type as ContractType)}
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {stageLabel(job.stage as JobStage)}
                    </td>
                    <td className="num px-3 py-2 text-right">{money(t.cost)}</td>
                    <td className="num px-3 py-2 text-right">{money(t.sell)}</td>
                    <td className="num px-3 py-2 text-right">{money(t.profit)}</td>
                    <td
                      className={cn(
                        "num px-3 py-2 text-right font-medium",
                        health === "alert" && "text-destructive",
                        health === "warning" && "text-warning",
                        health === "ok" && "text-success",
                      )}
                    >
                      {pct(t.margin)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

type JobRow = {
  id: string;
  name: string;
  client_name: string | null;
  stage: string;
  job_type: string;
  contract_type: string;
  target_margin: number;
  margin_floor: number;
};

function JobCard({ job, totals }: { job: JobRow; totals: Totals }) {
  const health = marginState(totals.margin, job.target_margin, job.margin_floor);
  return (
    <Link
      to="/jobs/$jobId"
      params={{ jobId: job.id }}
      className="block rounded-lg border bg-card p-3 transition-colors hover:border-primary/40"
    >
      <div className="flex items-start justify-between gap-2">
        <span className="font-medium leading-tight">{job.name}</span>
        <Badge
          variant="outline"
          className={cn(
            "shrink-0 tabular-nums",
            health === "alert" && "border-destructive/40 text-destructive",
            health === "warning" && "border-warning/40 text-warning",
            health === "ok" && "border-success/40 text-success",
          )}
        >
          {pct(totals.margin, 0)}
        </Badge>
      </div>
      {job.client_name && (
        <div className="mt-0.5 text-xs text-muted-foreground">{job.client_name}</div>
      )}
      <div className="mt-3 flex items-baseline justify-between text-xs text-muted-foreground">
        <span>
          {jobTypeLabel(job.job_type as JobType)}
          <span className="ml-1.5 uppercase tracking-[0.1em] text-[10px]">
            {contractLabel(job.contract_type as ContractType)}
          </span>
        </span>
        <span className="num text-foreground">{money(totals.sell)}</span>
      </div>
    </Link>
  );
}
