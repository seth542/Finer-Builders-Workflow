import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { FinancialOverview } from "@/components/home/FinancialOverview";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  CalendarClock,
  FileSignature,
  FilePlus2,
  HardHat,
  LayoutGrid,
  Library,
  Plus,
  Receipt,
  Wallet,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Home — Finer Builders" },
      {
        name: "description",
        content:
          "Finer Builders command center: jump into the job board, start documents, and run estimating, billing, and production workflows.",
      },
      { property: "og:title", content: "Home — Finer Builders" },
      {
        property: "og:description",
        content: "Command center for estimating, billing, and production at Finer Builders.",
      },
    ],
  }),
  component: Home,
});

const destinations = [
  {
    title: "Job board",
    description: "Every job staged from lead to closeout with live margin health.",
    icon: LayoutGrid,
    to: "/jobs" as const,
  },
  {
    title: "Production",
    description: "Active jobs, actual costs against budget, and field status.",
    icon: HardHat,
    to: null,
  },
  {
    title: "Billing",
    description: "Draw requests, invoices, and what's outstanding across all jobs.",
    icon: Wallet,
    to: null,
  },
  {
    title: "Cost library",
    description: "Assemblies, unit costs, and saved selection lists.",
    icon: Library,
    to: null,
  },
];

const quickActions = [
  { title: "Change order", hint: "Pick a job, then scope and price it", icon: FileSignature },
  { title: "Invoice", hint: "Fixed price milestone billing", icon: Receipt },
  { title: "Draw request", hint: "Cost plus application for payment", icon: FilePlus2 },
  { title: "Proposal", hint: "Generate from a completed estimate", icon: FileSignature },
  { title: "New job", hint: "Lead intake and contract type", icon: Plus },
  { title: "Schedule item", hint: "Add a milestone or field task", icon: CalendarClock },
];

function Home() {
  return (
    <AppShell>
      <section className="border-b pb-6 sm:pb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Finer Builders</p>
        <h1 className="mt-2 font-display text-3xl tracking-tight sm:text-4xl">Command center</h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Start where the work is. Jump into a board, or spin up the document a job needs next.
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/jobs">
              <LayoutGrid className="mr-2 h-4 w-4" /> Go to job board
            </Link>
          </Button>
          <Button variant="outline" disabled>
            <Plus className="mr-2 h-4 w-4" /> New job
          </Button>
        </div>
      </section>

      <FinancialOverview />

      <section className="mt-8">
        <h2 className="font-display text-xl tracking-tight">Workspaces</h2>
        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:gap-3 lg:grid-cols-4">
          {destinations.map((d) => {
            const body = (
              <>
                <div className="flex items-start justify-between gap-2">
                  <d.icon className="h-5 w-5 text-primary" />
                  {!d.to && (
                    <Badge variant="outline" className="text-[10px] uppercase tracking-wider">
                      Soon
                    </Badge>
                  )}
                </div>
                <div className="mt-4 flex items-center gap-1.5 font-medium">
                  {d.title}
                  {d.to && <ArrowRight className="h-3.5 w-3.5 opacity-50" />}
                </div>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {d.description}
                </p>
              </>
            );
            return d.to ? (
              <Link
                key={d.title}
                to={d.to}
                className="rounded-lg border bg-card p-4 transition-colors hover:border-primary/40"
              >
                {body}
              </Link>
            ) : (
              <div
                key={d.title}
                className="rounded-lg border border-dashed bg-card/50 p-4 opacity-70"
              >
                {body}
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="font-display text-xl tracking-tight">Quick actions</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Document creation — pick what you're making, then the job it belongs to.
        </p>
        <div className="mt-4 grid gap-2.5 sm:grid-cols-2 sm:gap-3 lg:grid-cols-3">
          {quickActions.map((a) => (
            <button
              key={a.title}
              type="button"
              disabled
              className="flex items-center gap-3 rounded-lg border border-dashed bg-card/50 p-3 text-left opacity-70"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-secondary">
                <a.icon className="h-4 w-4 text-primary" />
              </span>
              <span>
                <span className="block text-sm font-medium">{a.title}</span>
                <span className="block text-xs text-muted-foreground">{a.hint}</span>
              </span>
            </button>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
