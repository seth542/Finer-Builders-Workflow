import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { disconnectQuickbooks, quickbooksAuthUrl } from "@/lib/integrations.functions";
import { Bot, Check, Copy, Landmark } from "lucide-react";

export const Route = createFileRoute("/integrations")({
  head: () => ({
    meta: [
      { title: "Integrations — Finer Builders" },
      {
        name: "description",
        content:
          "Connect Claude for agent tasks and QuickBooks for job cost data across Finer Builders jobs.",
      },
      { property: "og:title", content: "Integrations — Finer Builders" },
      {
        property: "og:description",
        content: "Manage the Claude agent connection and QuickBooks accounting sync.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: IntegrationsPage,
});

function IntegrationsPage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-3xl space-y-6">
        <header>
          <h1 className="font-display text-2xl tracking-wide">Integrations</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Two connections for now: Claude for running tasks against your jobs, and QuickBooks for
            actual costs.
          </p>
        </header>
        <ClaudeCard />
        <QuickBooksCard />
      </div>
    </AppShell>
  );
}

function Card({
  icon,
  title,
  subtitle,
  status,
  children,
}: {
  icon: ReactNode;
  title: string;
  subtitle: string;
  status: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="rounded-lg border bg-card">
      <div className="flex items-start gap-3 border-b px-4 py-3">
        <div className="mt-0.5 text-muted-foreground">{icon}</div>
        <div className="min-w-0">
          <h2 className="text-sm font-semibold">{title}</h2>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
        <div className="ml-auto shrink-0">{status}</div>
      </div>
      <div className="space-y-4 px-4 py-4">{children}</div>
    </section>
  );
}

const TOOLS = [
  ["List jobs", "Every job with stage, contract type and client"],
  ["Get job", "One job in full, including its selections"],
  ["List estimate lines", "Phases, line items, costs and multipliers"],
  ["List billing", "Schedule of values, invoices and draw requests"],
  ["Move job stage", "Advance a job through the pipeline"],
];

function ClaudeCard() {
  const [endpoint, setEndpoint] = useState("");
  useEffect(() => setEndpoint(`${window.location.origin}/mcp`), []);

  return (
    <Card
      icon={<Bot className="h-5 w-5" />}
      title="Claude"
      subtitle="Run tasks against your jobs — read estimates and billing, move jobs through stages."
      status={<Badge variant="secondary">Ready</Badge>}
    >
      <div className="space-y-1.5">
        <Label className="text-xs uppercase tracking-wider text-muted-foreground">
          Connector URL
        </Label>
        <CopyField value={endpoint} />
        <p className="text-xs text-muted-foreground">
          In Claude, add a custom connector with this URL. You'll sign in with your Finer Builders
          account and approve access — Claude then only sees what you can see.
        </p>
      </div>
      <div className="space-y-1.5">
        <Label className="text-xs uppercase tracking-wider text-muted-foreground">
          Available tasks
        </Label>
        <ul className="divide-y rounded-md border text-sm">
          {TOOLS.map(([name, desc]) => (
            <li key={name} className="flex flex-wrap items-baseline gap-x-2 px-3 py-2">
              <span className="font-medium">{name}</span>
              <span className="text-xs text-muted-foreground">{desc}</span>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}

function QuickBooksCard() {
  const qc = useQueryClient();
  const getUrl = useServerFn(quickbooksAuthUrl);
  const disconnect = useServerFn(disconnectQuickbooks);

  const integration = useQuery({
    queryKey: ["integration", "quickbooks"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("integrations")
        .select("provider, status, connected_at, config")
        .eq("provider", "quickbooks")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const connected = integration.data?.status === "connected";

  const connectMut = useMutation({
    mutationFn: async () => getUrl({ data: { origin: window.location.origin } }),
    onSuccess: (res) => {
      window.location.href = res.url;
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const disconnectMut = useMutation({
    mutationFn: async () => disconnect({ data: undefined }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["integration", "quickbooks"] });
      toast.success("QuickBooks disconnected");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  useEffect(() => {
    const result = new URLSearchParams(window.location.search).get("quickbooks");
    if (!result) return;
    if (result === "connected") toast.success("QuickBooks connected");
    else if (result === "not_configured") toast.error("QuickBooks app credentials missing");
    else toast.error("QuickBooks connection failed");
    window.history.replaceState({}, "", window.location.pathname);
    void qc.invalidateQueries({ queryKey: ["integration", "quickbooks"] });
  }, [qc]);

  return (
    <Card
      icon={<Landmark className="h-5 w-5" />}
      title="QuickBooks"
      subtitle="One-way read-only sync: receipts and sub invoices come in as actual costs. Nothing is ever written back to QuickBooks."
      status={
        connected ? (
          <Badge variant="secondary">Connected</Badge>
        ) : (
          <Badge variant="outline">Not connected</Badge>
        )
      }
    >
      {connected ? (
        <div className="flex items-center gap-3 text-sm">
          <Check className="h-4 w-4 text-primary" />
          <span className="text-muted-foreground">
            Company {String((integration.data?.config as { realm_id?: string })?.realm_id ?? "—")}
            {integration.data?.connected_at
              ? ` · connected ${new Date(integration.data.connected_at).toLocaleDateString()}`
              : ""}
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto text-destructive"
            onClick={() => disconnectMut.mutate()}
          >
            Disconnect
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Sign in with Intuit to authorize this app for your company file. This needs your Intuit
            developer app's client ID and secret added to the project first.
          </p>
          <Button size="sm" onClick={() => connectMut.mutate()} disabled={connectMut.isPending}>
            Connect QuickBooks
          </Button>
        </div>
      )}
    </Card>
  );
}

function CopyField({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex items-center gap-2">
      <code className="min-w-0 flex-1 truncate rounded-md border bg-muted/40 px-2 py-1.5 text-xs">
        {value}
      </code>
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          void navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        }}
      >
        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      </Button>
    </div>
  );
}
