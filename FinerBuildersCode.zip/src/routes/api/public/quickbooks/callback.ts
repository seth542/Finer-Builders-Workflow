import { createFileRoute } from "@tanstack/react-router";

/** QuickBooks OAuth redirect target. Exchanges the code for tokens. */
export const Route = createFileRoute("/api/public/quickbooks/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const code = url.searchParams.get("code");
        const realmId = url.searchParams.get("realmId");
        if (!code || !realmId) return redirect(url.origin, "missing_code");

        const clientId = process.env["QUICKBOOKS_CLIENT_ID"];
        const clientSecret = process.env["QUICKBOOKS_CLIENT_SECRET"];
        if (!clientId || !clientSecret) return redirect(url.origin, "not_configured");

        const res = await fetch("https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer", {
          method: "POST",
          headers: {
            "content-type": "application/x-www-form-urlencoded",
            accept: "application/json",
            authorization: `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
          },
          body: new URLSearchParams({
            grant_type: "authorization_code",
            code,
            redirect_uri: `${url.origin}/api/public/quickbooks/callback`,
          }).toString(),
        });
        if (!res.ok) return redirect(url.origin, "exchange_failed");
        const tokens = (await res.json()) as {
          access_token: string;
          refresh_token: string;
          expires_in: number;
        };

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin.from("integration_secrets").upsert({
          provider: "quickbooks",
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          realm_id: realmId,
          expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        });
        await supabaseAdmin
          .from("integrations")
          .update({
            status: "connected",
            connected_at: new Date().toISOString(),
            config: { realm_id: realmId },
          })
          .eq("provider", "quickbooks");

        return redirect(url.origin, "connected");
      },
    },
  },
});

function redirect(origin: string, result: string) {
  return new Response(null, {
    status: 302,
    headers: { location: `${origin}/integrations?quickbooks=${result}` },
  });
}
