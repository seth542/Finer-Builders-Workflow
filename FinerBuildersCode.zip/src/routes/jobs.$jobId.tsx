import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { estimateQuery, jobQuery, linesQuery, phasesQuery, templatesQuery } from "@/lib/queries";
import {
  CONTRACT_TYPES,
  FEE_STYLES,
  JOB_STAGES,
  contractLabel,
  jobTypeLabel,
  type ContractType,
  type FeeStyle,
  type JobStage,
  type JobType,
} from "@/lib/domain";
import { costPlusTotals, marginState, multiplierForMargin, num, rollup } from "@/lib/estimate-math";
import { money, mult, pct } from "@/lib/format";
import { EstimateGrid } from "@/components/estimate/EstimateGrid";
import { ProposalView } from "@/components/estimate/ProposalView";
import { SelectionsTab } from "@/components/selections/SelectionsTab";
import { ScopeBreakdownTab } from "@/components/scope/ScopeBreakdownTab";
import { BidsTab } from "@/components/scope/BidsTab";

import { PaymentScheduleTab } from "@/components/payments/PaymentScheduleTab";
import { JobBudgetTab } from "@/components/budget/JobBudgetTab";

import { ScheduleTab } from "@/components/schedule/ScheduleTab";
import { DailyLogTab } from "@/components/daily-log/DailyLogTab";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { ArrowLeft, Target } from "lucide-react";
import { toast } from "sonner";

const tabRow =
  "flex h-auto w-full flex-nowrap justify-start gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:flex-wrap sm:overflow-visible";
const tabItem = "shrink-0 whitespace-nowrap";


export const Route = createFileRoute("/jobs/$jobId")({
  head: () => ({
    meta: [
      { title: "Job Workspace — Finer Builders" },
      {
        name: "description",
        content: "Estimate, price, and protect margin on a Finer Builders job.",
      },
      { property: "og:title", content: "Job Workspace — Finer Builders" },
      {
        property: "og:description",
        content: "Estimate, price, and protect margin on a Finer Builders job.",
      },
    ],
  }),
  component: JobWorkspace,
});

function JobWorkspace() {
  const { jobId } = Route.useParams();
  const qc = useQueryClient();
  const job = useQuery(jobQuery(jobId));
  const estimate = useQuery(estimateQuery(jobId));
  const templates = useQuery(templatesQuery());
  const estimateId = estimate.data?.id ?? "";
  const phases = useQuery(phasesQuery(estimateId));
  const lines = useQuery(linesQuery(estimateId));

  const defaultMultiplier = num(estimate.data?.default_multiplier, 1.35);
  const estimateTotals = rollup(lines.data ?? [], phases.data ?? [], defaultMultiplier);

  // Cost plus bills cost + contingency + fee, so the header must reflect that
  // instead of the estimate's marked-up price.
  const isCostPlusJob = job.data?.contract_type === "cost_plus";
  const cpJob = isCostPlusJob
    ? costPlusTotals({
        cost: estimateTotals.cost,
        sell: estimateTotals.sell,
        feeStyle: (job.data?.fee_style ?? "percent_of_cost") as
          "percent_of_cost" | "line_multipliers",
        feePercent: job.data?.fee_percent ?? 0,
        contingencyPercent: job.data?.contingency_percent ?? 0,
      })
    : null;
  const totals = cpJob
    ? {
        ...estimateTotals,
        sell: cpJob.total,
        profit: cpJob.fee,
        margin: cpJob.total > 0 ? cpJob.fee / cpJob.total : 0,
        blended: estimateTotals.cost > 0 ? cpJob.total / estimateTotals.cost : 0,
      }
    : estimateTotals;

  const setStage = useMutation({
    mutationFn: async (stage: JobStage) => {
      const { error } = await supabase.from("jobs").update({ stage }).eq("id", jobId);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["job", jobId] });
      void qc.invalidateQueries({ queryKey: ["jobs"] });
    },
  });

  const setJobTargets = useMutation({
    mutationFn: async (patch: { target_margin?: number; margin_floor?: number }) => {
      const { error } = await supabase.from("jobs").update(patch).eq("id", jobId);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["job", jobId] }),
  });

  const setContract = useMutation({
    mutationFn: async (patch: {
      contract_type?: ContractType;
      fee_style?: FeeStyle;
      fee_percent?: number;
      contingency_percent?: number;
    }) => {
      const { error } = await supabase.from("jobs").update(patch).eq("id", jobId);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["job", jobId] });
      void qc.invalidateQueries({ queryKey: ["jobs"] });
      toast.success("Contract settings updated");
    },
  });

  const setDefaultMultiplier = useMutation({
    mutationFn: async (value: number) => {
      if (!estimateId) return;
      const { error } = await supabase
        .from("estimates")
        .update({ default_multiplier: value })
        .eq("id", estimateId);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["estimate", jobId] });
      void qc.invalidateQueries({ queryKey: ["job-totals"] });
      toast.success("Default multiplier updated");
    },
  });

  const createEstimate = useMutation({
    mutationFn: async (templateId: string | null) => {
      const j = job.data;
      if (!j) throw new Error("Job not loaded");
      const { data: est, error } = await supabase
        .from("estimates")
        .insert({
          job_id: jobId,
          name: `${j.name} estimate`,
          target_margin: j.target_margin,
          margin_floor: j.margin_floor,
          default_multiplier: multiplierForMargin(j.target_margin),
        })
        .select("id")
        .single();
      if (error) throw error;
      const template = (templates.data ?? []).find((t) => t.id === templateId);
      const phaseNames = (template?.template_phases ?? [])
        .slice()
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((p) => p.name);
      if (phaseNames.length > 0) {
        const { error: pe } = await supabase.from("estimate_phases").insert(
          phaseNames.map((name, i) => ({
            estimate_id: est.id,
            name,
            sort_order: i,
          })),
        );
        if (pe) throw pe;
      }
      return est;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["estimate", jobId] });
      toast.success("Estimate created");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not create estimate"),
  });

  if (!job.data) {
    return (
      <AppShell>
        <div className="py-24 text-center text-sm text-muted-foreground">Loading job…</div>
      </AppShell>
    );
  }

  const j = job.data;
  const health = marginState(totals.margin, j.target_margin, j.margin_floor);
  const jobTemplates = (templates.data ?? []).filter((t) => t.job_type === j.job_type);
  const targetMultiplier = multiplierForMargin(j.target_margin);

  const pricingPanel = (
    <details className="group rounded-lg border bg-card">
      <summary className="cursor-pointer list-none px-4 py-3 text-sm font-medium">
        Pricing &amp; targets
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          target {pct(j.target_margin, 0)} · floor {pct(j.margin_floor, 0)} ·{" "}
          {contractLabel(j.contract_type as ContractType)}
        </span>
      </summary>
      <div className="max-w-md space-y-5 border-t px-4 py-4">
        <div className="space-y-1.5">
          <Label>Target margin %</Label>
          <Input
            className="num"
            defaultValue={(j.target_margin * 100).toFixed(1)}
            onBlur={(e) => setJobTargets.mutate({ target_margin: num(e.target.value, 25) / 100 })}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Margin floor %</Label>
          <Input
            className="num"
            defaultValue={(j.margin_floor * 100).toFixed(1)}
            onBlur={(e) => setJobTargets.mutate({ margin_floor: num(e.target.value, 18) / 100 })}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Estimate default multiplier</Label>
          <Input
            className="num"
            key={defaultMultiplier}
            defaultValue={defaultMultiplier.toFixed(4)}
            onBlur={(e) => setDefaultMultiplier.mutate(num(e.target.value, defaultMultiplier))}
          />
          <p className="text-xs text-muted-foreground">
            Applied to any line and phase without its own multiplier.
          </p>
        </div>
        <div className="space-y-1.5">
          <Label>Contract type</Label>
          <Select
            value={j.contract_type}
            onValueChange={(v) => setContract.mutate({ contract_type: v as ContractType })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CONTRACT_TYPES.map((c) => (
                <SelectItem key={c.value} value={c.value}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {CONTRACT_TYPES.find((c) => c.value === j.contract_type)?.blurb}
          </p>
        </div>

        {j.contract_type === "cost_plus" && (
          <>
            <div className="space-y-1.5">
              <Label>Fee style</Label>
              <Select
                value={j.fee_style}
                onValueChange={(v) => setContract.mutate({ fee_style: v as FeeStyle })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FEE_STYLES.map((f) => (
                    <SelectItem key={f.value} value={f.value}>
                      {f.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Fee %</Label>
                <Input
                  className="num"
                  key={`fee-${j.fee_percent}`}
                  defaultValue={(num(j.fee_percent) * 100).toFixed(1)}
                  onBlur={(e) => setContract.mutate({ fee_percent: num(e.target.value, 20) / 100 })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Contingency %</Label>
                <Input
                  className="num"
                  key={`cont-${j.contingency_percent}`}
                  defaultValue={(num(j.contingency_percent) * 100).toFixed(1)}
                  onBlur={(e) =>
                    setContract.mutate({ contingency_percent: num(e.target.value, 5) / 100 })
                  }
                />
              </div>
            </div>
          </>
        )}

        <Button
          variant="outline"
          size="sm"
          disabled={!estimateId}
          onClick={() => setDefaultMultiplier.mutate(targetMultiplier)}
        >
          <Target className="mr-1.5 h-3.5 w-3.5" /> Solve to {pct(j.target_margin, 0)} margin (
          {mult(targetMultiplier)})
        </Button>
      </div>
    </details>
  );


  return (
    <AppShell>
      <Link
        to="/jobs"
        className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Job board
      </Link>

      <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-start sm:justify-between sm:gap-4">
        <div className="min-w-0">
          <h1 className="font-display text-2xl tracking-tight sm:text-3xl">{j.name}</h1>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            <Badge
              variant={j.contract_type === "cost_plus" ? "outline" : "secondary"}
              className="uppercase tracking-[0.1em]"
            >
              {contractLabel(j.contract_type as ContractType)}
            </Badge>
            <p className="text-sm text-muted-foreground">
              {[j.client_name, j.address, jobTypeLabel(j.job_type as JobType)]
                .filter(Boolean)
                .join(" · ")}
            </p>
          </div>
        </div>
        <Select value={j.stage} onValueChange={(v) => setStage.mutate(v as JobStage)}>
          <SelectTrigger className="w-full sm:w-[190px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {JOB_STAGES.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-2.5 sm:mt-6 sm:gap-3 lg:grid-cols-5">
        <Stat label="Job cost" value={money(totals.cost)} />
        <Stat label={cpJob ? "Estimated total" : "Contract price"} value={money(totals.sell)} />
        <Stat label={cpJob ? "Builder fee" : "Gross profit"} value={money(totals.profit)} />
        <Stat
          label={cpJob ? "Fee margin" : "Gross margin"}
          value={pct(totals.margin)}
          tone={health}
          hint={`target ${pct(j.target_margin, 0)} · floor ${pct(j.margin_floor, 0)}`}
        />

        <Stat
          label="Blended multiplier"
          value={mult(totals.blended || 1)}
          hint={`target needs ${mult(targetMultiplier)}`}
        />
      </div>

      {health !== "ok" && totals.sell > 0 && (
        <div
          className={cn(
            "mt-3 rounded-md border px-3 py-2 text-sm",
            health === "alert"
              ? "border-destructive/40 bg-destructive/5 text-destructive"
              : "border-warning/40 bg-warning/5 text-warning",
          )}
        >
          {health === "alert"
            ? `Margin is below your ${pct(j.margin_floor, 0)} floor. Raise multipliers or cut cost before sending.`
            : `Margin is under your ${pct(j.target_margin, 0)} target.`}
        </div>
      )}

      <Tabs defaultValue="scope" className="mt-6">
        <div className="space-y-1.5">
          <TabsList className={tabRow}>
            <TabsTrigger className={tabItem} value="scope">
              Scope
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="bids">
              Bids
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="estimate">
              Estimating
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="selections">
              Selections
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="proposal">
              Proposal
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="payments">
              {j.contract_type === "cost_plus" ? "Schedule of values" : "Payment schedule"}
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="contract">
              Contract
            </TabsTrigger>
          </TabsList>
          <TabsList className={tabRow}>
            <TabsTrigger className={tabItem} value="budget">
              Job budget
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="schedule">
              Schedule
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="daily-log">
              Daily logs
            </TabsTrigger>
          </TabsList>
          <TabsList className={tabRow}>
            <TabsTrigger className={tabItem} value="job-summary">
              Job summary
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="records">
              Records
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="product-packages">
              Product packages
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="lien-waivers">
              Lien waivers
            </TabsTrigger>
            <TabsTrigger className={tabItem} value="warranty">
              Warranty
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="scope" className="mt-4">
          <ScopeBreakdownTab
            jobId={jobId}
            estimateId={estimateId}
            jobName={j.name}
            jobAddress={j.address}
            startDate={j.start_date}
          />
        </TabsContent>

        <TabsContent value="bids" className="mt-4">
          <BidsTab
            jobId={jobId}
            estimateId={estimateId}
            jobName={j.name}
            jobAddress={j.address}
            startDate={j.start_date}
          />
        </TabsContent>

        <TabsContent value="estimate" className="mt-4 space-y-4">
          {pricingPanel}


          {estimateId ? (
            <EstimateGrid
              estimateId={estimateId}
              estimateDefaultMultiplier={defaultMultiplier}
              costPlus={
                isCostPlusJob
                  ? {
                      feePercent: num(j.fee_percent, 0),
                      contingencyPercent: num(j.contingency_percent, 0),
                    }
                  : null
              }
            />
          ) : (
            <div className="rounded-lg border border-dashed p-10 text-center">
              <h2 className="font-display text-xl">Start the estimate</h2>
              <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
                Load a sequence template for {jobTypeLabel(j.job_type as JobType)} so phases follow
                the order you actually build in, or start from a blank sheet.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {jobTemplates.map((t) => (
                  <Button key={t.id} size="sm" onClick={() => createEstimate.mutate(t.id)}>
                    {t.name}
                  </Button>
                ))}
                <Button variant="outline" size="sm" onClick={() => createEstimate.mutate(null)}>
                  Blank estimate
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="selections" className="mt-4">
          {estimateId ? (
            <SelectionsTab jobId={jobId} estimateId={estimateId} jobType={j.job_type as JobType} />
          ) : (
            <p className="text-sm text-muted-foreground">Build the estimate first.</p>
          )}
        </TabsContent>

        <TabsContent value="proposal" className="mt-4">
          {estimateId ? (
            <ProposalView
              estimateId={estimateId}
              estimateDefaultMultiplier={defaultMultiplier}
              jobName={j.name}
              clientName={j.client_name}
              address={j.address}
              contractType={j.contract_type as ContractType}
              feeStyle={j.fee_style as FeeStyle}
              feePercent={j.fee_percent}
              contingencyPercent={j.contingency_percent}
              startDate={j.start_date}
              targetEndDate={j.target_end_date}
              scheduleNotes={j.schedule_notes}
            />
          ) : (
            <p className="text-sm text-muted-foreground">Build the estimate first.</p>
          )}
        </TabsContent>

        <TabsContent value="payments" className="mt-4">
          <PaymentScheduleTab
            job={{
              id: j.id,
              name: j.name,
              contract_type: j.contract_type as ContractType,
              fee_style: j.fee_style as FeeStyle,
              fee_percent: j.fee_percent,
              contingency_percent: j.contingency_percent,
            }}
            estimateId={estimateId}
            estimateDefaultMultiplier={defaultMultiplier}
            contractOnly

          />
        </TabsContent>

        <TabsContent value="contract" className="mt-4">
          <Placeholder
            title="Contract"
            body={
              j.contract_type === "cost_plus"
                ? "Cost plus agreement built from the proposal and schedule of values. Not wired up yet."
                : "Fixed price agreement built from the proposal and payment schedule. Not wired up yet."
            }
          />
        </TabsContent>

        <TabsContent value="budget" className="mt-4">
          {j.contract_type === "cost_plus" ? (
            <PaymentScheduleTab
              job={{
                id: j.id,
                name: j.name,
                contract_type: j.contract_type as ContractType,
                fee_style: j.fee_style as FeeStyle,
                fee_percent: j.fee_percent,
                contingency_percent: j.contingency_percent,
              }}
              estimateId={estimateId}
              estimateDefaultMultiplier={defaultMultiplier}
            />
          ) : (
            <JobBudgetTab
              job={{ id: j.id, name: j.name }}
              estimateId={estimateId}
              estimateDefaultMultiplier={defaultMultiplier}
            />
          )}
        </TabsContent>


        <TabsContent value="job-summary" className="mt-4">
          <Placeholder
            title="Job summary"
            body="Final cost vs. contract recap at closeout. Not wired up yet."
          />
        </TabsContent>

        <TabsContent value="records" className="mt-4">
          <Placeholder
            title="Records"
            body="City and deputy inspection cards, approved final plans, HERS reports, and other official job records. Not wired up yet."
          />
        </TabsContent>

        <TabsContent value="product-packages" className="mt-4">
          <Placeholder
            title="Product packages"
            body="Owner handoff package of installed products, finishes, and manuals. Not wired up yet."
          />
        </TabsContent>

        <TabsContent value="warranty" className="mt-4">
          <Placeholder
            title="Warranty"
            body="Warranty terms, start date, and punch/warranty requests. Not wired up yet."
          />
        </TabsContent>

        <TabsContent value="lien-waivers" className="mt-4">
          <Placeholder
            title="Lien waivers"
            body="Collect unconditional lien waivers from subs and vendors before final payment and closeout. Not wired up yet."
          />
        </TabsContent>

        <TabsContent value="schedule" className="mt-4">
          <ScheduleTab
            job={{
              id: j.id,
              name: j.name,
              contract_type: j.contract_type as ContractType,
              start_date: j.start_date,
              target_end_date: j.target_end_date,
              schedule_notes: j.schedule_notes,
            }}
            estimateId={estimateId}
            estimateDefaultMultiplier={defaultMultiplier}
          />
        </TabsContent>

        <TabsContent value="daily-log" className="mt-4">
          <DailyLogTab jobId={j.id} />
        </TabsContent>


      </Tabs>
    </AppShell>
  );
}

function Placeholder({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-lg border border-dashed p-10 text-center">
      <h2 className="font-display text-xl">{title}</h2>
      <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">{body}</p>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "ok" | "warning" | "alert";
}) {
  return (
    <div className="min-w-0 rounded-lg border bg-card px-3 py-2.5">
      <div className="truncate text-[10px] uppercase tracking-[0.12em] text-muted-foreground sm:text-[11px] sm:tracking-[0.14em]">
        {label}
      </div>
      <div
        className={cn(
          "num mt-1 text-lg font-medium sm:text-xl",
          tone === "alert" && "text-destructive",
          tone === "warning" && "text-warning",
          tone === "ok" && "text-success",
        )}
      >
        {value}
      </div>
      {hint && (
        <div className="mt-0.5 text-[10px] leading-snug text-muted-foreground sm:text-[11px]">
          {hint}
        </div>
      )}
    </div>
  );
}
